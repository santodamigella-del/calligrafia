"""Varianti di stile per i modelli vettoriali e alfabeti aggiuntivi.

Tutto qui è DIDATTICO: le trasformazioni (larghezza, inclinazione, angolosità,
arrotondamento) rendono visibili le differenze strutturali tra gli stili, ma non
sono tracciati digitalizzati da un facsimile. Gli alfabeti greco e arabo sono
schemi semplificati da confrontare con un modello storico.
"""
import math

try:
    from riconoscimento_stile import id_da_nome
except ImportError:  # modulo opzionale
    id_da_nome = lambda nome: None

# sx: scala larghezza · shear: inclinazione (tan; + = verso destra)
# ang: 0..1 angolosità (semplifica le curve in spezzate) · rnd: iterazioni di arrotondamento
TRASFORMAZIONI = {
    "occidentale_onciale":          {"sx": 1.15, "shear": 0.00, "ang": 0.0, "rnd": 1},
    "occidentale_semionciale":      {"sx": 1.05, "shear": 0.03, "ang": 0.0, "rnd": 1},
    "occidentale_carolina":         {"sx": 1.00, "shear": 0.00, "ang": 0.0, "rnd": 0},
    "occidentale_umanistica":       {"sx": 1.06, "shear": 0.03, "ang": 0.0, "rnd": 0},
    "occidentale_textura":          {"sx": 0.78, "shear": 0.00, "ang": 0.8, "rnd": 0},
    "occidentale_textura_quadrata": {"sx": 0.72, "shear": 0.00, "ang": 1.0, "rnd": 0},
    "occidentale_rotunda":          {"sx": 1.12, "shear": 0.00, "ang": 0.0, "rnd": 1},
    "occidentale_fraktur":          {"sx": 0.85, "shear": 0.00, "ang": 0.6, "rnd": 0},
    "occidentale_bastarda":         {"sx": 0.88, "shear": 0.20, "ang": 0.4, "rnd": 0},
    "occidentale_batarde_francaise": {"sx": 0.88, "shear": 0.18, "ang": 0.45, "rnd": 0},
    "occidentale_gotica_cursiva":   {"sx": 0.90, "shear": 0.14, "ang": 0.35, "rnd": 0},
    "occidentale_kurrent":          {"sx": 0.80, "shear": 0.20, "ang": 0.7, "rnd": 0},
    "occidentale_sutterlin":        {"sx": 0.78, "shear": 0.04, "ang": 0.7, "rnd": 0},
    "occidentale_cancelleresca":    {"sx": 0.85, "shear": 0.25, "ang": 0.0, "rnd": 1},
    "occidentale_copperplate":      {"sx": 0.82, "shear": 0.62, "ang": 0.0, "rnd": 2},
    "occidentale_spencerian":       {"sx": 0.80, "shear": 0.68, "ang": 0.0, "rnd": 2},
    "occidentale_capitale_romana":  {"sx": 1.05, "shear": 0.00, "ang": 0.1, "rnd": 0},
    "occidentale_rustica":          {"sx": 0.80, "shear": 0.00, "ang": 0.2, "rnd": 0},
    "moderna_brush_lettering":      {"sx": 1.00, "shear": 0.30, "ang": 0.0, "rnd": 2},
}


def _rdp(pts, eps):
    if len(pts) < 3:
        return list(pts)
    (x1, y1), (x2, y2) = pts[0], pts[-1]
    dx, dy = x2 - x1, y2 - y1
    norm = math.hypot(dx, dy)
    idx, dmax = 0, -1.0
    for i in range(1, len(pts) - 1):
        px, py = pts[i]
        d = math.hypot(px - x1, py - y1) if norm == 0 else abs(dy * px - dx * py + x2 * y1 - y2 * x1) / norm
        if d > dmax:
            idx, dmax = i, d
    if dmax > eps:
        return _rdp(pts[:idx + 1], eps)[:-1] + _rdp(pts[idx:], eps)
    return [pts[0], pts[-1]]


def _chaikin(pts, giri):
    for _ in range(giri):
        if len(pts) < 3:
            break
        nuovi = [pts[0]]
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            nuovi.append((0.75 * ax + 0.25 * bx, 0.75 * ay + 0.25 * by))
            nuovi.append((0.25 * ax + 0.75 * bx, 0.25 * ay + 0.75 * by))
        nuovi.append(pts[-1])
        pts = nuovi
    return pts


def trasforma_tratto(stile, pts):
    """Applica la variante dello stile a un tratto (lista di (x, y) normalizzati)."""
    par = TRASFORMAZIONI.get(id_da_nome(stile) or stile)
    if not par or len(pts) < 2:
        return list(pts)
    out = list(pts)
    if par["ang"] > 0 and len(out) > 3:
        out = _rdp(out, 0.012 + 0.05 * par["ang"])
    if par["rnd"] > 0:
        out = _chaikin(out, par["rnd"])
    res = []
    for x, y in out:
        x = 0.5 + (x - 0.5) * par["sx"] + (0.78 - y) * par["shear"]
        res.append((max(0.04, min(0.96, x)), y))
    return res


# ----------------------------------------------------------------------------
# Alfabeto greco
# ----------------------------------------------------------------------------
_GRECO_COME_LATINO = {"Α": "A", "Β": "B", "Ε": "E", "Ζ": "Z", "Η": "H", "Ι": "I", "Κ": "K",
                      "Μ": "M", "Ν": "N", "Ο": "O", "Ρ": "P", "Τ": "T", "Υ": "Y", "Χ": "X",
                      "ο": "o", "ν": "v"}
_OVALE_O = [(.49, .16), (.29, .23), (.21, .47), (.27, .69), (.49, .78), (.70, .69), (.78, .47), (.70, .23), (.49, .16)]
GRECO_NUOVI = {
    "Γ": [[(.28, .78), (.28, .16), (.72, .16)]],
    "Δ": [[(.49, .16), (.20, .78), (.80, .78), (.49, .16)]],
    "Θ": [_OVALE_O, [(.36, .47), (.62, .47)]],
    "Λ": [[(.20, .78), (.49, .16), (.78, .78)]],
    "Ξ": [[(.22, .16), (.78, .16)], [(.36, .47), (.64, .47)], [(.22, .78), (.78, .78)]],
    "Π": [[(.22, .16), (.78, .16)], [(.30, .16), (.30, .78)], [(.70, .16), (.70, .78)]],
    "Σ": [[(.74, .16), (.26, .16), (.52, .47), (.26, .78), (.74, .78)]],
    "Φ": [[(.50, .16), (.50, .78)], [(.50, .28), (.32, .35), (.28, .47), (.32, .60), (.50, .67), (.68, .60), (.72, .47), (.68, .35), (.50, .28)]],
    "Ψ": [[(.50, .16), (.50, .78)], [(.24, .20), (.27, .52), (.50, .62), (.73, .52), (.76, .20)]],
    "Ω": [[(.20, .78), (.36, .78), (.26, .55), (.26, .35), (.40, .17), (.60, .17), (.74, .35), (.74, .55), (.64, .78), (.80, .78)]],
    "α": [[(.58, .30), (.44, .28), (.32, .42), (.32, .62), (.45, .76), (.57, .62), (.62, .30), (.64, .76)]],
    "β": [[(.35, .94), (.35, .25), (.52, .18), (.62, .30), (.52, .45), (.35, .48), (.58, .56), (.62, .68), (.50, .77), (.35, .72)]],
    "γ": [[(.28, .30), (.45, .62), (.62, .30)], [(.45, .62), (.45, .94)]],
    "δ": [[(.56, .14), (.42, .20), (.50, .30), (.60, .44), (.58, .64), (.46, .77), (.32, .66), (.32, .46), (.44, .36), (.58, .40)]],
    "ε": [[(.60, .34), (.48, .28), (.34, .36), (.44, .50), (.34, .64), (.48, .76), (.60, .70)]],
    "ζ": [[(.34, .14), (.62, .14), (.44, .34), (.34, .52), (.40, .74), (.52, .88), (.60, .94)]],
    "η": [[(.30, .30), (.30, .94)], [(.30, .46), (.44, .30), (.58, .38), (.58, .78)]],
    "θ": [[(.48, .14), (.34, .25), (.32, .50), (.40, .72), (.52, .78), (.64, .70), (.68, .48), (.62, .25), (.48, .14)], [(.40, .46), (.60, .46)]],
    "ι": [[(.42, .30), (.44, .70), (.54, .76)]],
    "κ": [[(.32, .30), (.32, .77)], [(.62, .30), (.34, .54), (.64, .77)]],
    "λ": [[(.30, .14), (.40, .28), (.64, .77)], [(.46, .46), (.28, .77)]],
    "μ": [[(.30, .30), (.30, .94)], [(.30, .60), (.40, .76), (.52, .70), (.58, .30)], [(.58, .60), (.66, .76)]],
    "ξ": [[(.60, .16), (.40, .16), (.32, .28), (.44, .40), (.58, .44), (.38, .50), (.32, .64), (.44, .76), (.58, .88), (.60, .94)]],
    "π": [[(.26, .32), (.70, .32)], [(.38, .32), (.38, .77)], [(.58, .32), (.58, .77)]],
    "ρ": [[(.34, .30), (.34, .94)], [(.34, .46), (.46, .30), (.60, .36), (.62, .54), (.50, .72), (.34, .62)]],
    "σ": [[(.46, .30), (.32, .44), (.32, .62), (.44, .76), (.58, .70), (.64, .54), (.58, .38), (.46, .30), (.70, .30)]],
    "ς": [[(.60, .34), (.46, .28), (.34, .38), (.42, .52), (.56, .58), (.60, .72), (.50, .80), (.38, .78)]],
    "τ": [[(.28, .32), (.64, .32)], [(.46, .32), (.46, .70), (.58, .77)]],
    "υ": [[(.30, .30), (.32, .62), (.44, .77), (.58, .66), (.62, .30)]],
    "φ": [[(.50, .12), (.50, .94)], [(.50, .30), (.34, .36), (.30, .54), (.38, .70), (.50, .74), (.64, .68), (.70, .52), (.64, .36), (.50, .30)]],
    "χ": [[(.30, .30), (.64, .77)], [(.64, .30), (.30, .94)]],
    "ψ": [[(.50, .14), (.50, .94)], [(.28, .30), (.30, .58), (.50, .70), (.70, .58), (.72, .30)]],
    "ω": [[(.28, .32), (.30, .62), (.40, .77), (.50, .62), (.60, .77), (.70, .62), (.72, .32)]],
}
GRECO_MAIUSCOLE = list("ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ")
GRECO_MINUSCOLE = list("αβγδεζηθικλμνξοπρσςτυφχψω")


def modelli_greci(modelli_latini):
    """Costruisce i modelli greci riusando le forme latine identiche."""
    out = {k: [list(s) for s in v] for k, v in GRECO_NUOVI.items()}
    for g, l in _GRECO_COME_LATINO.items():
        if l in modelli_latini:
            out[g] = [list(s) for s in modelli_latini[l]]
    return out


# ----------------------------------------------------------------------------
# Alfabeto arabo (forme isolate, schema semplificato; i puntini sono tratti minimi)
# ----------------------------------------------------------------------------
def _p(x, y):
    return [(x, y), (x + .001, y + .001)]


_B = [(.80, .42), (.74, .62), (.55, .72), (.35, .70), (.22, .58), (.20, .45)]
_N = [(.78, .40), (.76, .62), (.62, .76), (.40, .78), (.26, .66), (.28, .46)]
_J = [(.70, .30), (.40, .28), (.28, .42), (.38, .55), (.62, .60), (.66, .72), (.54, .84), (.34, .82)]
_D = [(.30, .38), (.60, .40), (.66, .55), (.55, .74), (.35, .80)]
_R = [(.62, .40), (.58, .60), (.48, .76), (.30, .84)]
_S = [(.88, .44), (.84, .56), (.78, .44), (.72, .56), (.66, .44), (.60, .56), (.54, .46), (.40, .68), (.22, .70), (.14, .52)]
_SD = [(.76, .42), (.62, .36), (.52, .46), (.60, .58), (.76, .56), (.84, .62), (.60, .72), (.30, .72), (.16, .52)]
_T = [(.78, .50), (.60, .44), (.42, .52), (.44, .68), (.66, .72), (.82, .64)]
_A = [(.66, .30), (.46, .28), (.38, .40), (.52, .50), (.66, .58), (.60, .74), (.40, .82), (.24, .76)]
_F = [(.70, .44), (.52, .38), (.42, .50), (.54, .62), (.70, .56), (.74, .74), (.55, .82), (.24, .78)]
ARABO_ISOLATE = {
    "ا": [[(.50, .15), (.50, .80)]],
    "ب": [_B, _p(.50, .84)],
    "ت": [_B, _p(.43, .30), _p(.57, .30)],
    "ث": [_B, _p(.40, .32), _p(.60, .32), _p(.50, .20)],
    "ج": [_J, _p(.48, .72)],
    "ح": [_J],
    "خ": [_J, _p(.50, .16)],
    "د": [_D],
    "ذ": [_D, _p(.50, .26)],
    "ر": [_R],
    "ز": [_R, _p(.60, .28)],
    "س": [_S],
    "ش": [_S, _p(.46, .30), _p(.60, .30), _p(.53, .20)],
    "ص": [_SD],
    "ض": [_SD, _p(.50, .24)],
    "ط": [[(.55, .14), (.55, .66)], _T],
    "ظ": [[(.55, .14), (.55, .66)], _T, _p(.72, .20)],
    "ع": [_A],
    "غ": [_A, _p(.48, .16)],
    "ف": [_F, _p(.56, .26)],
    "ق": [_F, _p(.48, .26), _p(.62, .26)],
    "ك": [[(.74, .12), (.74, .70), (.55, .80), (.25, .76)], [(.60, .40), (.40, .52), (.58, .58)]],
    "ل": [[(.70, .14), (.70, .68), (.52, .80), (.28, .76)]],
    "م": [[(.62, .40), (.48, .34), (.40, .46), (.48, .60), (.62, .56), (.64, .42), (.58, .74), (.44, .88)]],
    "ن": [_N, _p(.52, .30)],
    "ه": [[(.58, .34), (.44, .30), (.34, .44), (.44, .58), (.60, .50), (.62, .36), (.50, .30)]],
    "و": [[(.56, .30), (.44, .32), (.40, .44), (.50, .54), (.60, .46), (.56, .30), (.54, .72), (.40, .86), (.24, .86)]],
    "ي": [[(.84, .36), (.82, .60), (.66, .70), (.40, .68), (.20, .74), (.10, .62)], _p(.44, .88), _p(.56, .88)],
}
ARABO_LETTERE = list(ARABO_ISOLATE.keys())

# Hiragana: elenco dei caratteri per la selezione (solo glifo di riferimento, nessun modello vettoriale).
HIRAGANA = list("あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん")


def tutti_i_modelli(modelli_latini):
    """Unisce greco e arabo in un unico dizionario carattere -> tratti."""
    out = modelli_greci(modelli_latini)
    out.update({k: [list(s) for s in v] for k, v in ARABO_ISOLATE.items()})
    return out


def descrivi_tratti(strokes):
    """Istruzioni generate dalla geometria: direzione e forma di ogni tratto."""
    passi = []
    for i, pts in enumerate(strokes, 1):
        if len(pts) == 2 and math.dist(pts[0], pts[1]) < 0.01:
            passi.append(f"Tratto {i} · Punto diacritico: tocco breve e leggero nella posizione indicata.")
            continue
        (x0, y0), (x1, y1) = pts[0], pts[-1]
        lung = sum(math.dist(a, b) for a, b in zip(pts, pts[1:]))
        dritto = math.dist(pts[0], pts[-1])
        forma = "tratto quasi rettilineo" if lung < dritto * 1.12 else ("tratto chiuso a occhiello" if dritto < lung * 0.25 else "tratto curvo")
        v = "alto" if y1 < y0 - .1 else ("basso" if y1 > y0 + .1 else "")
        o = "destra" if x1 > x0 + .1 else ("sinistra" if x1 < x0 - .1 else "")
        verso = " verso " + " e ".join(x for x in (v and f"il {v}", o and f"{o}") if x) if (v or o) else ""
        passi.append(f"Tratto {i} · {forma} che parte da ({x0:.2f}, {y0:.2f}) e termina{verso}.")
    passi.append("Schema semplificato: confrontalo con un modello storico verificato prima di usarlo come riferimento.")
    return passi
