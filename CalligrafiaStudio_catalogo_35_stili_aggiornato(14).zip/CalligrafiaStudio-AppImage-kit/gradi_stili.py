"""Gradi calligrafici per stile: angolo del pennino, altezza del corpo e inclinazione (senza Qt).

Fonti, in quest'ordine:
  1. L'ARCHIVIO CALLIGRAFICO dell'utente (cartella dati_stili/*_ductus.json): ha la precedenza.
  2. Le STIME dell'app (dati_stili/stime_app.json, modificabile) per gli stili che l'archivio non copre
     o per i campi che non indica.
Un campo senza valore (None) significa «non applicabile o non noto»: chi usa il modulo lascia quel
parametro com'è. Ogni valore ha la sua provenienza ("archivio" o "stima") per poterla mostrare all'utente.

Il file di un archivio rovinato o mancante non blocca l'app: il modulo ignora ciò che non legge e
riporta l'elenco dei problemi in PROBLEMI.
"""
import json
import os
import sys

try:
    from riconoscimento_stile import id_da_nome
except ImportError:                                   # modulo opzionale
    id_da_nome = lambda nome: None

# id dello stile -> frammento (minuscolo) del nome della voce nell'archivio
MAPPA_ARCHIVIO = {
    "occidentale_cancelleresca": "cancelleresca",
    "occidentale_carolina": "carolingia",
    "occidentale_onciale": "unciale",
    "occidentale_textura": "textura",
    "occidentale_rotunda": "rotunda",
    "occidentale_fraktur": "fraktur",
    "occidentale_capitale_romana": "lapidarie",
    "occidentale_rustica": "rustica",
    "araba_naskh": "naskh",
    "araba_thuluth": "naskh",                          # nell'archivio la voce è «Naskh / Thuluth»
    "araba_kufico": "kufico",
}
# Se l'id non ha né voce né stima propria, eredita da questo (derivati)
EREDITA_DA = {"occidentale_textura_quadrata": "occidentale_textura"}

CAMPI = ("angolo_pennino_gradi", "altezza_corpo_x_pennini", "inclinazione_gradi")
PROBLEMI = []


def cartella_dati():
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "dati_stili")


def _leggi(percorso):
    try:
        with open(percorso, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as errore:
        PROBLEMI.append(f"{os.path.basename(percorso)}: {errore}")
        return None


def _numero(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return None


def _voci_archivio(cartella):
    """Elenco normalizzato delle voci di tutti i file *_ductus.json."""
    voci = []
    try:
        nomi = sorted(n for n in os.listdir(cartella) if n.endswith("_ductus.json"))
    except OSError as errore:
        PROBLEMI.append(f"cartella {cartella}: {errore}")
        return voci
    for nome in nomi:
        dati = _leggi(os.path.join(cartella, nome))
        if not isinstance(dati, dict):
            continue
        elementi = []
        if "varianti" in dati and isinstance(dati["varianti"], list):
            elementi = [e for e in dati["varianti"] if isinstance(e, dict)]
        elif "stili" in dati and isinstance(dati["stili"], list):
            elementi = [e for e in dati["stili"] if isinstance(e, dict)]
        else:
            elementi = [dati]
        for e in elementi:
            titolo = str(e.get("nome") or e.get("stile") or "")
            if not titolo:
                continue
            voci.append({
                "titolo": titolo, "file": nome,
                "angolo_pennino_gradi": _numero(e.get("angolo_pennino_gradi")),
                "altezza_corpo_x_pennini": _numero(e.get("altezza_corpo_x_pennini")),
                "inclinazione_gradi": _numero(e.get("inclinazione_gradi")),
                "nota": str(e.get("note") or e.get("caratteristiche") or e.get("dinamica") or e.get("struttura") or ""),
            })
    return voci


def _stime(cartella):
    dati = _leggi(os.path.join(cartella, "stime_app.json"))
    if isinstance(dati, dict) and isinstance(dati.get("stili"), dict):
        return {k: v for k, v in dati["stili"].items() if isinstance(v, dict)}
    return {}


_CACHE = {}


def ricarica(cartella=None):
    """Rilegge i file (utile dopo averli modificati)."""
    cartella = cartella or cartella_dati()
    del PROBLEMI[:]
    _CACHE.clear()
    _CACHE["cartella"] = cartella
    _CACHE["voci"] = _voci_archivio(cartella)
    _CACHE["stime"] = _stime(cartella)
    return _CACHE


def _dati():
    if "voci" not in _CACHE:
        ricarica()
    return _CACHE


def gradi_per_id(stile_id, _profondita=0):
    """Gradi dello stile: dict con angolo, corpo, inclinazione, provenienza di ciascuno e note; None se sconosciuto."""
    if not stile_id:
        return None
    dati = _dati()
    voce = None
    frammento = MAPPA_ARCHIVIO.get(stile_id)
    if frammento:
        voce = next((v for v in dati["voci"] if frammento in v["titolo"].casefold()), None)
    stima = dati["stime"].get(stile_id)
    if voce is None and stima is None:
        padre = EREDITA_DA.get(stile_id)
        if padre and _profondita < 3:
            g = gradi_per_id(padre, _profondita + 1)
            if g:
                g = dict(g); g["id"] = stile_id
                g["nota"] = "Derivato da " + g.get("titolo", padre) + ". " + g.get("nota", "")
            return g
        return None
    risultato = {"id": stile_id, "titolo": voce["titolo"] if voce else stile_id, "valori": {}, "fonte": {}, "note": []}
    for campo in CAMPI:
        valore, fonte = None, None
        if voce and voce[campo] is not None:
            valore, fonte = voce[campo], "archivio"
        elif stima and campo in stima:
            valore = _numero(stima[campo])
            fonte = "stima" if valore is not None else None
        risultato["valori"][campo] = valore
        risultato["fonte"][campo] = fonte
    if voce and voce["nota"]:
        risultato["note"].append(voce["nota"])
    if stima and stima.get("note"):
        risultato["note"].append(str(stima["note"]))
    risultato["angolo"] = risultato["valori"]["angolo_pennino_gradi"]
    risultato["corpo"] = risultato["valori"]["altezza_corpo_x_pennini"]
    risultato["inclinazione"] = risultato["valori"]["inclinazione_gradi"]
    risultato["nota"] = " ".join(risultato["note"])
    return risultato


def gradi_per_nome(nome):
    """Come gradi_per_id, partendo da un nome di stile qualsiasi usato nell'app."""
    chiave = (nome or "").casefold()
    if chiave == "cinese" or chiave.startswith("cinese"):
        return gradi_per_id("cinese_pennello")
    return gradi_per_id(id_da_nome(nome))


def descrizione(g):
    """Testo italiano con i gradi e la loro provenienza."""
    if not g:
        return "Nessun dato sui gradi per questo stile: i valori restano quelli impostati."
    def parte(etichetta, valore, fonte, unita, vuoto):
        if valore is None:
            return f"{etichetta}: {vuoto}"
        n = f"{valore:g}"
        return f"{etichetta}: {n}{unita} ({fonte})"
    parti = [
        parte("pennino", g["angolo"], g["fonte"]["angolo_pennino_gradi"], "°", "non applicabile (invariato)"),
        parte("corpo", g["corpo"], g["fonte"]["altezza_corpo_x_pennini"], " larghezze", "non indicato (invariato)"),
        parte("inclinazione", g["inclinazione"], g["fonte"]["inclinazione_gradi"], "°", "non indicata (invariata)"),
    ]
    testo = " · ".join(parti)
    if any(f == "stima" for f in g["fonte"].values()):
        testo += ". «stima» = valore stimato dall'app (modificabile in dati_stili/stime_app.json)"
    return testo
