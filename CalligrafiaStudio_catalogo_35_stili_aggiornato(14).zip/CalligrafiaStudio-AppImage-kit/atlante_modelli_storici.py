"""Atlante documentario per la ricostruzione paleografica di Calligrafia Studio.

I profili qui descrivono caratteri osservabili e fonti d'esemplare. Non sono
coordinate vettoriali né misure universali: queste ultime vanno digitalizzate
sulle immagini dei singoli fogli prima di essere usate come modelli esecutivi.
"""

ATLANTE_STORICO = {
    "carolina": {
        "nome": "Minuscola carolina",
        "esemplare": "Ad fontes, Università di Zurigo — pagina Caroline Minuscule; Grandval Bible, Tours, ca. 840 come riferimento manoscritto storico da confrontare.",
        "url": "https://histadfontes02.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/karolingische-minuskel",
        "osservabili": [
            "minuscole generalmente ben separate e leggibili",
            "forme relativamente regolari e aperte",
            "distinzione chiara tra corpo, aste ascendenti e discendenti",
            "variazioni di ductus e proporzioni tra scriptoria ed epoche"
        ],
        "lettere_spia": ["a", "g", "d", "e", "h", "m", "r", "s"],
        "maiuscole": "Le capitali di titolo e le iniziali vanno studiate separatamente: non sono semplicemente le minuscole ingrandite.",
        "strumento": "Penna a punta larga; angolo e modulo da rilevare sul foglio scelto.",
        "misure": "Da misurare sul facsimile: altezza del corpo, aste, discendenti, larghezza media e interlinea. Nessun rapporto numerico universale preimpostato.",
        "stato": "Riferimento storico individuato; forme vettoriali specifiche ancora da trascrivere dal facsimile."
    },
    "textura": {
        "nome": "Gotica Textura / Textualis formata",
        "esemplare": "Rudolf von Ems, Weltchronik, ca. 1350, Zentralbibliothek Zürich, Ms. Rh. 15, fol. 218v (esempio indicato da Ad fontes).",
        "url": "https://histadfontes02.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/spaetkarolingische-und-fruehgotische-minuskeln",
        "osservabili": [
            "ritmo fortemente verticale e fascia mediana relativamente compressa",
            "aste ravvicinate e ripetizione serrata dei minimi",
            "spezzatura degli archi e giunzioni angolose",
            "contrasto tra trama compatta e spazi interni delle lettere"
        ],
        "lettere_spia": ["i", "m", "n", "u", "a", "d", "o", "g"],
        "maiuscole": "Iniziali e capitali di testo vanno rilevate dalla stessa pagina o da un repertorio coevo dichiarato; non derivarle dal font Fraktur.",
        "strumento": "Penna a punta larga; ricavare angolo e larghezza del tratto dal facsimile.",
        "misure": "Misurare corpo, rapporto altezza/larghezza, passo dei minimi e interlinea direttamente sul foglio.",
        "stato": "Esemplare e foglio identificati; occorre tracciare separatamente ogni lettera e i suoi allografi."
    },
    "rotunda": {
        "nome": "Gotica Rotunda",
        "esemplare": "Psalmen und Brevier, Italia, XV secolo, Zentralbibliothek Zürich, Ms. Rh. 182, fol. 9r (confronto Ad fontes).",
        "url": "https://histadfontes02.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/spaetkarolingische-und-fruehgotische-minuskeln",
        "osservabili": [
            "forme gotiche più arrotondate rispetto alla Textura",
            "minimi e archi con andamento meno rigidamente spezzato",
            "ritmo librario e spaziatura da leggere nella specifica mano italiana",
            "varianti locali: non assumere un'unica Rotunda canonica"
        ],
        "lettere_spia": ["o", "c", "e", "d", "p", "b", "m", "n"],
        "maiuscole": "Rilevare iniziali e capitali dalla stessa tradizione libraria; non usare automaticamente capitali romane moderne.",
        "strumento": "Penna a punta larga; angolo e modulo da ricavare dal manoscritto.",
        "misure": "Rilevare larghezza delle curve, altezza del corpo, aste e spaziatura sul foglio campione.",
        "stato": "Esemplare identificato; vettorializzazione delle forme ancora da realizzare."
    },
    "bastarda": {
        "nome": "Bastarda",
        "esemplare": "Livre d'heures, Tours, XV secolo, Zentralbibliothek Zürich, Ms. C 168, fol. 17r (Ad fontes).",
        "url": "https://adfontes.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte",
        "osservabili": [
            "ibridazione di elementi textualis e corsivi",
            "inclinazione visibile nella mano esemplificata",
            "forme e legature dipendenti dalla variante regionale",
            "discendenti e lettere lunghe da osservare nel contesto della singola mano"
        ],
        "lettere_spia": ["a", "g", "h", "f", "s", "r", "d", "e"],
        "maiuscole": "Selezionare le maiuscole del medesimo libro d'ore; distinguere iniziali decorate da capitali correnti.",
        "strumento": "Penna a punta larga; angolo, inclinazione e modulo da misurare sull'esemplare.",
        "misure": "Misurare corpo, aste, discendenti, inclinazione e connessioni sul foglio; evitare rapporti standardizzati.",
        "stato": "Esemplare identificato; prima di digitalizzare fissare la variante e la mano del foglio."
    }
    ,"umanistica": {
        "nome": "Scrittura umanistica libraria",
        "esemplare": "British Library, Add MS 15246, fol. 29 — copia italiana, probabilmente napoletana, della fine del XV secolo (esempio paleografico riprodotto dalla New Palaeographical Society, 1911).",
        "url": "https://medievalwritings.atillo.com.au/scripts/examples/human2.htm",
        "osservabili": [
            "minuscola libraria di impianto carolino, con forme regolari e separate",
            "distinzione tra s lunga e s finale e presenza di t corta",
            "legature come ae, ct e st da verificare nella pagina",
            "i/j e u/v non necessariamente distinti secondo l'uso moderno"
        ],
        "lettere_spia": ["a", "g", "d", "e", "s", "t", "m", "n"],
        "maiuscole": "Le capitali e le iniziali vanno rilevate nel medesimo codice: non presumere che ogni maiuscola sia una capitale umanistica uniforme.",
        "strumento": "Penna a punta larga; angolo, contrasto e modulo devono essere ricavati dalla pagina campione.",
        "misure": "Rilevare altezza del corpo, aste, larghezza, interlinea e rapporto tra lettere tonde e strette direttamente dal facsimile.",
        "stato": "Esemplare identificato a livello di pagina; schede morfologiche didattiche aggiunte, vettorializzazione dal facsimile ancora da realizzare."
    }

    ,"cancelleresca": {
        "nome": "Cancelleresca / Italica",
        "esemplare": "Ludovico degli Arrighi, La Operina (Roma, 1522), tavole calligrafiche a stampa; da confrontare con documenti di cancelleria coevi per distinguere modello didattico e uso documentario.",
        "url": "https://www.digitale-sammlungen.de/",
        "osservabili": [
            "andamento corsivo e inclinazione variabile secondo la mano e la tavola",
            "contrasto prodotto dal pennino a punta larga e dall'angolo di scrittura",
            "aste ascendenti e discendenti con forme e terminali caratteristici",
            "legature e continuità del gesto da verificare lettera per lettera"
        ],
        "lettere_spia": ["a", "d", "g", "h", "m", "r", "s", "t"],
        "maiuscole": "Le maiuscole vanno rilevate dalle tavole dell'Arrighi o da un testimone coevo dichiarato; non sono semplici minuscole ingrandite.",
        "strumento": "Pennino a punta larga; larghezza, angolo e inclinazione vanno calibrati sulla tavola specifica.",
        "misure": "Rilevare altezza del corpo, aste, discendenti, inclinazione, larghezza e rapporto con la larghezza del pennino direttamente dalla tavola scelta.",
        "stato": "Fonte tipografica storica individuata; repertorio didattico aggiunto. Tracciati vettoriali da digitalizzare sulle tavole originali."
    }
}


def scheda_storica(chiave):
    """Restituisce la scheda documentaria di una famiglia, se presente."""
    return ATLANTE_STORICO.get(chiave)


# Schede paleografiche per la minuscola carolina. Le descrizioni distinguono
# i tratti attestati nelle fonti didattiche dalle sequenze operative proposte
# per l'esercizio: non sono coordinate estratte da un facsimile.
CAROLINA_LETTERE = {
    "a": {"forma": "a a due occhielli / forma libraria carolina; confrontare l'apertura del tratto e la forma del secondo elemento nella mano scelta.", "osservazione": "La forma è vicina alla minuscola libraria moderna, ma presenta varianti di mano e di periodo.", "esercizio": ["Imposta il corpo ovale nella fascia mediana.", "Aggiungi il tratto destro secondo la forma osservata nel facsimile.", "Controlla apertura, asse e raccordo: non chiudere automaticamente ogni variante."]},
    "d": {"forma": "d con asta ascendente; sono documentate anche varianti con asta inclinata a sinistra.", "osservazione": "L'asta può essere diritta o assumere una forma onciale: registrare quale compare nella pagina campione.", "esercizio": ["Costruisci il corpo arrotondato nella fascia mediana.", "Aggiungi l'asta ascendente con il profilo osservato.", "Verifica altezza, inclinazione e attacco al corpo."]},
    "g": {"forma": "g con occhiello superiore e tratto inferiore ricurvo; la forma carolina è spesso descritta come derivata dalla semionciale.", "osservazione": "La coda e la relazione fra i due elementi variano fra copisti; non sostituirla con una g tipografica generica.", "esercizio": ["Disegna l'occhiello superiore nella fascia mediana.", "Aggiungi il tratto inferiore e la sua curva sotto la linea di base.", "Confronta direzione, apertura e rapporto fra i due elementi con l'esemplare."]},
    "e": {"forma": "e con tratto orizzontale / lingua che può proseguire verso destra.", "osservazione": "La lingua può avvicinarsi o raccordarsi alla lettera seguente; osservare il contesto e la velocità della mano.", "esercizio": ["Costruisci il corpo arrotondato.", "Inserisci il tratto mediano distinguibile.", "Prolunga il terminale destro solo quanto mostra il modello."]},
    "s": {"forma": "s lunga e alta, normalmente non sostituita dalla s onciale arrotondata nella minuscola carolina libraria.", "osservazione": "Distinguere s da r: la spalla della s raggiunge un'altezza maggiore.", "esercizio": ["Traccia il corpo curvo mantenendo la verticalità della lettera.", "Definisci la spalla superiore.", "Confronta altezza e terminali con r e f della stessa mano."]},
    "r": {"forma": "r con spalla breve; può comparire una variante a forma di 2 in contesti specifici, ad esempio dopo o.", "osservazione": "La variante contestuale non va generalizzata a tutte le posizioni.", "esercizio": ["Imposta l'asta breve.", "Aggiungi la spalla o il terminale secondo la posizione nella parola.", "Confronta la r ordinaria con l'allografo contestuale dopo o."]},
    "h": {"forma": "h con asta ascendente e spalla arcuata nella fascia mediana.", "osservazione": "Osservare la curva della spalla e il punto in cui si raccorda all'asta.", "esercizio": ["Traccia l'asta ascendente.", "Forma la spalla arcuata senza irrigidirla.", "Confronta altezza e larghezza con n e m."]},
    "m": {"forma": "m costruita da minimi ripetuti, con ritmo regolare.", "osservazione": "La distanza fra i minimi e la forma dei raccordi sono indicatori importanti della mano.", "esercizio": ["Imposta il primo minimo.", "Ripeti i minimi mantenendo ritmo e spaziatura.", "Controlla che la lettera non diventi troppo larga rispetto a n."]},
}

def scheda_lettera_carolina(lettera):
    """Restituisce una nota didattica prudente per le lettere-spia caroline."""
    return CAROLINA_LETTERE.get(str(lettera).lower())

# Le maiuscole dei manoscritti carolingi non costituiscono un unico alfabeto
# "maiuscolo carolino": nei titoli si alternano Capitalis quadrata, rustica,
# onciale, forme miste e iniziali ornamentali. Le note seguenti guidano
# l'osservazione, ma non fingono di essere tracciati estratti dal foglio.
CAROLINA_MAIUSCOLE = {
    "A": ("Capitale di tradizione romana; osservare forma del vertice, traversa e proporzione delle gambe.", "Confrontare la Capitalis quadrata e la rustica: la seconda tende a essere più stretta e alta."),
    "B": ("Due occhielli sovrapposti; confrontare dimensioni e punto di innesto sul fusto.", "Non rendere automaticamente uguali i due occhielli: misurare il modello."),
    "C": ("Curva aperta con terminali distinti.", "Osservare orientamento e forma dei terminali nella capitale scelta."),
    "D": ("Fusto verticale e curva esterna; verificare larghezza e asse.", "La quadrata tende a proporzioni più ampie della rustica."),
    "E": ("Fusto e tre bracci; confrontare lunghezze e posizione del braccio mediano.", "Registrare eventuali grazie e contrasto del tratto."),
    "F": ("Fusto e due bracci; il braccio inferiore manca rispetto alla E.", "Misurare il rapporto tra braccio superiore e mediano."),
    "G": ("Curva aperta con tratto interno; la soluzione varia tra modelli epigrafici e librari.", "Usare la forma attestata nella pagina, non una G tipografica contemporanea."),
    "H": ("Due fusti e traversa; controllare altezza e posizione della traversa.", "Osservare se i fusti sono verticali o leggermente modulati."),
    "I": ("Fusto semplice oppure fusto con grazie terminali.", "La presenza e la forma delle grazie dipendono dalla capitale scelta."),
    "J": ("Non è una forma stabile in tutti gli alfabeti latini medievali.", "Non imporla al modello: verificare se compare nel repertorio e nel periodo scelto."),
    "K": ("Fusto e diagonali; verificare i punti d'incontro delle diagonali.", "La K può essere rara in alcuni repertori librari: documentare la fonte."),
    "L": ("Fusto e piede; misurare la lunghezza del braccio inferiore.", "Confrontare terminali e proporzioni nella quadrata e nella rustica."),
    "M": ("Due fusti e diagonali centrali; osservare se le diagonali scendono al piede o si incontrano più in alto.", "La M è utile per confrontare le proporzioni geometriche della quadrata."),
    "N": ("Due fusti e diagonale; controllare inclinazione e attacchi.", "Confrontare larghezza complessiva con M e H."),
    "O": ("Forma chiusa; osservare asse, larghezza e andamento non necessariamente circolare.", "Confrontare l'ovale con D e Q nel medesimo alfabeto."),
    "P": ("Fusto e occhiello superiore; osservare quanto scende l'occhiello.", "Non aggiungere un secondo occhiello come nella B."),
    "Q": ("Ovale con coda; la coda può variare molto per orientamento e lunghezza.", "Verificare la forma nel repertorio effettivamente usato."),
    "R": ("Fusto, occhiello e gamba obliqua; confrontare il raccordo della gamba.", "La gamba può avere un andamento diverso tra quadrata e rustica."),
    "S": ("Curva continua; osservare asse e terminali.", "Evitare una S moderna uniforme: seguire il ductus e la modulazione del facsimile."),
    "T": ("Fusto e traversa superiore; controllare centratura e sporgenza.", "Confrontare larghezza della traversa con la larghezza del corpo."),
    "U": ("Forma curva con due fusti; distinguere U da V secondo la convenzione del manoscritto.", "La distinzione grafica U/V non è uniforme nei testimoni medievali."),
    "V": ("Forma angolare; osservare se è distinta da U nel testimone.", "Non modernizzare automaticamente la distinzione U/V."),
    "W": ("Non è normalmente parte del repertorio latino antico standard.", "Non inserirla senza attestazione nel modello storico selezionato."),
    "X": ("Due diagonali incrociate; controllare il punto d'incrocio.", "Verificare spessore e terminali nel facsimile."),
    "Y": ("Due bracci superiori e fusto; la forma può variare.", "Documentare la variante e non dedurla da font moderni."),
    "Z": ("Tre tratti principali; osservare diagonale e terminali.", "Verificare la presenza e la forma nel repertorio scelto."),
}

def scheda_maiuscola_carolina(lettera):
    """Nota di osservazione per capitali usate nei titoli carolingi."""
    dato = CAROLINA_MAIUSCOLE.get(str(lettera).upper())
    if not dato:
        return None
    return {"forma": dato[0], "osservazione": dato[1], "esercizio": [
        "Individua la capitale nel foglio campione e annota se è quadrata, rustica, onciale, mista o ornamentale.",
        "Misura altezza, larghezza, spessore e terminali rispetto alla stessa pagina.",
        "Ricostruisci il ductus solo dopo aver distinto i tratti osservabili dalle ipotesi operative."
    ]}


# Estensione delle schede caroline: completa l'alfabeto minuscolo con note
# morfologiche prudenti. Le sequenze sono esercizi proposti, non trascrizioni
# cinematiche certificate del copista del manoscritto campione.
CAROLINA_LETTERE_EXTRA = {
    "b": ("Asta ascendente e occhiello nella fascia mediana.", "Confrontare altezza dell'asta, apertura dell'occhiello e punto d'attacco."),
    "c": ("Curva aperta, con terminali che variano secondo la mano.", "Osservare orientamento dei terminali e rapporto con e, o e t."),
    "f": ("Asta alta con tratto mediano; nella minuscola libraria va distinta dalla s lunga.", "Verificare altezza, traversa e presenza di eventuale tratto discendente nel testimone."),
    "i": ("Minimo semplice nella fascia mediana; il punto non è un elemento costante dei modelli più antichi.", "Non aggiungere automaticamente il punto moderno: controllare data e mano."),
    "j": ("Non è normalmente distinta da i come lettera autonoma nei modelli carolingi antichi.", "Per un alfabeto storico non introdurre j senza attestazione nel repertorio scelto."),
    "k": ("Asta ascendente con due bracci obliqui; lettera poco frequente nel latino librario.", "Registrare forma e frequenza dal testo campione, senza ricavare la k da un font moderno."),
    "l": ("Asta ascendente semplice, con eventuali lievi curvature o piedi secondo la mano.", "Confrontare altezza, terminale e inclinazione con b, h e d."),
    "n": ("Due minimi nella fascia mediana, con spalla arcuata.", "Controllare passo dei minimi e raccordo; confrontare con m e u."),
    "o": ("Corpo ovale chiuso, non necessariamente un cerchio geometrico.", "Misurare asse, larghezza e inclinazione confrontandoli con c, e e a."),
    "p": ("Asta discendente con occhiello nella fascia mediana.", "Misurare la discesa rispetto al corpo e la forma dell'occhiello."),
    "q": ("Corpo ovale con asta discendente, spesso sul lato destro.", "Osservare direzione e terminale della discendente nel testimone."),
    "t": ("Asta che supera poco o moderatamente il corpo, con traversa breve.", "La quota dell'asta e la posizione della traversa sono variabili storiche da rilevare."),
    "u": ("Due minimi/curve; la distinzione grafica da v non è sempre moderna né costante.", "Verificare convenzioni ortografiche e forma nel contesto del manoscritto."),
    "v": ("Forma angolare o arrotondata secondo la mano e la posizione; può alternare con u.", "Non imporre la distinzione u/v contemporanea senza prova nel testimone."),
    "x": ("Due tratti incrociati, con proporzioni e incrocio variabili.", "Osservare ordine e sovrapposizione dei tratti sul facsimile."),
    "y": ("Due elementi con tratto discendente; forma e coda variano.", "Misurare la discendente e verificare la forma effettiva nella mano scelta."),
    "z": ("Forma poco frequente, con varianti di tracciato.", "Registrare la variante dal testimone; non assumere la z tipografica moderna.")
}

for _lettera, (_forma, _osservazione) in CAROLINA_LETTERE_EXTRA.items():
    CAROLINA_LETTERE[_lettera] = {
        "forma": _forma,
        "osservazione": _osservazione,
        "esercizio": [
            "Individua almeno tre occorrenze della lettera nel foglio campione e confrontane le varianti.",
            "Ricostruisci il contorno distinguendo ciò che è visibile da ciò che ipotizzi sul movimento della penna.",
            "Confronta altezza, larghezza, terminali e rapporto con le lettere vicine."
        ]
    }

# Note individuali per lettere-spia della Textura: descrivono tratti diagnostici
# del sistema gotico documentato da Ad fontes, non un alfabeto vettoriale completo.
TEXTURA_LETTERE = {
    "a": ("Corpo compatto con forme spezzate e spesso occhiello superiore/inferiore secondo la variante.", "Confrontare l'allografo della a nel foglio; non dedurlo da una blackletter digitale."),
    "d": ("Asta ascendente e corpo angoloso; il raccordo dell'arco è spezzato.", "Osservare il punto di rottura dell'arco e il rapporto tra asta e corpo."),
    "e": ("Corpo stretto con traversa e arco gotico.", "Misurare apertura interna e forma del tratto mediano."),
    "f": ("Asta alta e tratto mediano; nella textualis la f può restare sulla linea di base senza discendente.", "Distinguere la forma specifica della textura dalla bastarda e dalla corsiva."),
    "g": ("Struttura a più elementi, con forma e raccordi dipendenti dalla mano.", "Rilevare occhielli e discendente direttamente sul testimone."),
    "i": ("Minimo verticale che partecipa al ritmo serrato della trama; il punto può mancare nei testimoni antichi.", "Contare i minimi nelle sequenze e valutare i segni distintivi effettivamente presenti."),
    "m": ("Sequenza serrata di minimi, con archi spezzati e giunzioni angolose.", "Misurare il passo dei minimi e la regolarità della trama."),
    "n": ("Due minimi ravvicinati, con arco spezzato.", "Confrontare n, m e u: in Textura le sequenze possono essere ambigue."),
    "o": ("Ovale gotico con possibili spezzature nei raccordi.", "Confrontare la rottura dell'arco con la più rotonda Rotunda."),
    "r": ("Spalla breve e varianti contestuali dopo lettere tonde.", "Registrare le varianti posizionali nella parola, non isolare una sola forma."),
    "s": ("La s lunga è caratteristica in molte posizioni; distinguere la forma finale.", "Annotare posizione iniziale, mediana e finale nel campione."),
    "u": ("Minimi e archi possono confondersi con i, n e m nella trama compatta.", "Leggere gruppi di lettere e non soltanto il glifo isolato.")
}

UMANISTICA_LETTERE = {
    "a": ("a di impianto carolino, normalmente a due elementi; verificare proporzioni e attacco nella mano campione.", "Confronta larghezza, asse e forma dell'occhiello con o ed e."),
    "b": ("Asta ascendente e occhiello nella fascia mediana.", "Misura l'asta rispetto al corpo e osserva il raccordo dell'occhiello."),
    "c": ("Curva aperta con terminali relativamente netti.", "Confronta apertura e terminali con e e o."),
    "d": ("Asta ascendente con corpo tondeggiante; registrare l'allografo del testimone.", "Confronta altezza e inclinazione dell'asta con b e h."),
    "e": ("Corpo tondeggiante con tratto mediano; apertura da rilevare sul foglio.", "Misura traversa e apertura, senza regolarizzare il glifo."),
    "f": ("Asta alta e traversa; forma distinta dalla s lunga.", "Confronta altezza, traversa e terminali con s lunga."),
    "g": ("Forma a due elementi con parte inferiore; varianti da rilevare nel testimone.", "Osserva occhiello, raccordo e coda in più occorrenze."),
    "h": ("Asta ascendente e spalla arcuata, di impianto carolino.", "Confronta spalla e passo dei minimi con n e m."),
    "i": ("Minimo semplice; la presenza del punto va verificata nel manoscritto.", "Non aggiungere il punto moderno senza attestazione."),
    "j": ("Non sempre distinta da i nei testimoni quattrocenteschi.", "Registrare la convenzione ortografica del codice prima di creare un glifo autonomo."),
    "k": ("Asta e bracci obliqui; lettera rara in molti testi latini.", "Usare soltanto una forma attestata nel testimone."),
    "l": ("Asta ascendente semplice, di norma non ansata nella forma libraria regolare.", "Misura altezza e terminale rispetto a b, h e d."),
    "m": ("Minimi regolari e archi arrotondati.", "Misura il passo dei minimi e confronta con n."),
    "n": ("Due minimi con spalla arcuata.", "Confronta altezza, larghezza e raccordi con m e u."),
    "o": ("Corpo ovale, non un cerchio geometrico.", "Misura asse e larghezza confrontando c, e e a."),
    "p": ("Corpo nella fascia mediana e asta discendente.", "Misura la discesa rispetto all'altezza del corpo."),
    "q": ("Corpo tondeggiante con asta discendente.", "Rileva lato, direzione e terminale nel testimone."),
    "r": ("Spalla breve; possono comparire varianti contestuali.", "Confronta r ordinaria e allografi dopo lettere tonde."),
    "s": ("Distinguere s lunga e s finale; la lunga compare in posizioni non finali.", "Raccogli esempi iniziali, mediani e finali, annotando legature."),
    "t": ("t relativamente corta rispetto alle aste ascendenti maggiori.", "Misura l'altezza e la traversa nel modello, senza assumerne il valore universale."),
    "u": ("Forma arrotondata; la distinzione da v dipende dalla convenzione del testo.", "Verifica uso e forma nel contesto ortografico."),
    "v": ("Allografo da confrontare con u; non imporre la distinzione moderna.", "Registra distribuzione e forma effettiva nel codice."),
    "w": ("Grafema non ordinario nel latino librario del modello; inserirlo solo se compare nel testo o in una sezione volgare.", "Non ricavare la w da due v moderne: documentare l'eventuale forma attestata nel testimone."),
    "x": ("Due tratti incrociati con proporzioni da rilevare.", "Osserva punto d'incrocio e terminali."),
    "y": ("Forma con discendente; coda variabile.", "Misura la discesa e confronta più occorrenze."),
    "z": ("Forma poco frequente, da verificare nel repertorio del testo.", "Non ricostruirla per analogia tipografica se non attestata.")
}

def scheda_lettera_storica(stile, lettera):
    """Restituisce note per le lettere delle scuole con repertorio disponibile."""
    nome = str(stile).casefold()
    ch = str(lettera).lower()
    if "carolina" in nome and ch.isalpha():
        return scheda_lettera_carolina(ch)
    if ("textura" in nome or "textualis" in nome) and ch in TEXTURA_LETTERE:
        forma, osservazione = TEXTURA_LETTERE[ch]
        return {"forma": forma, "osservazione": osservazione, "esercizio": [
            "Confronta almeno tre occorrenze della lettera nel manoscritto di riferimento.",
            "Segna gli archi spezzati, i minimi, gli attacchi e i terminali osservabili.",
            "Solo dopo il confronto prepara il tracciato vettoriale della variante scelta."
        ]}
    if "rotunda" in nome and ch in ROTUNDA_LETTERE:
        forma, osservazione = ROTUNDA_LETTERE[ch]
        return {"forma": forma, "osservazione": osservazione, "esercizio": [
            "Confronta almeno tre occorrenze nel testimone italiano indicato.",
            "Rileva rotondità, minimi, eventuali piedi, aste e discendenti.",
            "Disegna una variante documentata e annota le differenze rispetto alla Textura."
        ]}
    if ("canceller" in nome or "italica" in nome or "italic" in nome) and ch in CANCELLERESCA_LETTERE:
        forma, osservazione = CANCELLERESCA_LETTERE[ch]
        return {"forma": forma, "osservazione": osservazione, "esercizio": [
            "Confronta la lettera con le tavole della Operina di Ludovico degli Arrighi (1522) e con un esemplare manoscritto coevo.",
            "Registra inclinazione, rapporto tra corpo e aste, attacchi e uscite; non assumere un angolo unico per tutte le mani.",
            "Distingui la forma attestata dal ductus didattico ricostruito: verifica ordine e continuità dei tratti su più esempi."
        ]}
    punta = scheda_lettera_punta_flessibile(stile, ch)
    if punta:
        return punta
    if "umanistic" in nome and ch in UMANISTICA_LETTERE:
        forma, osservazione = UMANISTICA_LETTERE[ch]
        return {"forma": forma, "osservazione": osservazione, "esercizio": [
            "Confronta almeno tre occorrenze nel British Library, Add MS 15246, fol. 29.",
            "Registra s lunga/finale, t corta, legature e convenzioni i/j e u/v.",
            "Disegna il glifo solo dopo aver verificato la forma effettiva sul facsimile."
        ]}
    return None


# Estensione della Textura all'alfabeto latino minuscolo. Le descrizioni sono
# criteri di lettura del testimone, non coordinate o ductus copiati dal copista.
TEXTURA_LETTERE_EXTRA = {
    "b": ("Asta ascendente alta e corpo angoloso; l'occhiello va confrontato nella mano scelta.", "Misura l'asta rispetto al corpo e osserva se il raccordo superiore è spezzato."),
    "c": ("Curva aperta con terminali angolosi o più netti rispetto alla Carolina.", "Confronta apertura e terminali con e, o e t."),
    "h": ("Asta ascendente e spalla formata da arco spezzato.", "Rileva il punto di cambio direzione e confronta la spalla con n e m."),
    "l": ("Asta ascendente generalmente stretta, integrata nel ritmo verticale.", "Confronta altezza e terminale con b, h e d."),
    "p": ("Asta discendente con corpo nella fascia mediana.", "Misura la discesa e registra la forma dell'occhiello nel testimone."),
    "q": ("Corpo compatto e asta discendente; forma e lato vanno verificati sul foglio.", "Non assumere una q tipografica: osserva attacco e terminale."),
    "t": ("Asta che supera il corpo con traversa breve; proporzioni variabili.", "Misura quota e posizione della traversa nel campione."),
    "v": ("Può condividere forme con u; il valore grafico dipende dalla convenzione del manoscritto.", "Osserva la distinzione u/v nel contesto, senza modernizzarla."),
    "x": ("Due tratti incrociati con angoli e spessori da rilevare.", "Segna punto d'incrocio, ordine apparente e terminali."),
    "y": ("Forma con elemento discendente, da distinguere dagli allografi locali.", "Misura la coda e confronta più occorrenze."),
    "z": ("Lettera meno frequente, con forme variabili secondo luogo e periodo.", "Usa soltanto una forma attestata nel testimone o nel repertorio dichiarato.")
}
for _lettera, (_forma, _osservazione) in TEXTURA_LETTERE_EXTRA.items():
    TEXTURA_LETTERE[_lettera] = (_forma, _osservazione)

# Repertorio didattico per la Rotunda italiana: privilegia l'osservazione delle
# forme tonde e della distinzione dei minimi. La scheda non pretende di descrivere
# ogni variante regionale né di sostituire la lettura del Ms. Rh. 182, fol. 9r.
ROTUNDA_LETTERE = {
    "a": ("Corpo più arrotondato rispetto alla Textura; verificare allografo e apertura.", "Confronta le occorrenze e annota forma del corpo e attacco del secondo elemento."),
    "b": ("Asta ascendente e corpo tondeggiante, con raccordo meno rigido.", "Misura asta e corpo; osserva l'eventuale piede del minimo."),
    "c": ("Curva aperta e terminali arrotondati o smussati.", "Confronta apertura e terminali con e e o."),
    "d": ("Corpo tondeggiante e asta ascendente; allografo da verificare.", "Osserva lato e andamento dell'asta nel testimone."),
    "e": ("Corpo arrotondato con traversa interna; apertura variabile.", "Misura la traversa e confronta l'apertura con c."),
    "f": ("Asta alta con traversa; nella textualis f resta sulla linea di base.", "Controlla la posizione del tratto e non attribuire discendenti senza evidenza."),
    "g": ("Corpo superiore e parte inferiore da rilevare nella mano italiana scelta.", "Confronta occhielli, raccordi e discendente in più occorrenze."),
    "h": ("Asta ascendente e spalla più curva rispetto alla Textura.", "Confronta larghezza e arco con n e m."),
    "i": ("Minimo verticale; segni distintivi possono variare nei testimoni.", "Conta i minimi nelle sequenze e leggi le lettere nel contesto."),
    "l": ("Asta ascendente semplice, integrata nel ritmo librario.", "Confronta terminale e altezza con b, h e d."),
    "m": ("Minimi distinti, con curve meno spezzate e ritmo regolare.", "Osserva eventuali piedi dei minimi e confronta con n."),
    "n": ("Due minimi con arco più arrotondato rispetto alla Textura.", "Rileva la forma del piede iniziale e del terminale finale."),
    "o": ("Corpo ovale o tondeggiante, elemento diagnostico della Rotunda.", "Misura asse e larghezza; non imporre un cerchio geometrico."),
    "p": ("Asta discendente con corpo arrotondato.", "Misura la discesa rispetto al corpo e la forma dell'occhiello."),
    "q": ("Corpo arrotondato con asta discendente.", "Registra direzione e terminale della discendente."),
    "r": ("Spalla breve; possono esistere varianti contestuali.", "Confronta r ordinaria e forme posizionali dopo lettere tonde."),
    "s": ("Distinguere s lunga e s finale; la forma dipende dalla posizione.", "Raccogli esempi iniziali, mediani e finali."),
    "t": ("Asta moderatamente ascendente con traversa breve.", "Misura quota e posizione della traversa."),
    "u": ("Minimi con andamento arrotondato; distinzione da v da verificare.", "Leggi la convenzione grafica nel contesto del testo."),
    "v": ("Allografo da confrontare con u, non da modernizzare automaticamente.", "Registra distribuzione e forma effettiva nel testimone."),
    "x": ("Due tratti incrociati, con proporzioni proprie della mano.", "Confronta incrocio e terminali con il facsimile."),
    "y": ("Forma con discendente; coda e raccordo variano.", "Misura la discesa e confronta più occorrenze."),
    "z": ("Forma poco frequente e potenzialmente variabile.", "Documenta l'allografo solo se attestato nel testimone scelto.")
}

# Schede per le maiuscole gotiche. Nei manoscritti le iniziali possono essere
# versali, capitali, onciali o iniziali decorate: la categoria va scelta dal
# foglio campione e non dedotta dalla sola forma alfabetica moderna.
MAIUSCOLE_GOTICHE = {
    "textura": {
        "A": "Capitale/versale da confrontare con il repertorio Textura; osservare aste, vertice e terminali.",
        "B": "Rilevare fusto e occhielli; non uniformare le due curve.",
        "C": "Curva aperta: misurare orientamento e terminali.",
        "D": "Fusto e curva esterna; controllare rapporto larghezza/altezza.",
        "E": "Fusto e bracci; osservare lunghezze e grazie.",
        "F": "Fusto e bracci; distinguere capitale corrente da iniziale decorata.",
        "G": "Curva e tratto interno; verificare la variante sul testimone.",
        "H": "Due aste e traversa; misurare quota e spessore.",
        "I": "Asta semplice o capitale con terminali secondo il repertorio.",
        "J": "Non introdurre come lettera autonoma senza attestazione nel repertorio scelto.",
        "K": "Asta e diagonali; verificare frequenza e forma nel testo.",
        "L": "Asta e base; osservare eventuali piedi.",
        "M": "Aste e diagonali; confrontare larghezza e vertici interni.",
        "N": "Due aste e diagonale; misurare inclinazione.",
        "O": "Ovale o forma poligonale; confrontare con la mano e il ductus del foglio.",
        "P": "Fusto e occhiello superiore; verificare proporzioni.",
        "Q": "Ovale e coda; rilevare direzione e innesto.",
        "R": "Fusto, occhiello e gamba; osservare il punto di innesto.",
        "S": "Curva superiore e inferiore; evitare simmetria tipografica automatica.",
        "T": "Asta e traversa; misurare centratura.",
        "U": "Curva inferiore; controllare se il testimone distingue U/V.",
        "V": "Forma angolare o arrotondata secondo la capitale attestata.",
        "W": "Sequenza di due V; usare solo se presente nel repertorio del testo.",
        "X": "Diagonali incrociate; osservare ordine e sovrapposizione.",
        "Y": "Aste superiori e discendente; misurare il raccordo.",
        "Z": "Forma poco frequente: documentarla soltanto se attestata."
    },
    "rotunda": {
        "A": "Versale o capitale del libro; osservare proporzioni e terminali più morbidi, se attestati.",
        "B": "Curva degli occhielli da rilevare sul foglio, senza imporre simmetria.",
        "C": "Curva ampia; annotare apertura e terminali.",
        "D": "Fusto e curva; misurare larghezza e asse.",
        "E": "Bracci e fusto; osservare eventuali grazie arrotondate.",
        "F": "Bracci e fusto; distinguere capitale corrente e iniziale.",
        "G": "Curva con tratto interno; verificare il modello locale.",
        "H": "Aste e traversa; osservare il contrasto del pennino.",
        "I": "Asta semplice o capitale con terminali secondo il testimone.",
        "J": "Non presupporre una J autonoma nei repertori medievali latini.",
        "K": "Asta e diagonali; verificare attestazione.",
        "L": "Asta e base; osservare terminali e proporzioni.",
        "M": "Aste e diagonali; misurare la larghezza effettiva.",
        "N": "Aste e diagonale; osservare inclinazione.",
        "O": "Ovale ampio o arrotondato; non costruirlo come cerchio perfetto.",
        "P": "Fusto e occhiello; verificare forma della curva.",
        "Q": "Ovale e coda; annotare il raccordo.",
        "R": "Occhiello e gamba; misurare punto di innesto.",
        "S": "Curve non necessariamente simmetriche; rilevare gli assi.",
        "T": "Traversa e asta; osservare centratura.",
        "U": "Curva inferiore; controllare convenzioni U/V.",
        "V": "Forma e terminali da rilevare nel repertorio capitale associato.",
        "W": "Usare soltanto se attestata nella pagina o nel repertorio scelto.",
        "X": "Incrocio e terminali da misurare sul foglio.",
        "Y": "Raccordo delle aste e discendente da osservare.",
        "Z": "Non ricostruire per analogia se non attestata."
    }
}

def scheda_maiuscola_storica(stile, lettera):
    """Nota prudente per maiuscole Textura/Rotunda: guida all'osservazione, non glifo."""
    nome = str(stile).casefold()
    ch = str(lettera).upper()
    famiglia = "textura" if ("textura" in nome or "textualis" in nome) else ("rotunda" if "rotunda" in nome else None)
    if not famiglia or ch not in MAIUSCOLE_GOTICHE[famiglia]:
        return None
    forma = MAIUSCOLE_GOTICHE[famiglia][ch]
    return {
        "forma": forma,
        "osservazione": "Le maiuscole non costituiscono un alfabeto uniforme della minuscola: nel foglio possono alternarsi versali, capitali, onciali e iniziali decorate. Identificare prima la categoria e poi confrontare le occorrenze.",
        "esercizio": [
            "Individua la maiuscola nel manoscritto di riferimento o in un repertorio coevo esplicitamente dichiarato.",
            "Registra altezza, larghezza, terminali, contrasto del tratto e rapporto con la minuscola della stessa pagina.",
            "Non usare il maiuscolo moderno come modello sostitutivo: salva la forma solo dopo averne verificato l'attestazione."
        ]
    }

# Repertorio introduttivo Bastarda: tratti distintivi da verificare sul Ms. C 168,
# fol. 17r. Non attribuisce coordinate né una sequenza di penna non documentata.
BASTARDA_LETTERE = {
    "a": ("Corpo curvilineo con possibile attacco obliquo; varianti di occhiello secondo la mano.", "Confronta a iniziale, mediana e finale; annota inclinazione e terminale."),
    "b": ("Asta ascendente spesso inclinata; possibile tratto d'attacco o occhiello variabile.", "Misura asta e corpo e verifica se compare una forma ad ansa."),
    "c": ("Curva aperta, talvolta con terminale appuntito.", "Confronta apertura e terminale con e e o."),
    "d": ("Asta ascendente e corpo; l'allografo dipende dalla mano.", "Verifica inclinazione, attacco e raccordo."),
    "e": ("Corpo curvo con traversa; può mostrare attacchi obliqui.", "Confronta traversa e apertura in più occorrenze."),
    "f": ("Asta alta con tratto discendente caratteristico in molte mani bastarde.", "Misura la discesa e confronta con la s lunga."),
    "g": ("Forma a più elementi, con occhiello e coda variabili.", "Rileva separazione, legature e andamento della coda."),
    "h": ("Asta ascendente e spalla; possibili attacchi obliqui o anse.", "Confronta altezza e inclinazione con b e l."),
    "i": ("Minimo spesso inclinato e integrato nel ritmo corsivo.", "Osserva segni distintivi e legature nel contesto."),
    "j": ("Non sempre distinta da i nei testimoni medievali.", "Usala solo se il repertorio ortografico del testimone la distingue."),
    "k": ("Asta e bracci obliqui, con frequenza dipendente dal testo.", "Rileva forma e attestazione nel foglio."),
    "l": ("Asta ascendente, talvolta con ansa o tratto d'attacco.", "Misura altezza e osserva l'eventuale legatura."),
    "m": ("Minimi più fluidi, talvolta collegati o con tratti obliqui.", "Confronta numero dei minimi, ritmo e raccordi."),
    "n": ("Minimi e spalla con andamento meno rigido della Textura.", "Osserva attacco e uscita, specialmente nelle legature."),
    "o": ("Corpo curvo, spesso con attacco obliquo o punta superiore.", "Misura asse e rapporto altezza/larghezza."),
    "p": ("Corpo mediano con asta discendente evidente.", "Misura la discendente e osserva il raccordo."),
    "q": ("Corpo con asta discendente; orientamento da verificare.", "Confronta con p e annota il terminale."),
    "r": ("Spalla breve, con varianti posizionali.", "Confronta r dopo lettere tonde e in posizione iniziale."),
    "s": ("Distinguere s lunga e s finale; la lunga può avere discendente.", "Registra posizione e lunghezza dell'asta."),
    "t": ("Asta con traversa; terminali e altezza variabili.", "Misura la traversa e osserva la forma finale di parola."),
    "u": ("Minimi con raccordi corsivi; convenzione u/v da verificare.", "Leggi la distinzione nel contesto ortografico."),
    "v": ("Può alternare con u secondo la convenzione del manoscritto.", "Non imporre valori moderni senza attestazione."),
    "w": ("Sequenza rara nel latino librario, più probabile in testi volgari.", "Verifica che sia presente nel testo e come viene costruita."),
    "x": ("Tratti incrociati con raccordi variabili.", "Osserva ordine e sovrapposizione."),
    "y": ("Forma con discendente e coda variabile.", "Misura discesa e raccordo."),
    "z": ("Forma poco frequente e dipendente dal repertorio linguistico.", "Usa solo una forma attestata nel testimone.")
}

def scheda_lettera_bastarda(lettera):
    dato = BASTARDA_LETTERE.get(str(lettera).lower())
    if not dato:
        return None
    forma, osservazione = dato
    return {"forma": forma, "osservazione": osservazione, "esercizio": [
        "Confronta almeno tre occorrenze nel Livre d'heures, Ms. C 168, fol. 17r, quando disponibili.",
        "Annota inclinazione, legature, attacchi, discendenti e differenze di posizione.",
        "Separa la forma osservata dal percorso di penna ipotizzato: il ductus va verificato con più esemplari e manuali coevi."
    ]}


# Repertorio prudente per la Cancelleresca/Italica: descrive aspetti da
# verificare sulle tavole dell'Arrighi, senza fingere coordinate o ductus estratti.
CANCELLERESCA_LETTERE = {
    "a": ("Corpo ovale con attacco e uscita corsivi; forma e apertura da confrontare con la tavola.", "Confronta a isolata e in legatura; misura asse, inclinazione e terminale."),
    "b": ("Asta ascendente con corpo mediano; ansa e attacco dipendono dal modello inciso.", "Rileva altezza dell'asta e rapporto con il corpo."),
    "c": ("Curva aperta con terminali orientati secondo la mano.", "Confronta apertura, asse e collegamento alla lettera seguente."),
    "d": ("Corpo ovale e asta ascendente; osservare se l'asta è diritta o inclinata.", "Misura l'asta rispetto al corpo e registra l'attacco."),
    "e": ("Corpo corsivo con traversa e uscita; non ridurlo a un ovale tipografico.", "Osserva traversa, apertura e legature frequenti."),
    "f": ("Asta alta con traversa e possibile sviluppo discendente secondo la forma scelta.", "Verifica quota della traversa e terminale sul modello."),
    "g": ("Corpo superiore e sviluppo inferiore da rilevare nella variante dell'esemplare.", "Confronta occhiello, coda e continuità del gesto."),
    "h": ("Asta ascendente e spalla corsiva con raccordi fluidi.", "Misura asta, spalla e uscita rispetto a n e m."),
    "i": ("Minimo inclinato; punto e segni distintivi dipendono dalla convenzione della tavola.", "Registra altezza e posizione del punto, se presente."),
    "j": ("Variante di i da trattare secondo il repertorio ortografico adottato.", "Non introdurre una distinzione moderna senza riscontro."),
    "k": ("Asta con bracci obliqui, da osservare nella tavola originale.", "Rileva proporzioni e ordine apparente degli elementi."),
    "l": ("Asta ascendente slanciata con terminali calligrafici.", "Confronta altezza, inclinazione e uscita con b e h."),
    "m": ("Sequenza di minimi collegati con ritmo corsivo.", "Misura passo dei minimi e larghezza complessiva."),
    "n": ("Due minimi con spalla e uscita corsiva.", "Confronta ritmo e raccordi con m e u."),
    "o": ("Corpo ovale inclinato, non necessariamente simmetrico.", "Rileva asse e contrasto del tratto sul facsimile."),
    "p": ("Corpo mediano con asta discendente.", "Misura la discesa e il raccordo inferiore."),
    "q": ("Corpo ovale con asta discendente e terminale variabile.", "Confronta con p e verifica la direzione della coda."),
    "r": ("Spalla breve con terminale e uscita corsivi.", "Confronta le forme dopo lettere tonde e in inizio parola."),
    "s": ("Distinguere s lunga e s finale secondo posizione e modello.", "Registra gli allografi e la loro distribuzione nel testo."),
    "t": ("Asta e traversa con altezza e terminali da misurare.", "Confronta t mediana e finale, se entrambe attestate."),
    "u": ("Minimi raccordati; convenzione u/v da verificare nel testo.", "Osserva forma e distribuzione contestuale."),
    "v": ("Forma affine a u, distinta secondo convenzioni storiche variabili.", "Non imporre la distinzione ortografica moderna."),
    "w": ("Grafema non sempre presente nei repertori latini del periodo.", "Inserire soltanto se attestato nella lingua e nella tavola adottata."),
    "x": ("Tratti incrociati con contrasto e terminali da osservare.", "Rileva incrocio e sequenza del gesto senza presumere il ductus."),
    "y": ("Forma con elemento discendente e coda variabile.", "Misura discesa e terminale nella tavola scelta."),
    "z": ("Forma poco frequente, dipendente dal repertorio linguistico.", "Usare soltanto una variante attestata nel testimone."),
}

# Maiuscole della Cancelleresca: repertorio di osservazione riferito alle tavole
# di Ludovico degli Arrighi, La Operina (Roma, 1522). Non sostituisce il facsimile.
CANCELLERESCA_MAIUSCOLE = {
    "A": "Versale inclinata: confrontare asta, diagonale e traversa con la tavola dell'Arrighi.",
    "B": "Fusto e due curve: rilevare se gli occhielli sono continui o separati.",
    "C": "Curva aperta con terminali calligrafici; misurare asse e apertura.",
    "D": "Fusto e curva ampia; verificare l'inclinazione complessiva.",
    "E": "Fusto e bracci; osservare differenze di lunghezza e terminali.",
    "F": "Fusto e bracci; non confondere la versale con un'iniziale ornata.",
    "G": "Curva con tratto interno; registrare il raccordo effettivo.",
    "H": "Aste e traversa; misurare la quota della traversa.",
    "I": "Asta con eventuali terminali; verificare la variante incisa.",
    "J": "Non presumere una J autonoma: verificare la convenzione del repertorio.",
    "K": "Fusto e diagonali; osservare punto d'innesto e andamento dei bracci.",
    "L": "Fusto e base; confrontare terminali e inclinazione.",
    "M": "Sequenza di aste e diagonali; misurare larghezza e vertici.",
    "N": "Due aste e diagonale; osservare inclinazione e raccordi.",
    "O": "Ovale calligrafico; non trasformarlo in un'ellisse geometrica perfetta.",
    "P": "Fusto e occhiello; verificare la proporzione rispetto all'altezza.",
    "Q": "Ovale e coda; rilevare direzione e punto di innesto.",
    "R": "Occhiello e gamba; osservare il punto in cui nasce la diagonale.",
    "S": "Curve superiore e inferiore; rilevare contrasto e terminali.",
    "T": "Asta e traversa; osservare centratura e terminali.",
    "U": "Curva inferiore; verificare se il repertorio distingue U e V.",
    "V": "Diagonali o forma arrotondata secondo la tavola: registrare l'allografo.",
    "W": "Usare soltanto se attestata nella tavola o nel testo di riferimento.",
    "X": "Incrocio delle diagonali; osservare ordine apparente e sovrapposizione.",
    "Y": "Aste superiori e coda; misurare il raccordo.",
    "Z": "Forma rara nel repertorio latino: documentare solo se presente."
}

def scheda_maiuscola_cancelleresca(lettera):
    ch = str(lettera).upper()
    forma = CANCELLERESCA_MAIUSCOLE.get(ch)
    if not forma:
        return None
    return {
        "forma": forma,
        "osservazione": "Riferimento: Ludovico degli Arrighi, La Operina (Roma, 1522). Le maiuscole vanno rilevate sulle tavole originali: la descrizione è una guida all'osservazione, non un glifo vettoriale trascritto.",
        "esercizio": [
            "Individua la forma nella tavola originale e annota pagina/tavola e variante.",
            "Misura altezza, larghezza, inclinazione, contrasto e terminali rispetto alla minuscola.",
            "Disegna il contorno osservato separatamente dal percorso di penna ipotizzato; non dichiarare il ductus certo senza una fonte esplicita."
        ]
    }

# Tavole didattiche per le scritture a punta flessibile.
# Le descrizioni sono criteri di lettura, non tracciati estratti dai manuali.
ATLANTE_STORICO.update({
    "copperplate": {
        "nome": "Copperplate / English Roundhand",
        "esemplare": "George Bickham, The Universal Penman, Londra, 1733–1741; selezionare una tavola e una singola mano prima della vettorializzazione.",
        "url": "https://archive.org/search?query=George+Bickham+Universal+Penman",
        "osservabili": [
            "contrasto fra tratti fini ascendenti e tratti pieni discendenti prodotto dalla flessione del pennino",
            "asse inclinato e ovali coerenti nella stessa mano",
            "legature corsive e raccordi continui, con varianti fra copisti e tavole",
            "maiuscole ornate spesso più elaborate e non proporzionali alle minuscole"
        ],
        "lettere_spia": ["o", "a", "d", "p", "t", "r", "s", "f"],
        "maiuscole": "Studiare le maiuscole direttamente nella tavola selezionata: sono forme calligrafiche ornamentali, non capitali semplicemente ingrandite.",
        "strumento": "Pennino flessibile appuntito; la modulazione dipende dalla pressione. Una tavoletta grafica può simulare la pressione, il mouse no.",
        "misure": "Rilevare asse, rapporto pieno/fino, altezza, larghezza degli ovali e spaziature nella tavola specifica; non imporre un rapporto universale.",
        "stato": "Manuale storico identificato; scegliere tavola e mano prima di tracciare glifi vettoriali fedeli."
    },
    "spencerian": {
        "nome": "Spencerian",
        "esemplare": "Platt Rogers Spencer, Spencerian Key to Practical Penmanship, edizioni ottocentesche; confrontare una specifica edizione digitalizzata prima di fissare i modelli.",
        "url": "https://archive.org/search?query=Platt+Rogers+Spencer+Spencerian+Key",
        "osservabili": [
            "movimento leggero e ritmico, con ovali e raccordi fluidi",
            "contrasto controllato tramite pressione del pennino flessibile",
            "inclinazione e spaziatura regolari ma dipendenti dalla tavola e dal livello didattico",
            "maiuscole ornamentali con svolazzi che vanno separati dalle forme di base"
        ],
        "lettere_spia": ["i", "u", "n", "m", "o", "a", "r", "s"],
        "maiuscole": "Distinguere le maiuscole di esercizio dalle varianti ornamentali; trascrivere solo quelle mostrate nella tavola scelta.",
        "strumento": "Pennino flessibile appuntito; la pressione è parte essenziale del ductus e richiede input sensibile alla pressione per una simulazione realistica.",
        "misure": "Misurare inclinazione, altezza, larghezza, spaziatura e rapporto fra tratti pieni e fini sull'esemplare scelto.",
        "stato": "Manuale storico identificato a livello bibliografico; occorre selezionare edizione e tavola per la trascrizione puntuale."
    }
})

PUNTA_FLESSIBILE_LETTERE = {
    "copperplate": {
        "o": ("Ovale inclinato, con tratto fine in salita e pieno in discesa.", "Osserva asse, chiusura e distribuzione del contrasto nella stessa tavola."),
        "a": ("Ovale con attacco e uscita corsivi; la forma dipende dalla mano incisa.", "Confronta attacco, occhiello e raccordo con o e d."),
        "d": ("Ovale con asta ascendente sottile e raccordo corsivo.", "Misura altezza dell'asta e continuità del raccordo senza uniformare le varianti."),
        "p": ("Asta discendente con occhiello e modulazione pieno/fino.", "Osserva la discesa e il punto in cui la pressione produce il tratto pieno."),
        "t": ("Asta relativamente alta con traversa; forma e posizione variano per mano.", "Rileva altezza, traversa e uscita nella tavola scelta."),
        "r": ("Spalla breve e raccordo corsivo, spesso utile per leggere il ritmo.", "Confronta r in contesto iniziale e mediano."),
        "s": ("Curva corsiva con contrasto modulato; varianti di forma e posizione.", "Non assumere un'unica s: confronta occorrenze e legature."),
        "f": ("Asta alta con occhiello o svolazzo secondo la mano.", "Distingui il corpo della lettera dagli ornamenti e dalle legature.")
    },
    "spencerian": {
        "i": ("Minimo leggero con entrata e uscita ritmiche.", "Osserva il ritmo dei minimi e il punto, se presente nella tavola."),
        "u": ("Sequenza di minimi e raccordi continui.", "Confronta passo e spaziatura con n e w."),
        "n": ("Due minimi raccordati con andamento fluido.", "Misura altezza e larghezza del gruppo, non il singolo tratto isolato."),
        "m": ("Tre minimi raccordati, con ritmo regolare.", "Confronta il passo dei minimi con n e u."),
        "o": ("Ovale inclinato, costruito con gesto leggero e pressione selettiva.", "Rileva asse e rapporto fra tratti pieni e fini."),
        "a": ("Ovale con uscita corsiva e legatura alla lettera seguente.", "Confronta forma isolata e forma legata nel modello."),
        "r": ("Spalla compatta e raccordo leggero.", "Osserva la continuità del gesto e lo spazio successivo."),
        "s": ("Curva fluida con varianti secondo la posizione.", "Confronta forma iniziale, mediana e finale nella tavola.")
    }
}


def scheda_lettera_punta_flessibile(stile, lettera):
    """Restituisce note morfologiche prudenti per Copperplate e Spencerian."""
    nome = str(stile).casefold()
    chiave = "copperplate" if ("copper" in nome or "roundhand" in nome) else "spencerian" if "spencerian" in nome else None
    if not chiave:
        return None
    dato = PUNTA_FLESSIBILE_LETTERE.get(chiave, {}).get(str(lettera).lower())
    if not dato:
        return None
    forma, osservazione = dato
    return {
        "forma": forma,
        "osservazione": osservazione,
        "esercizio": [
            "Confronta almeno tre occorrenze nella medesima tavola del manuale storico selezionato.",
            "Segna asse, proporzioni, tratti fini e pieni, attacchi e uscite; non dedurre la pressione dal solo contorno.",
            "Ricostruisci il ductus come ipotesi didattica e annota quali passaggi sono direttamente osservabili."
        ]
    }

# DODICESIMA FASE — ONCIALE E FRAKTUR.
# Profili documentari: le note guidano il confronto con un testimone preciso;
# non sostituiscono la digitalizzazione dei glifi dal facsimile.
ATLANTE_STORICO.update({
    "onciale": {
        "nome": "Onciale latina",
        "esemplare": "Codex Bezae Cantabrigiensis, Cambridge University Library, Nn.2.41, manoscritto greco-latino del V secolo; per la componente latina confrontare il facsimile e distinguere mani e sezioni.",
        "url": "https://cudl.lib.cam.ac.uk/view/MS-NN-00002-00041",
        "osservabili": [
            "forme maiuscole librarie ampie e tendenzialmente arrotondate",
            "lettere come A, D, E, M e U con costruzioni caratteristiche rispetto alle capitali classiche",
            "contrasto e modulazione dipendenti dalla mano, dal supporto e dalla penna",
            "assenza di un sistema universale di ascendenti e discendenti come nella minuscola moderna"
        ],
        "lettere_spia": ["a", "d", "e", "g", "h", "m", "q", "u"],
        "maiuscole": "La scrittura onciale è essa stessa una maiuscola libraria; distinguere le forme onciali dalle capitali e dalle rubriche presenti nello stesso codice.",
        "strumento": "Penna larga; angolo, modulo e contrasto vanno misurati sulla pagina e sulla mano selezionate.",
        "misure": "Rilevare altezza, larghezza, asse, rapporto tra curve e tratti verticali e interlinea sul facsimile; non applicare automaticamente gradi della minuscola carolina.",
        "stato": "Testimone manoscritto identificato; le forme delle singole lettere vanno trascritte dal foglio e dalla sezione latina selezionati."
    },
    "fraktur": {
        "nome": "Fraktur tipografica e calligrafica",
        "esemplare": "Per la storia tipografica: forme Fraktur documentate nei libri a stampa tedeschi dal XVI secolo; per il ductus manoscritto occorre selezionare un manoscritto distinto, senza trattare il tipo mobile come gesto di penna.",
        "url": "https://www.gesamtkatalogderwiegendrucke.de/  ",
        "osservabili": [
            "contrasto fra aste spezzate e curve, con forme specifiche per lettere come a, e, g, h e s",
            "differenze sostanziali tra Fraktur tipografica, scrittura manoscritta gotica e calligrafia moderna ispirata alla Fraktur",
            "maiuscole spesso ornate e con struttura distinta dalle minuscole",
            "spessori e proporzioni del carattere a stampa dipendono dal disegno tipografico, non dalla pressione di un pennino"
        ],
        "lettere_spia": ["a", "e", "g", "h", "k", "s", "t", "x"],
        "maiuscole": "Le capitali Fraktur tipografiche vanno studiate nel carattere e nell'edizione scelti; non vanno presentate come maiuscole manoscritte universali.",
        "strumento": "Per il modello tipografico: analisi del carattere stampato. Per una reinterpretazione calligrafica: pennino largo, dichiarando che si tratta di adattamento moderno.",
        "misure": "Misurare altezza, larghezza, contrasto, spaziatura e forme di legatura nel tipo o nell'esemplare selezionato; non derivare misure di ductus da un carattere a stampa.",
        "stato": "Profilo tipografico-documentario introdotto; per il ductus manoscritto serve un testimone manoscritto autonomo."
    }
})

ONCIALE_LETTERE = {
    "a": ("Forma onciale con corpo arrotondato e struttura distinta dalla a carolina.", "Confronta le occorrenze nel medesimo foglio; registra apertura, asse e rapporto fra curva e tratto verticale."),
    "b": ("Corpo arrotondato con asta verticale; proporzioni da rilevare nella mano selezionata.", "Misura asta e corpo e verifica se l'asta supera il corpo o resta allineata."),
    "c": ("Curva aperta, spesso ampia; terminali e apertura variano secondo la mano.", "Confronta c con e e o e annota orientamento dei terminali."),
    "d": ("Forma onciale con asta e corpo curvo; non assumere la d carolina.", "Rileva lato e andamento dell'asta e il raccordo con il corpo."),
    "e": ("Forma arrotondata con tratto mediano; geometria da verificare sul testimone.", "Misura apertura e posizione del tratto mediano."),
    "f": ("Forma alta con traversa o tratto mediano; varianti dipendenti dalla mano.", "Confronta quota della traversa e terminali con le altre aste alte."),
    "g": ("Forma onciale caratteristica, spesso diversa dalla g minuscola carolina.", "Registra struttura, occhiello e sviluppo inferiore soltanto dove attestato."),
    "h": ("Asta verticale con arco o spalla; proporzioni da rilevare.", "Confronta altezza e curva con n e m."),
    "i": ("Tratto verticale semplice; segni distintivi dipendono dalla convenzione del codice.", "Rileva lunghezza e presenza di segni accessori nel contesto."),
    "j": ("Distinzione moderna non da presumere nel repertorio latino antico.", "Usa j solo se il testimone o la trascrizione editoriale giustificano la distinzione."),
    "k": ("Asta e bracci obliqui; forma e frequenza da verificare nel testo.", "Confronta i punti di innesto dei bracci sull'asta."),
    "l": ("Tratto verticale alto, generalmente semplice.", "Misura altezza e terminali rispetto alle altre lettere."),
    "m": ("Lettera ampia con sequenza di curve; evitare la m tipografica moderna.", "Confronta numero e andamento degli archi sul facsimile."),
    "n": ("Curva o arco con proporzioni da leggere nel rapporto con m.", "Rileva larghezza e andamento del raccordo."),
    "o": ("Forma arrotondata, non necessariamente un cerchio geometrico.", "Misura asse, larghezza e modulazione del tratto."),
    "p": ("Asta e corpo con sviluppo inferiore o laterale secondo la forma attestata.", "Non presumere una discendente moderna: osserva il disegno effettivo."),
    "q": ("Forma con corpo e tratto accessorio; varianti da verificare.", "Confronta orientamento e posizione del tratto accessorio."),
    "r": ("Asta con curva o spalla; forma da distinguere da n.", "Osserva attacco e terminale nella pagina campione."),
    "s": ("Forma di s antica, con varianti contestuali e posizionali.", "Registra forma iniziale, mediana e finale se presenti."),
    "t": ("Asta con tratto mediano; quota e orientamento variabili.", "Misura la traversa e confronta le occorrenze."),
    "u": ("Forma curva o a coppa; la distinzione u/v può non coincidere con quella moderna.", "Leggi il valore grafico nel contesto e non modernizzare automaticamente."),
    "v": ("Allografo da confrontare con u; non imporre la distinzione moderna.", "Registra distribuzione e forma effettiva nel codice."),
    "w": ("Grafema non ordinario nel latino del modello; usare solo se attestato.", "Non costruire w per duplicazione di v senza prova nel testimone."),
    "x": ("Due elementi incrociati; forma e terminali da rilevare.", "Segna punto d'incrocio e differenze di spessore."),
    "y": ("Grafema da verificare nel repertorio linguistico del codice.", "Usa soltanto una forma attestata nella pagina o in una sezione pertinente."),
    "z": ("Lettera poco frequente e dipendente dal testo.", "Non ricostruirla per analogia se non compare nel testimone.")
}

FRAKTUR_LETTERE = {
    "a": ("Forma Fraktur con struttura e occhiello spezzati o angolosi secondo il disegno tipografico.", "Confronta a nel carattere e nell'edizione scelti; non confonderla con la a manoscritta gotica."),
    "b": ("Asta alta e corpo con raccordi caratteristici del tipo.", "Misura corpo, asta e contrasto nel campione tipografico."),
    "c": ("Curva aperta con terminali e contrasto definiti dal carattere.", "Confronta c con e e o nel medesimo font."),
    "d": ("Forma con asta e corpo; il disegno varia fra caratteri Fraktur.", "Registra forma dell'asta e raccordo del corpo."),
    "e": ("Occhiello e traversa con costruzione tipografica specifica.", "Osserva apertura e terminali, evitando di dedurre il gesto dal solo contorno."),
    "f": ("Asta alta e traversa; può avere forma lunga in contesti storici.", "Distingui f lunga e f ordinaria secondo l'edizione."),
    "g": ("Forma a più elementi, con costruzione caratteristica del carattere.", "Confronta occhiello superiore e parte inferiore nel tipo selezionato."),
    "h": ("Asta alta e spalla angolosa o spezzata.", "Misura altezza, larghezza e forma della spalla."),
    "i": ("Tratto stretto con segno distintivo secondo il carattere.", "Rileva posizione del punto e spaziatura rispetto ai minimi."),
    "j": ("Variante di i da interpretare secondo l'ortografia dell'edizione.", "Non imporre una distinzione moderna a testi che non la adottano."),
    "k": ("Asta con bracci obliqui e giunzioni angolose.", "Osserva innesto e inclinazione dei bracci."),
    "l": ("Asta alta e stretta, con terminali propri del tipo.", "Confronta con b, h e k."),
    "m": ("Sequenza di minimi con ritmo serrato e forme angolose.", "Misura larghezza e passo dei minimi."),
    "n": ("Minimi e spalla con contrasto e giunzioni del carattere.", "Confronta con m e u."),
    "o": ("Ovale con contrasto tipografico; non necessariamente geometrico.", "Misura asse, larghezza e spessore apparente."),
    "p": ("Asta discendente e corpo; forma del terminale varia.", "Rileva proporzione e terminale nel carattere scelto."),
    "q": ("Corpo e tratto discendente o accessorio.", "Confronta orientamento e terminale con p."),
    "r": ("Spalla e terminale caratteristici, spesso compatti.", "Confronta r in differenti posizioni tipografiche."),
    "s": ("Distinguere s lunga e s finale nelle edizioni che le impiegano.", "Annota regole d'uso dell'edizione prima di disegnare entrambe."),
    "t": ("Asta con traversa e terminali specifici del tipo.", "Misura quota della traversa e larghezza."),
    "u": ("Forma curva con convenzioni storiche di u/v dipendenti dall'edizione.", "Controlla uso ortografico e forma del carattere."),
    "v": ("Forma da confrontare con u secondo convenzioni storiche.", "Non assumere la distribuzione moderna u/v."),
    "w": ("Grafema composto con disegno specifico del carattere.", "Misura larghezza e rapporto tra gli elementi."),
    "x": ("Incrocio di due elementi con terminali definiti dal tipo.", "Osserva il punto d'incrocio e il contrasto."),
    "y": ("Forma con discendente e terminale variabile.", "Misura la discesa e confronta più caratteri."),
    "z": ("Forma angolosa con terminali distintivi.", "Confronta asse e terminali nel font selezionato.")
}

# Estende il dispatcher mantenendo intatti i repertori precedenti.
_scheda_lettera_storica_precedente = scheda_lettera_storica
def scheda_lettera_storica(stile, lettera):
    nome = str(stile).casefold()
    ch = str(lettera).lower()
    famiglia = "onciale" if "oncial" in nome else "fraktur" if "fraktur" in nome else None
    repertorio = ONCIALE_LETTERE if famiglia == "onciale" else FRAKTUR_LETTERE if famiglia == "fraktur" else None
    if repertorio and ch in repertorio:
        forma, osservazione = repertorio[ch]
        return {
            "forma": forma,
            "osservazione": osservazione,
            "esercizio": [
                "Confronta almeno tre occorrenze nella stessa pagina o nello stesso carattere storico selezionato.",
                "Registra proporzioni, asse, terminali e varianti; per Fraktur tipografica non dedurre il ductus dalla forma stampata.",
                "Etichetta ogni ricostruzione come osservazione, adattamento didattico o ipotesi di ductus."
            ]
        }
    return _scheda_lettera_storica_precedente(stile, lettera)


def scheda_maiuscola_storica(stile, lettera):
    nome = str(stile).casefold()
    ch = str(lettera).upper()
    if "oncial" in nome:
        return {
            "forma": "Forma onciale maiuscola da confrontare con il facsimile selezionato; non è una maiuscola moderna semplicemente ingrandita.",
            "osservazione": "La scrittura onciale è una maiuscola libraria; nel codice possono coesistere capitali, rubriche e iniziali di altra tradizione.",
            "esercizio": ["Individua la lettera nel testimone latino e annota pagina e riga.", "Misura altezza, larghezza, asse e modulazione del tratto.", "Traccia il contorno solo dopo aver verificato la forma nel facsimile."]
        }
    if "fraktur" in nome:
        return {
            "forma": "Capitale Fraktur tipografica: forma da rilevare nel carattere e nell'edizione scelti.",
            "osservazione": "Le maiuscole Fraktur sono disegni tipografici specifici e spesso ornamentali; non costituiscono un modello universale di maiuscola manoscritta.",
            "esercizio": ["Identifica font, edizione e pagina del campione.", "Misura larghezza, altezza, contrasto e terminali.", "Se realizzi una versione a pennino, dichiarala adattamento calligrafico moderno."]
        }
    return None


# Tradizioni arabe: profili distinti, senza trasferire le categorie latine di
# ascendente/discendente o il ductus della punta larga. Le forme Unicode qui
# mostrate sono isolate; le forme contestuali e le legature richiedono un
# motore di shaping arabo e modelli tratti da un esemplare specifico.
ATLANTE_STORICO.update({
    "araba_naskh": {
        "nome": "Naskh",
        "esemplare": "Library of Congress, raccolta Arabic, Persian and Ottoman Calligraphy; scegliere un foglio Naskh catalogato prima della trascrizione esecutiva.",
        "url": "https://www.loc.gov/collections/selections-of-arabic-persian-and-ottoman-calligraphy/",
        "osservabili": ["scrittura corsiva con lettere collegate", "proporzioni e punti diacritici essenziali alla lettura", "forme contestuali iniziali, mediane, finali e isolate", "ritmo della linea e rapporto fra lettere e punti"],
        "lettere_spia": ["ب", "ج", "س", "ص", "ع", "م", "ن", "ي"],
        "maiuscole": "L'alfabeto arabo non distingue maiuscole e minuscole come quello latino.",
        "strumento": "Calamo (qalam); larghezza del taglio, angolo e inchiostro vanno osservati nel foglio scelto.",
        "misure": "Studiare altezza delle lettere rispetto al rombo-punto, linea di base, legature, punti diacritici e spaziatura; non usare x-height o ascender latini.",
        "stato": "Profilo introduttivo e repertorio alfabetico isolato; forme contestuali e ductus da trascrivere da un foglio catalogato."
    },
    "araba_kufico": {
        "nome": "Cufico (Kufic)",
        "esemplare": "Library of Congress, Qur'anic Fragments; la famiglia comprende varianti manoscritte e monumentali, da specificare per singolo foglio o iscrizione.",
        "url": "https://www.loc.gov/collections/selections-of-arabic-persian-and-ottoman-calligraphy/articles-and-essays/quranic-fragments/",
        "osservabili": ["struttura prevalentemente angolare in molte varianti", "proporzioni dipendenti dal supporto e dalla variante", "differenza fra scrittura manoscritta e composizione geometrica architettonica", "punti e segni vocalici non uniformi nei testimoni antichi"],
        "lettere_spia": ["ا", "ب", "ح", "د", "ر", "س", "ك", "م"],
        "maiuscole": "Non esistono maiuscole e minuscole nel senso latino.",
        "strumento": "Calamo o strumenti da iscrizione secondo il testimone; non presumere che ogni Cufico sia scritto con la stessa tecnica.",
        "misure": "Rilevare modulo, altezza, larghezza, spaziatura e geometria dal singolo esemplare; non applicare gradi latini.",
        "stato": "Profilo comparativo; occorre fissare una variante e un testimone prima di generare tracciati."
    },
    "araba_thuluth": {
        "nome": "Thuluth",
        "esemplare": "Library of Congress, raccolta Arabic, Persian and Ottoman Calligraphy Sheets; selezionare una tavola Thuluth specifica per la ricostruzione.",
        "url": "https://blogs.loc.gov/international-collections/2021/03/from-your-hand-to-heaven-arabic-persian-and-ottoman-calligraphy-sheets-at-the-library-of-congress/",
        "osservabili": ["lettere slanciate e composizione monumentale", "curve e terminali elaborati secondo la scuola", "punti diacritici e proporzioni geometriche", "composizione delle parole e bilanciamento dello spazio"],
        "lettere_spia": ["ا", "ل", "م", "ن", "و", "ه", "ي"],
        "maiuscole": "L'alfabeto arabo non ha distinzione maiuscolo/minuscolo.",
        "strumento": "Calamo con taglio e angolo specifici della scuola; rilevare le caratteristiche dalla tavola selezionata.",
        "misure": "Usare il rombo-punto, le proporzioni delle aste e la relazione tra lettere e composizione; non usare ascender e descender latini.",
        "stato": "Scheda introduttiva; il ductus esecutivo richiede una tavola specifica e l'analisi delle forme contestuali."
    }
})

ARABIC_ISOLATED = {
    "ا":"alif", "ب":"ba", "ت":"ta", "ث":"tha", "ج":"jim", "ح":"ha", "خ":"kha",
    "د":"dal", "ذ":"dhal", "ر":"ra", "ز":"zay", "س":"sin", "ش":"shin",
    "ص":"sad", "ض":"dad", "ط":"ta enfatica", "ظ":"za enfatica", "ع":"ayn", "غ":"ghayn",
    "ف":"fa", "ق":"qaf", "ك":"kaf", "ل":"lam", "م":"mim", "ن":"nun",
    "ه":"ha", "و":"waw", "ي":"ya"
}

def scheda_lettera_araba(stile, lettera):
    """Scheda prudente per il grafema arabo isolato selezionato."""
    if lettera not in ARABIC_ISOLATED:
        return None
    famiglia = "Naskh" if "naskh" in str(stile).casefold() else "Cufico" if "kuf" in str(stile).casefold() or "cuf" in str(stile).casefold() else "Thuluth"
    nome = ARABIC_ISOLATED[lettera]
    return {
        "forma": f"Grafema isolato {nome} ({lettera}) nel percorso {famiglia}; la forma cambia in posizione iniziale, mediana e finale.",
        "osservazione": "L'arabo si legge da destra a sinistra. I punti diacritici distinguono grafemi diversi; la connessione dipende dalla lettera e dalla posizione. Questa scheda non sostituisce un modello calligrafico contestuale.",
        "esercizio": [
            "Osserva il grafema isolato e individua le sue forme iniziale, mediana e finale in un testo dello stesso stile.",
            "Segna linea di base, proporzioni rispetto al rombo-punto, punti diacritici e legature.",
            "Esercitati nella direzione e nella sequenza dei tratti solo dopo aver scelto una tavola storica precisa; non applicare il ductus latino."
        ]
    }
