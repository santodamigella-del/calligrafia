"""Foglio di esercizi stampabile (senza dipendenze da Qt).

Costruisce pagine A4 (a 150 dpi: 1240×1754 px) come liste di PRIMITIVE di disegno:
    ("linea", x0, y0, x1, y1, colore, spessore, tratteggiata)
    ("poli",  [(x, y), ...], colore, spessore)
    ("riempi", [(x, y), ...], colore)
    ("testo", x, y, stringa, altezza_pixel, colore)
Chi disegna (Qt, PIL...) deve solo eseguirle: tutta la geometria è qui ed è verificabile.

Contenuto
* Alfabeti latino e arabo: righe con linea di base, altezza della x, linea delle ascendenti e delle
  discendenti, e linee dell'inclinazione dello stile; in ogni riga la lettera-modello in grigio da
  ricalcare (con la penna a punta larga simulata se lo stile la usa) e lo spazio per esercitarsi.
* Kana e caratteri cinesi/giapponesi: caselle quadrate con croce e diagonali tratteggiate; il carattere
  è mostrato in grigio con il numero di ogni tratto sul punto di partenza.

I modelli sono schemi didattici del programma: confrontali con un facsimile prima di usarli come riferimento storico.
"""
import math

LARGHEZZA, ALTEZZA = 1240, 1754           # A4 a 150 dpi
MARGINE = 90

# Inclinazione delle linee guida (gradi dalla verticale, positivo = verso destra).
INCLINAZIONE = {
    "occidentale_copperplate": 35, "occidentale_spencerian": 38, "occidentale_cancelleresca": 14,
    "occidentale_bastarda": 11, "occidentale_batarde_francaise": 10, "occidentale_gotica_cursiva": 7,
    "occidentale_kurrent": 15, "moderna_brush_lettering": 20,
}
COL_GUIDA = "#d9c7a4"
COL_BASE = "#cf7d6b"
COL_X = "#e4b3a6"
COL_MODELLO = "#b9b09c"
COL_TESTO = "#573417"
COL_NUMERO = "#c0392b"


def tipo_carattere(c):
    """'cjk' per kana e ideogrammi, 'arabo' per l'arabo, altrimenti 'latino'."""
    o = ord(c)
    if 0x3040 <= o <= 0x30FF or 0x4E00 <= o <= 0x9FFF:
        return "cjk"
    if 0x0600 <= o <= 0x06FF:
        return "arabo"
    return "latino"


def _poligoni_penna(punti, larghezza, angolo):
    a = math.radians(angolo)
    hx, hy = math.cos(a) * larghezza / 2.0, -math.sin(a) * larghezza / 2.0
    return [((x0 + hx, y0 + hy), (x1 + hx, y1 + hy), (x1 - hx, y1 - hy), (x0 - hx, y0 - hy))
            for (x0, y0), (x1, y1) in zip(punti, punti[1:])]


def _intestazione(titolo, sottotitolo, pagina, pagine):
    prim = [("testo", MARGINE, 62, titolo, 34, COL_TESTO)]
    if sottotitolo:
        prim.append(("testo", MARGINE, 100, sottotitolo, 20, "#59432f"))
    prim.append(("linea", MARGINE, 118, LARGHEZZA - MARGINE, 118, COL_BASE, 2, False))
    prim.append(("testo", LARGHEZZA - MARGINE - 150, ALTEZZA - 40, f"Pagina {pagina}/{pagine}", 18, "#8a7355"))
    prim.append(("testo", MARGINE, ALTEZZA - 40, "Calligrafia Studio · schema didattico da confrontare con un facsimile", 18, "#8a7355"))
    return prim


def costruisci_fogli(titolo, lettere, modello_fn, nib=None, stile_id=None, xh=54, sottotitolo=None):
    """Restituisce la lista delle pagine; ogni pagina è {'prim': [...], 'larghezza': .., 'altezza': ..}."""
    lettere = [c for c in lettere if modello_fn(c)]
    if not lettere:
        return []
    tipo = tipo_carattere(lettere[0])
    if tipo == "cjk":
        return _fogli_cjk(titolo, lettere, modello_fn, sottotitolo)
    return _fogli_alfabetici(titolo, lettere, modello_fn, nib, stile_id, xh, sottotitolo, rtl=(tipo == "arabo"))


def _fogli_alfabetici(titolo, lettere, modello_fn, nib, stile_id, xh, sottotitolo, rtl):
    incl = INCLINAZIONE.get(stile_id, 0) if stile_id else 0
    try:                                           # l'archivio dell'utente (dati_stili) ha la precedenza
        from gradi_stili import gradi_per_id
        g = gradi_per_id(stile_id) if stile_id else None
        if g and g["inclinazione"] is not None:
            incl = g["inclinazione"]
    except ImportError:
        pass
    s = xh / 0.5
    alt_asc, alt_disc = 1.45 * xh, 0.8 * xh
    riga_h = alt_asc + xh + alt_disc + 0.5 * xh
    top = 150
    per_pagina = max(1, int((ALTEZZA - top - 90) // riga_h))
    pagine = [lettere[i:i + per_pagina] for i in range(0, len(lettere), per_pagina)]
    risultato = []
    larg_pennino = xh / 5.0
    x_inizio, x_fine = MARGINE + 50, LARGHEZZA - MARGINE
    for n, gruppo in enumerate(pagine, 1):
        prim = _intestazione(titolo, sottotitolo, n, len(pagine))
        for r, ch in enumerate(gruppo):
            y_top = top + r * riga_h
            y_x = y_top + alt_asc                 # linea della x
            y_b = y_x + xh                        # linea di base
            y_d = y_b + alt_disc
            # linee dell'inclinazione
            if incl is not None:
                dx = math.tan(math.radians(incl)) * (y_d - y_top)
                passo = 1.9 * xh
                x = x_inizio - max(dx, 0)
                while x < x_fine:
                    xa, ya = x, y_d
                    xb, yb = x + dx, y_top
                    if xb > x_inizio - 1 or xa > x_inizio - 1:
                        prim.append(("linea", max(xa, x_inizio), ya, min(xb, x_fine), yb, "#ece0c8", 1, True))
                    x += passo
            prim.append(("linea", x_inizio, y_top, x_fine, y_top, COL_GUIDA, 1, True))
            prim.append(("linea", x_inizio, y_x, x_fine, y_x, COL_X, 2, False))
            prim.append(("linea", x_inizio, y_b, x_fine, y_b, COL_BASE, 2, False))
            prim.append(("linea", x_inizio, y_d, x_fine, y_d, COL_GUIDA, 1, True))
            prim.append(("testo", MARGINE - 10, y_b, ch, 38, COL_TESTO))
            # modelli ripetuti: due da ricalcare, poi spazio libero
            strokes = modello_fn(ch)
            xs = [p[0] for t in strokes for p in t]
            larg = (max(xs) - min(xs)) * s
            cella = larg + 1.2 * xh + (math.tan(math.radians(incl)) * xh * 1.2 if incl else 0)
            xmin = min(xs)
            for k in range(2):
                if rtl:
                    ox = x_fine - 20 - k * cella - larg
                else:
                    ox = x_inizio + 20 + k * cella
                colore = COL_MODELLO if k == 0 else "#d8d1c1"     # il secondo modello è più chiaro
                for t in strokes:
                    punti = [(ox + (px - xmin) * s, y_b + (py - 0.78) * s) for px, py in t]
                    if nib:
                        for q in _poligoni_penna(punti, larg_pennino, nib):
                            prim.append(("riempi", list(q), colore))
                    else:
                        prim.append(("poli", punti, colore, max(3, xh / 6)))
        risultato.append({"prim": prim, "larghezza": LARGHEZZA, "altezza": ALTEZZA})
    return risultato


def _fogli_cjk(titolo, lettere, modello_fn, sottotitolo):
    c = 130                                        # lato della casella
    colonne = (LARGHEZZA - 2 * MARGINE) // c
    per_carattere = 4                              # modello, modello chiaro, due caselle libere
    caratteri_per_riga = max(1, colonne // per_carattere)
    top = 150
    righe_pagina = max(1, (ALTEZZA - top - 90) // c)
    per_pagina = righe_pagina * caratteri_per_riga
    pagine = [lettere[i:i + per_pagina] for i in range(0, len(lettere), per_pagina)]
    x0 = (LARGHEZZA - colonne * c) // 2
    risultato = []
    for n, gruppo in enumerate(pagine, 1):
        prim = _intestazione(titolo, sottotitolo, n, len(pagine))
        for i, ch in enumerate(gruppo):
            riga, pos = divmod(i, caratteri_per_riga)
            for k in range(per_carattere):
                cx = x0 + (pos * per_carattere + k) * c
                cy = top + riga * c
                prim.append(("poli", [(cx, cy), (cx + c, cy), (cx + c, cy + c), (cx, cy + c), (cx, cy)], COL_BASE, 2))
                for (xa, ya, xb, yb) in ((cx + c / 2, cy, cx + c / 2, cy + c), (cx, cy + c / 2, cx + c, cy + c / 2),
                                         (cx, cy, cx + c, cy + c), (cx + c, cy, cx, cy + c)):
                    prim.append(("linea", xa, ya, xb, yb, COL_GUIDA, 1, True))
                if k < 2:
                    colore = COL_MODELLO if k == 0 else "#dcd5c6"
                    strokes = modello_fn(ch)
                    for j, t in enumerate(strokes):
                        punti = [(cx + 0.08 * c + px * 0.84 * c, cy + 0.08 * c + py * 0.84 * c) for px, py in t]
                        prim.append(("poli", punti, colore, 8))
                        if k == 0:
                            prim.append(("testo", punti[0][0] + 3, punti[0][1] - 4, str(j + 1), 16, COL_NUMERO))
        risultato.append({"prim": prim, "larghezza": LARGHEZZA, "altezza": ALTEZZA})
    return risultato
