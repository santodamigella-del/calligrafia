"""Sequenze didattiche introduttive per alcuni caratteri dell'Asia orientale.

Le sequenze sono convenzioni di base per forme regolari moderne (kaishu/kaisho),
non trascrizioni di un singolo manoscritto storico. Varianti calligrafiche possono
modificare collegamenti, andamento e terminazioni.
"""

TRATTI = {
    "永": ["Punto: dall'alto verso il basso, con appoggio e rilascio.", "Tratto orizzontale breve: da sinistra a destra.", "Tratto verticale con uncino: dall'alto in basso, chiudendo con un piccolo uncino.", "Discendente verso sinistra: dall'alto a destra verso il basso a sinistra.", "Punto laterale sinistro: gesto breve e controllato.", "Discendente lungo verso sinistra: apertura progressiva del pennello.", "Punto laterale destro: appoggio, spinta e sollevamento.", "Discendente verso destra: andamento controllato e chiusura piena."],
    "山": ["Tratto verticale sinistro: dall'alto verso il basso.", "Tratto verticale centrale: dall'alto verso il basso, leggermente più lungo.", "Tratto verticale destro con andamento orizzontale finale: dall'alto, poi verso destra."],
    "水": ["Punto/segno centrale superiore.", "Tratto verticale centrale con uncino.", "Discendente verso sinistra, separato.", "Discendente verso destra, ampio e conclusivo."],
    "人": ["Discendente verso sinistra, dall'alto a destra verso il basso a sinistra.", "Discendente verso destra, iniziando vicino alla sommità e aprendosi verso il basso."],
    "天": ["Tratto orizzontale superiore, da sinistra a destra.", "Tratto orizzontale inferiore, leggermente più lungo.", "Discendente verso sinistra.", "Discendente verso destra."],
    "地": ["Tratto verticale breve a sinistra.", "Tratto orizzontale con piega e uncino nella componente 土.", "Secondo tratto orizzontale della componente 土.", "Tratto verticale della componente 土.", "Tratti della componente 也: seguire la sequenza regolare del modello adottato; evitare di improvvisare legature corsive."],
    "日": ["Tratto verticale sinistro con piega verso destra.", "Tratto orizzontale superiore e verticale destro, in continuità.", "Tratto orizzontale interno.", "Tratto orizzontale inferiore di chiusura."],
    "月": ["Tratto verticale sinistro con piega verso destra.", "Tratto verticale destro, dall'alto verso il basso.", "Tratto orizzontale interno superiore.", "Tratto orizzontale interno inferiore."],
    "川": ["Primo tratto verticale a sinistra.", "Secondo tratto verticale centrale.", "Terzo tratto verticale a destra."],
    "春": ["Componente superiore: prima i tratti orizzontali e poi i discendenti, secondo il modello regolare.", "Completare la parte superiore mantenendo spaziatura uniforme.", "Componente 日 inferiore: contorno, tratto interno e chiusura."],
    "花": ["Componente 艹: tratto sinistro, tratto destro e collegamento/chiusura superiore secondo la variante adottata.", "Componente 化: prima il radicale 人 nella sua forma laterale.", "Completare la parte 匕 rispettando l'ordine standard dei tratti."],
    "道": ["Componente 首: costruire prima i tratti superiori e poi la parte centrale/inferiore.", "Completare 首 prima del radicale 辶.", "Radicale 辶: punto, tratto piegato e tratto finale lungo."],
}

NOTE = "Sequenza didattica di base per forme regolari moderne. Le forme storiche, corsive e i singoli maestri possono presentare varianti: verificare sempre il modello specifico."

def lezione_tratti(carattere):
    passi = TRATTI.get(carattere)
    if not passi:
        return None
    return {"carattere": carattere, "passi": list(passi), "nota": NOTE}
