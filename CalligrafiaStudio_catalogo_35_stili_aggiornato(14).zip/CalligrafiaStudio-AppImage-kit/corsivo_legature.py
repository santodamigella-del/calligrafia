"""Scrittura corsiva a punta flessibile: lettere legate in un tracciato continuo.

Ogni lettera è un percorso nell'unità «altezza della x» (x-height = 1):
la riga di base è y = 0, la linea della x è y = -1, le aste salgono verso -2.2 e le
discendenti scendono verso +1.3 (y cresce verso il basso, come sullo schermo).
Ogni lettera inizia in (0, -0.9), dove arriva il filetto di legatura della lettera
precedente, e termina sul rigo (o in alto) da dove parte il filetto verso la
successiva. Tratti extra (traverse della t, punti della i, secondo tratto della x)
si fanno a parola finita, come nella pratica reale.

Lo spessore simula la punta flessibile: più largo nei tratti in discesa (pressione),
filetto sottile in salita. Sono SCHEMI DIDATTICI: forme e legature vanno confrontate
con un manuale (per esempio un testo di roundhand o di Spencer) prima di usarle
come riferimento storico.
"""
import math

# lettera: (percorso del corpo, avanzamento, tratti extra)
_LETTERE = {
    "a": ([(0, -.9), (.30, -1.0), (.12, -.78), (.08, -.4), (.28, -.02), (.50, -.4), (.54, -1.0), (.58, -.4), (.62, 0)], 1.0, []),
    "b": ([(0, -.9), (.2, -1.5), (.38, -2.15), (.40, -2.3), (.30, -2.25), (.28, -1.5), (.30, -.5), (.32, -.03),
           (.5, -.6), (.7, -.98), (.88, -.7), (.82, -.2), (.55, 0), (.40, -.1)], 1.1, []),
    "c": ([(0, -.9), (.30, -1.0), (.10, -.7), (.08, -.3), (.30, 0), (.50, -.1)], .85, []),
    "d": ([(0, -.9), (.30, -1.0), (.12, -.78), (.08, -.4), (.28, -.02), (.50, -.4), (.52, -1.0),
           (.58, -1.9), (.48, -2.2), (.40, -2.3), (.55, -1.5), (.62, -.5), (.65, 0)], 1.05, []),
    "e": ([(0, -.9), (.25, -1.0), (.40, -.85), (.12, -.62), (.08, -.3), (.28, 0), (.48, -.12)], .85, []),
    "f": ([(0, -.9), (.22, -1.8), (.42, -2.25), (.36, -2.35), (.28, -1.5), (.28, 0), (.26, 1.1), (.10, 1.3), (.0, 1.0), (.2, .4), (.5, 0)], .95,
          [[(-.05, -1.0), (.6, -1.02)]]),
    "g": ([(0, -.9), (.30, -1.0), (.12, -.78), (.08, -.4), (.28, -.02), (.50, -.4), (.54, -1.0), (.58, -.2),
           (.55, .6), (.45, 1.2), (.22, 1.35), (.08, 1.1), (.28, .75), (.55, .3)], 1.0, []),
    "h": ([(0, -.9), (.2, -1.5), (.38, -2.15), (.40, -2.3), (.30, -2.25), (.28, -1.5), (.30, -.5), (.32, -.03),
           (.31, -.55), (.5, -.98), (.7, -.9), (.75, -.4), (.78, 0)], 1.05, []),
    "i": ([(0, -.9), (.25, -1.0), (.28, -.5), (.30, -.03), (.42, 0)], .75, [[(.26, -1.55), (.31, -1.5)]]),
    "j": ([(0, -.9), (.25, -1.0), (.28, -.4), (.28, .8), (.10, 1.25), (-.12, 1.0), (.10, .5), (.40, 0)], .8, [[(.26, -1.55), (.31, -1.5)]]),
    "k": ([(0, -.9), (.2, -1.5), (.38, -2.15), (.40, -2.3), (.30, -2.25), (.28, -1.5), (.30, -.5), (.32, -.03),
           (.31, -.55), (.45, -.95), (.55, -.85), (.35, -.45), (.55, 0), (.70, -.05)], 1.0, []),
    "l": ([(0, -.9), (.2, -1.5), (.38, -2.15), (.40, -2.3), (.30, -2.25), (.28, -1.5), (.30, -.5), (.33, -.03), (.5, -.05)], .8, []),
    "m": ([(0, -.9), (.22, -1.0), (.25, -.4), (.27, 0), (.30, -.7), (.5, -1.0), (.6, -.8), (.6, -.3), (.62, 0),
           (.65, -.7), (.85, -1.0), (.95, -.8), (.95, -.3), (.98, 0)], 1.45, []),
    "n": ([(0, -.9), (.22, -1.0), (.25, -.4), (.27, 0), (.30, -.7), (.5, -1.0), (.62, -.8), (.62, -.3), (.65, 0)], 1.0, []),
    "o": ([(0, -.9), (.30, -1.02), (.10, -.8), (.06, -.4), (.30, 0), (.55, -.4), (.50, -.95), (.30, -1.0), (.62, -1.0)], 1.0, []),
    "p": ([(0, -.9), (.20, -1.0), (.24, 0), (.26, 1.2), (.24, .2), (.30, -.8), (.60, -1.0), (.75, -.6), (.60, -.1), (.30, -.1)], 1.0, []),
    "q": ([(0, -.9), (.30, -1.0), (.12, -.7), (.08, -.3), (.30, 0), (.50, -.4), (.52, -1.0), (.55, 0), (.57, 1.2), (.40, 1.3)], 1.0, []),
    "r": ([(0, -.9), (.22, -1.0), (.25, -.4), (.27, 0), (.30, -.6), (.50, -1.0), (.70, -.95)], .85, []),
    "s": ([(0, -.9), (.25, -1.0), (.45, -.9), (.30, -.55), (.10, -.35), (.20, 0), (.40, -.05)], .8, []),
    "t": ([(0, -.9), (.20, -1.5), (.25, -1.6), (.27, -.5), (.30, -.02), (.50, -.05)], .8, [[(-.05, -1.0), (.55, -1.02)]]),
    "u": ([(0, -.9), (.20, -1.0), (.20, -.4), (.28, 0), (.50, -.2), (.60, -1.0), (.62, -.4), (.66, 0)], 1.0, []),
    "v": ([(0, -.9), (.22, -1.0), (.40, -.02), (.62, -.95), (.75, -1.0)], .85, []),
    "w": ([(0, -.9), (.20, -1.0), (.35, -.02), (.55, -.9), (.75, -.02), (.95, -.95), (1.05, -1.0)], 1.2, []),
    "x": ([(0, -.9), (.25, -1.0), (.60, -.02)], .9, [[(.55, -1.0), (.15, 0)]]),
    "y": ([(0, -.9), (.20, -1.0), (.20, -.4), (.28, 0), (.50, -.2), (.60, -1.0), (.60, .4), (.50, 1.2), (.25, 1.35), (.10, 1.1), (.30, .7)], 1.0, []),
    "z": ([(0, -.9), (.25, -1.0), (.55, -.95), (.15, -.08), (.45, 0)], .85, []),
}

# Capilettera: (tratti prima del corpo, corpo finale che termina sul rigo, avanzamento, tratti extra).
# Alti circa 2 x-height; i capilettera non si legano alla lettera precedente: la penna si stacca.
_MAIUSC = {
    "A": ([[(.5, -2.05), (.25, -1.0), (.02, 0)]], [(.5, -2.05), (.8, -1.0), (1.0, 0)], 1.3, [[(.2, -.65), (.8, -.65)]]),
    "B": ([[(.2, -2.0), (.15, -1.0), (.1, 0)]], [(.2, -2.0), (.7, -2.0), (.95, -1.6), (.7, -1.1), (.25, -1.0), (.8, -.9), (1.0, -.45), (.75, 0), (.2, 0)], 1.35, []),
    "C": ([], [(1.0, -1.7), (.7, -2.0), (.3, -1.8), (.05, -1.0), (.2, -.2), (.6, 0), (.95, -.2)], 1.3, []),
    "D": ([[(.2, -2.0), (.12, 0)]], [(.2, -2.0), (.8, -1.9), (1.05, -1.0), (.8, -.1), (.15, 0)], 1.4, []),
    "E": ([], [(.9, -1.8), (.6, -2.0), (.25, -1.7), (.5, -1.1), (.2, -1.0), (.15, -.4), (.45, 0), (.9, -.1)], 1.2, []),
    "F": ([], [(1.0, -1.8), (.65, -2.1), (.3, -1.85), (.3, -1.0), (.2, 0)], 1.2, [[(-.05, -1.1), (.5, -1.15), (1.0, -1.2)]]),
    "G": ([], [(1.0, -1.7), (.7, -2.0), (.3, -1.8), (.05, -1.0), (.2, -.2), (.6, 0), (.95, -.3), (.98, -.95)], 1.35, [[(.55, -.95), (1.05, -.97)]]),
    "H": ([[(.2, -2.0), (.15, 0)]], [(.9, -2.0), (.85, -1.0), (.8, 0)], 1.3, [[(.15, -1.0), (.85, -1.0)]]),
    "I": ([], [(.3, -1.95), (.6, -2.15), (.85, -2.0), (.55, -1.85), (.45, -1.0), (.35, 0)], 1.1, []),
    "J": ([], [(.2, -1.85), (.5, -2.15), (.85, -2.0), (.6, -1.85), (.65, -1.0), (.6, .7), (.35, 1.25), (.05, 1.05), (.25, .55), (.5, 0)], 1.2, []),
    "K": ([[(.2, -2.0), (.15, 0)]], [(.95, -1.9), (.2, -.9), (.6, -.7), (.95, 0)], 1.3, []),
    "L": ([], [(.9, -1.8), (.55, -2.15), (.2, -1.7), (.45, -1.0), (.35, -.2), (.55, 0), (1.0, -.1)], 1.3, []),
    "M": ([[(.0, 0), (.12, -1.95)]], [(.12, -1.95), (.45, -.1), (.72, -1.95), (1.05, -.1)], 1.6, []),
    "N": ([[(.1, 0), (.22, -1.9)]], [(.22, -1.9), (.9, -.05)], 1.3, [[(.9, -.05), (.98, -1.9)]]),
    "O": ([], [(.6, -2.0), (.2, -1.7), (.1, -1.0), (.25, -.2), (.6, 0), (.95, -.5), (.95, -1.4), (.6, -2.0), (.45, -1.2), (.5, -.3)], 1.3, []),
    "P": ([[(.2, -2.0), (.12, 0)]], [(.2, -2.0), (.8, -1.9), (.95, -1.4), (.7, -.9), (.2, -.9)], 1.2, []),
    "Q": ([], [(.6, -2.0), (.2, -1.7), (.1, -1.0), (.25, -.2), (.6, 0), (.95, -.5), (.95, -1.4), (.6, -2.0), (.45, -1.2), (.5, -.3)], 1.3, [[(.6, -.3), (1.0, .5)]]),
    "R": ([[(.2, -2.0), (.12, 0)]], [(.2, -2.0), (.8, -1.9), (.95, -1.4), (.7, -.95), (.25, -.9), (.6, -.8), (.95, 0)], 1.3, []),
    "S": ([], [(.8, -1.75), (.5, -2.1), (.25, -1.85), (.45, -1.4), (.8, -1.05), (.85, -.55), (.55, -.02), (.25, -.1), (.15, -.4)], 1.2, []),
    "T": ([[(.1, -1.9), (1.0, -1.95)]], [(.55, -2.0), (.45, -1.0), (.35, 0)], 1.2, []),
    "U": ([], [(.15, -1.9), (.2, -.6), (.5, 0), (.8, -.5), (.9, -1.9), (.95, -.3), (1.0, 0)], 1.3, []),
    "V": ([], [(.1, -1.9), (.5, -.05)], 1.2, [[(.5, -.05), (.95, -1.9)]]),
    "W": ([], [(.1, -1.9), (.35, 0)], 1.6, [[(.35, 0), (.6, -1.4)], [(.6, -1.4), (.85, 0)], [(.85, 0), (1.15, -1.9)]]),
    "X": ([], [(.15, -1.9), (.9, 0)], 1.2, [[(.9, -1.9), (.15, 0)]]),
    "Y": ([[(.9, -1.9), (.5, -1.0)]], [(.1, -1.9), (.5, -1.0), (.45, .5), (.25, 1.2), (.05, 1.0), (.3, .5), (.5, 0)], 1.2, []),
    "Z": ([], [(.1, -1.75), (.3, -2.05), (.95, -1.95), (.6, -1.1), (.15, -.15), (.4, .02), (.95, -.05)], 1.3, []),
}
LETTERE_DISPONIBILI = "".join(sorted(_LETTERE)) + "".join(sorted(_MAIUSC))


# Alfabeto italico (cancelleresca): senza occhielli, aste diritte con ingresso a filetto,
# archi che si ramificano dall'asta (n, m, h, r, b, p) e ovali per a, c, d, e, g, o, q.
_ITALICA = {
    "a": ([(0, -.9), (.34, -1.04), (.1, -.82), (.04, -.42), (.2, 0), (.5, -.3), (.54, -1.0), (.56, -.5), (.58, 0)], .8, []),
    "b": ([(0, -.9), (.2, -1.6), (.3, -2.0), (.3, -1.0), (.3, 0), (.31, -.5), (.5, -.98), (.7, -.8), (.7, -.25), (.5, 0), (.3, -.1)], .9, []),
    "c": ([(0, -.9), (.3, -1.02), (.1, -.75), (.08, -.4), (.25, 0), (.45, -.08)], .6, []),
    "d": ([(0, -.9), (.3, -1.02), (.1, -.75), (.08, -.4), (.25, 0), (.48, -.35), (.5, -1.0), (.5, -1.95), (.52, -1.0), (.52, -.05)], .75, []),
    "e": ([(0, -.9), (.3, -1.02), (.4, -.82), (.12, -.62), (.08, -.35), (.25, 0), (.48, -.1)], .65, []),
    "f": ([(0, -.9), (.2, -1.6), (.35, -2.0), (.38, -1.5), (.3, -.3), (.25, 1.0), (.1, 1.15), (0, 1.0)], .6, [[(0, -1.0), (.6, -1.0)]]),
    "g": ([(0, -.9), (.3, -1.02), (.1, -.75), (.08, -.4), (.25, 0), (.48, -.35), (.5, -1.0), (.5, -.2), (.45, .6), (.3, 1.1), (.1, 1.2), (0, 1.0)], .8, []),
    "h": ([(0, -.9), (.2, -1.6), (.3, -2.0), (.3, -1.2), (.3, -.5), (.3, 0), (.31, -.5), (.5, -.95), (.7, -.9), (.78, -.5), (.8, 0)], .95, []),
    "i": ([(0, -.9), (.2, -1.0), (.22, -.5), (.22, -.05), (.4, -.05)], .6, [[(.2, -1.5), (.24, -1.47)]]),
    "j": ([(0, -.9), (.2, -1.0), (.22, -.3), (.2, .9), (.05, 1.15), (-.1, 1.0)], .6, [[(.2, -1.5), (.24, -1.47)]]),
    "k": ([(0, -.9), (.2, -1.6), (.3, -2.0), (.3, -1.0), (.3, 0), (.3, -.45), (.6, -.95), (.35, -.5), (.65, 0), (.8, 0)], .95, []),
    "l": ([(0, -.9), (.2, -1.6), (.3, -2.0), (.3, -1.0), (.3, -.1), (.45, -.02)], .65, []),
    "m": ([(0, -.9), (.2, -1.0), (.22, -.5), (.22, 0), (.23, -.5), (.4, -.95), (.58, -.9), (.65, -.5), (.66, 0), (.67, -.5), (.82, -.95), (1.0, -.9), (1.08, -.5), (1.1, 0)], 1.4, []),
    "n": ([(0, -.9), (.2, -1.0), (.22, -.5), (.22, 0), (.23, -.5), (.4, -.95), (.62, -.92), (.7, -.5), (.72, -.05)], .95, []),
    "o": ([(0, -.9), (.3, -1.02), (.1, -.75), (.08, -.4), (.25, 0), (.48, -.4), (.45, -.9), (.3, -1.0), (.55, -1.0)], .8, []),
    "p": ([(0, -.9), (.2, -1.0), (.22, 0), (.22, 1.2), (.22, .3), (.24, -.5), (.4, -.97), (.6, -.8), (.62, -.4), (.45, -.05), (.25, -.1)], .85, []),
    "q": ([(0, -.9), (.3, -1.02), (.1, -.75), (.08, -.4), (.25, 0), (.48, -.35), (.5, -1.0), (.52, 0), (.53, 1.1), (.62, 1.2)], .8, []),
    "r": ([(0, -.9), (.2, -1.0), (.22, -.5), (.22, 0), (.23, -.5), (.4, -.95), (.62, -.92)], .75, []),
    "s": ([(0, -.9), (.3, -1.0), (.4, -.85), (.2, -.55), (.1, -.35), (.25, 0), (.45, -.1)], .6, []),
    "t": ([(0, -.9), (.15, -1.4), (.25, -1.5), (.27, -.6), (.28, -.1), (.45, 0)], .65, [[(-.05, -1.0), (.55, -1.0)]]),
    "u": ([(0, -.9), (.18, -1.0), (.2, -.4), (.3, -.05), (.5, -.15), (.6, -1.0), (.62, -.4), (.65, 0)], .95, []),
    "v": ([(0, -.9), (.2, -1.0), (.35, -.05), (.55, -.95), (.65, -1.0)], .65, []),
    "w": ([(0, -.9), (.18, -1.0), (.3, -.05), (.5, -.9), (.65, -.05), (.82, -.95), (.92, -1.0)], .95, []),
    "x": ([(0, -.9), (.2, -1.0), (.5, -.02)], .75, [[(.45, -1.0), (.1, 0)]]),
    "y": ([(0, -.9), (.18, -1.0), (.2, -.4), (.3, -.05), (.5, -.15), (.6, -1.0), (.6, .5), (.45, 1.1), (.25, 1.2), (.1, 1.0)], .85, []),
    "z": ([(0, -.9), (.2, -1.0), (.5, -.98), (.1, -.05), (.45, 0)], .6, []),
}
_CAPITALE_ROMANA = "Capitale Romana (Capitalis Monumentalis)"

# slant = tangente dell'inclinazione dalla verticale; asc/disc scalano aste e discendenti;
# larg scala le larghezze; spazio = spazio tra le parole in unità x-height.
STILI_CORSIVI = {
    "occidentale_copperplate": {"nome": "Copperplate / Roundhand", "slant": 0.70, "asc": 1.0, "disc": 1.0, "larg": 1.4, "spazio": 2.0,
                                "spessore": 0.20, "filetto": 0.035},
    "moderna_brush_lettering": {"nome": "Brush lettering", "slant": 0.35, "asc": 0.85, "disc": 0.85, "larg": 1.25, "spazio": 1.8,
                                "spessore": 0.34, "filetto": 0.09, "rimbalzo": 0.14},
    "occidentale_cancelleresca": {"nome": "Cancelleresca / Italica", "slant": 0.158, "asc": 0.9, "disc": 0.85, "larg": 1.6, "spazio": 1.5,
                                  "spessore": 0.30, "filetto": 0.04, "penna_larga": 40, "alfabeto": "italica"},
    "occidentale_spencerian":  {"nome": "Spencerian", "slant": 0.78, "asc": 0.85, "disc": 0.85, "larg": 1.25, "spazio": 1.8,
                                "spessore": 0.18, "filetto": 0.032},
}


def _chaikin(pts, giri):
    for _ in range(giri):
        if len(pts) < 3:
            break
        nuovi = [pts[0]]
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            nuovi.append((0.75 * ax + 0.25 * bx, 0.75 * ay + 0.25 * by))
            nuovi.append((0.25 * ax + 0.75 * bx, 0.25 * ay + 0.75 * by))
        nuovi.append(pts[-1])
        pts = nuovi
    return pts


def _salita(ultimo, adv, y_fin=-0.92):
    """Filetto di legatura: dall'ultimo punto fino a (adv, y_fin), dove inizia la lettera successiva."""
    xb, yb = ultimo
    if yb < -0.5:                       # lettera che finisce in alto (o, v, w, r)
        return [(xb, yb), ((xb + adv) / 2, (yb + y_fin) / 2), (adv, y_fin)]
    return [(xb, yb), (xb + 0.15, yb + 0.02), (adv - 0.25, (yb + y_fin) / 2), (adv, y_fin)]


def _rimbalzo(i, n, ampiezza):
    """Spostamento verticale deterministico (brush lettering: le lettere «ballano» sul rigo)."""
    if not ampiezza:
        return 0.0
    v = math.sin((i + 1) * 12.9898 + n * 3.1) * 43758.5453
    return ampiezza * (2 * (v - math.floor(v)) - 1)


def _maiuscola_romana(ch):
    """Strati della capitale romana (alfabeto italico: i capilettera sono capitali diritte, non legate)."""
    try:
        from ductus_stili import modello_stile
        return modello_stile(_CAPITALE_ROMANA, ch)
    except ImportError:
        return None


def parola_valida(testo, stile_id=None):
    """Restituisce (testo ripulito, lettere non supportate)."""
    italica = bool(stile_id) and STILI_CORSIVI.get(stile_id, {}).get("alfabeto") == "italica"
    if italica:
        def ok(c):
            return c in _ITALICA or (c.isupper() and _maiuscola_romana(c) is not None)
    else:
        def ok(c):
            return c in _LETTERE or c in _MAIUSC
    mancanti = sorted({c for c in testo if c != " " and not ok(c)})
    return "".join(c for c in testo if c == " " or ok(c)), mancanti


def costruisci_testo(testo, stile_id="occidentale_copperplate"):
    """Costruisce i tratti di una o più parole.

    Restituisce (tratti, riga) dove tratti è la lista di percorsi [(x, y), ...] nell'ordine di
    scrittura (prima i corpi delle parole, poi i tratti extra) e riga è un dict con
    larghezza e limiti verticali in unità x-height.
    """
    par = STILI_CORSIVI[stile_id]
    italica = par.get("alfabeto") == "italica"
    lettere = _ITALICA if italica else _LETTERE
    pulito, _m = parola_valida(testo, stile_id)
    cursori = 0.0
    corpi, extra = [], []

    def ridimensiona(p, dx, dy=0.0):
        out = []
        for x, y in p:
            if y < -1.2: y = -1.0 + (y + 1.0) * par["asc"]
            if y > 0.2: y = y * par["disc"]
            out.append((dx + x * par["larg"], y + dy))
        return out

    for parola in pulito.split(" "):
        if not parola:
            cursori += par["spazio"]
            continue
        percorso = []
        rimb = [_rimbalzo(i, len(parola), par.get("rimbalzo", 0.0)) for i in range(len(parola) + 1)]
        for i, ch in enumerate(parola):
            if italica and ch.isupper():
                # capolettera: capitale romana, tratti staccati; la minuscola successiva riparte da sé
                if percorso:
                    corpi.append(percorso); percorso = []
                forme = _maiuscola_romana(ch)
                K = 3.33
                x_min = min(x for t in forme for x, _y in t)
                x_max = max(x for t in forme for x, _y in t)
                for tr in forme:
                    corpi.append([(cursori + (x - x_min) * K, (y - 0.78) * K + rimb[i]) for x, y in tr])
                adv_s = cursori + (x_max - x_min) * K + 0.35
                cursori = adv_s
                continue
            if ch in _MAIUSC and not italica:
                prima, corpo, adv, ex = _MAIUSC[ch]; dy = rimb[i]
                if percorso:                       # il capolettera non si lega: la penna si stacca
                    corpi.append(percorso); percorso = []
                for pr in prima:
                    corpi.append(ridimensiona(pr, cursori, dy))
                corpo = ridimensiona(corpo, cursori, dy)
                percorso.extend(corpo)
            else:
                corpo, adv, ex = lettere[ch]; dy = rimb[i]
                corpo = ridimensiona(corpo, cursori, dy)
                if percorso:
                    percorso.extend(corpo[1:])    # il primo punto coincide con la fine del filetto
                else:
                    percorso.extend(corpo)
            for e in ex:
                extra.append(ridimensiona(e, cursori, dy))
            ultimo = i == len(parola) - 1
            adv_s = cursori + adv * par["larg"]
            if not ultimo and (parola[i + 1:i + 2].isupper() and italica):
                pass                                       # prima di un capolettera la penna si stacca
            elif not ultimo:
                percorso.extend(_salita(percorso[-1], adv_s, -0.92 + rimb[i + 1])[1:])
            else:
                xb, yb = percorso[-1]
                percorso.extend([(xb + 0.2, yb - 0.1 if yb > -0.5 else yb), (xb + 0.45, yb - 0.45 if yb > -0.5 else yb - 0.05)])
            cursori = adv_s
        if percorso:
            corpi.append(percorso)
        cursori += par["spazio"]
    tratti = [_chaikin(p, 3) for p in corpi] + [_chaikin(e, 1) if len(e) > 2 else e for e in extra]
    # inclinazione: la parte alta si sposta a destra
    inclinati = [[(x - y * par["slant"], y) for x, y in t] for t in tratti]
    xs = [x for t in inclinati for x, _y in t]
    ys = [y for t in inclinati for _x, y in t]
    riga = {"x0": min(xs), "x1": max(xs), "y0": min(ys + [-2.3]), "y1": max(ys + [1.4])}
    return inclinati, riga


def segmenti_pressione(punti, spessore, filetto, penna_larga=None):
    """Per ogni segmento (p0, p1, larghezza): largo in discesa, filetto in salita.

    La pressione segue la componente verticale del movimento con una transizione dolce,
    come una punta flessibile che si apre quando si preme verso il basso.
    """
    segs = []
    prec = 0.0
    if penna_larga:
        a = math.radians(penna_larga)
        ex, ey = math.cos(a), -math.sin(a)          # direzione del taglio della penna (y verso il basso)
    for (x0, y0), (x1, y1) in zip(punti, punti[1:]):
        d = math.hypot(x1 - x0, y1 - y0)
        if d == 0:
            continue
        if penna_larga:
            # penna a punta larga: largo quando il movimento è perpendicolare al taglio
            f = (abs((x1 - x0) * ey - (y1 - y0) * ex) / d) ** 1.5
            f = 0.35 * prec + 0.65 * f
            prec = f
            segs.append(((x0, y0), (x1, y1), filetto + (spessore - filetto) * f))
            continue
        discesa = max(0.0, (y1 - y0) / d)           # 0..1
        f = discesa ** 1.5
        f = 0.6 * prec + 0.4 * f                    # smorza i salti
        prec = f
        segs.append(((x0, y0), (x1, y1), filetto + (spessore - filetto) * f))
    return segs


def lunghezza(tratti):
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for t in tratti for a, b in zip(t, t[1:]))


def _contorno_tratto(punti_larghezze):
    """Contorno chiuso (lista di punti) di un tratto a spessore variabile.

    punti_larghezze: [(x, y, mezza_larghezza)]. La normale in ogni punto è la perpendicolare
    alla direzione media tra il segmento entrante e quello uscente (miter semplice): nei punti
    con una svolta molto stretta (occhielli, asole) il contorno può autointersecarsi leggermente.
    """
    n = len(punti_larghezze)
    if n < 2:
        return []
    normali = []
    for i in range(n):
        if i == 0:
            dx, dy = punti_larghezze[1][0] - punti_larghezze[0][0], punti_larghezze[1][1] - punti_larghezze[0][1]
        elif i == n - 1:
            dx, dy = punti_larghezze[-1][0] - punti_larghezze[-2][0], punti_larghezze[-1][1] - punti_larghezze[-2][1]
        else:
            d1 = (punti_larghezze[i][0] - punti_larghezze[i - 1][0], punti_larghezze[i][1] - punti_larghezze[i - 1][1])
            d2 = (punti_larghezze[i + 1][0] - punti_larghezze[i][0], punti_larghezze[i + 1][1] - punti_larghezze[i][1])
            dx, dy = d1[0] + d2[0], d1[1] + d2[1]
        l = math.hypot(dx, dy) or 1.0
        normali.append((-dy / l, dx / l))
    sx = [(x + nx * hw, y + ny * hw) for (x, y, hw), (nx, ny) in zip(punti_larghezze, normali)]
    dx_ = [(x - nx * hw, y - ny * hw) for (x, y, hw), (nx, ny) in zip(punti_larghezze, normali)]
    return sx + dx_[::-1]


def contorni_testo(tratti, par):
    """Un contorno chiuso per ciascun tratto della parola, pronto per il riempimento (SVG, taglio laser, ricamo)."""
    contorni = []
    for tratto in tratti:
        segs = segmenti_pressione(tratto, par["spessore"], par["filetto"], par.get("penna_larga"))
        if not segs:
            continue
        punti = [(tratto[0][0], tratto[0][1], segs[0][2] / 2.0)]
        for (_a, b, w) in segs:
            punti.append((b[0], b[1], w / 2.0))
        contorno = _contorno_tratto(punti)
        if contorno:
            contorni.append(contorno)
    return contorni


def svg_testo(testo, stile_id, sc=120, titolo=None):
    """Restituisce il contenuto di un file SVG con la parola scritta in corsivo.

    sc: pixel per unità di altezza della x (a 120 l'altezza delle minuscole è circa 2 cm a 150 dpi).
    Il contorno di ogni tratto è un percorso continuo pensato anche per taglio laser e ricamo (digitalizzazione
    a parte): per le lettere con occhielli o asole molto stretti il contorno può autointersecarsi leggermente.
    """
    par = STILI_CORSIVI[stile_id]
    tratti, riga = costruisci_testo(testo, stile_id)
    margine = 0.4
    larg = (riga["x1"] - riga["x0"] + 2 * margine) * sc
    alt = (riga["y1"] - riga["y0"] + 2 * margine) * sc
    ox, oy = (margine - riga["x0"]) * sc, (margine - riga["y0"]) * sc
    parti = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{larg:.0f}" height="{alt:.0f}" '
             f'viewBox="0 0 {larg:.0f} {alt:.0f}">']
    if titolo:
        parti.append(f"<title>{_esc_xml(titolo)}</title>")
    parti.append(f'<g id="parola" fill="#1a120a" fill-rule="nonzero">')
    for contorno in contorni_testo(tratti, par):
        d = "M " + " L ".join(f"{ox + x * sc:.2f},{oy + y * sc:.2f}" for x, y in contorno) + " Z"
        parti.append(f'<path d="{d}"/>')
    parti.append("</g></svg>")
    return "\n".join(parti)


def _esc_xml(testo):
    return testo.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
