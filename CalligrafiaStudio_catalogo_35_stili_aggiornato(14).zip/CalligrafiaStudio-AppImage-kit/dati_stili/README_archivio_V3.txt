=== ARCHIVIO CALLIGRAFICO COMPLETO V3 ===

Questo archivio raccoglie l'insieme dei modelli dati, parametri di ductus e 
riferimenti ai font open-source per tutte le principali famiglie calligrafiche:

1. CANCELLERESCA E CAROLINGIA
2. UNCIALE E CAPITALI ROMANE
3. GOTICHE COMPLETE (Textura, Rotunda, Fraktur, Bastarda)
4. ARABE ED ORIENTALI (Naskh, Thuluth, Kufico, Shodo/Kanji)

RIFERIMENTI OPEN-SOURCE (SIL OFL / Freeware):
- Cormorant Garamond: https://fonts.google.com/specimen/Cormorant+Garamond
- Carolingia (Dieter Steffmann): https://www.dafont.com/carolingia.font
- Omnia / Unciala: https://www.dafont.com/unciala.font
- UnifrakturMaguntia (Gotico Textura): https://fonts.google.com/specimen/UnifrakturMaguntia
- Fette Fraktur: https://www.dafont.com/fette-fraktur.font
- Amiri Font (Calligrafia Araba): https://fonts.google.com/specimen/Amiri
- Yuji Syukyo / Kanji Shodo: https://fonts.google.com/specimen/Yuji+Syukyo
