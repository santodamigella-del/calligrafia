"""Riconoscimento euristico dello stile calligrafico dal disegno a mano libera.

Come funziona (in breve)
------------------------
1. Dai tratti disegnati (con mouse o tavoletta) si estraggono misure
   geometriche indipendenti dalla scala: inclinazione delle aste, proporzione
   delle lettere, angolosità, curvatura, quanti tratti ci sono per lettera
   (cursività), allineamento agli assi, direzione di scrittura, puntini.
2. Si stima prima la famiglia di scrittura (latina, araba, dell'Asia orientale).
3. Dentro la famiglia, ogni stile del catalogo ha un profilo "atteso" e si
   calcola una somiglianza per ciascuna misura.

LIMITI (da dire sempre all'utente)
----------------------------------
* I profili sono valori ricavati a mano dalle descrizioni paleografiche
  generali, NON addestrati su un campione di scritture reali.
* Con il mouse non c'è pressione: il contrasto dei pieni e dei filetti non è
  osservabile. Stili vicini (Textura / Textura Quadrata, Bastarda / Bâtarde,
  Copperplate / Spencerian, Kaishu / Kaisho ...) si distinguono poco.
* Servono almeno una parola di 4-5 lettere (o 3-4 caratteri) per un risultato
  sensato; con una lettera sola il risultato è solo indicativo.
Il risultato è quindi un suggerimento didattico, non una perizia paleografica.
"""

import math
from statistics import median

# ----------------------------------------------------------------------------
# Profili degli stili: (valore atteso, tolleranza) per misura.
# Misure: slant (gradi dalla verticale, + = inclinato a destra), aspect
# (larghezza/altezza della lettera), ang (angoli netti per altezza di lettera),
# curve (frazione di percorso curvo), connect (lunghezza media tratto / altezza),
# ortho (frazione di percorso allineata agli assi), horiz (frazione orizzontale),
# closed (frazione di tratti chiusi a ovale), nstroke (tratti per carattere),
# drift (pendenza della riga in gradi, solo arabo).
# ----------------------------------------------------------------------------
PROFILI = {
    # --- latini (valori nelle unità osservate da estrai_caratteristiche; vedi nota in testa)
    "occidentale_onciale": {"f": "latino", "g": "Librarie e maiuscole larghe", "slant": (5, 8), "aspect": (0.9, 0.25), "ang": (0.05, 0.1), "connect": (1.4, 0.5)},
    "occidentale_semionciale": {"f": "latino", "g": "Librarie e maiuscole larghe", "slant": (6, 8), "aspect": (0.8, 0.25), "ang": (0.07, 0.1), "connect": (1.4, 0.5)},
    "occidentale_carolina": {"f": "latino", "g": "Librarie e maiuscole larghe", "slant": (5, 8), "aspect": (0.65, 0.25), "ang": (0.1, 0.1), "connect": (1.4, 0.5)},
    "occidentale_umanistica": {"f": "latino", "g": "Librarie e maiuscole larghe", "slant": (7, 8), "aspect": (0.8, 0.25), "ang": (0.04, 0.1), "connect": (1.4, 0.5)},
    "occidentale_rotunda": {"f": "latino", "g": "Librarie e maiuscole larghe", "slant": (6, 8), "aspect": (0.85, 0.25), "ang": (0.04, 0.1), "connect": (1.4, 0.5)},
    "occidentale_capitale_romana": {"f": "latino", "g": "Librarie e maiuscole larghe", "slant": (4, 6), "aspect": (0.8, 0.3), "ang": (0.05, 0.1), "connect": (1.4, 0.5)},
    "occidentale_textura": {"f": "latino", "g": "Librarie strette / gotiche", "slant": (3, 6), "aspect": (0.5, 0.15), "ang": (0.11, 0.08), "connect": (1.4, 0.5)},
    "occidentale_textura_quadrata": {"f": "latino", "g": "Librarie strette / gotiche", "slant": (3, 6), "aspect": (0.48, 0.15), "ang": (0.16, 0.08), "connect": (1.4, 0.5)},
    "occidentale_fraktur": {"f": "latino", "g": "Librarie strette / gotiche", "slant": (4, 7), "aspect": (0.52, 0.15), "ang": (0.1, 0.08), "connect": (1.4, 0.5)},
    "occidentale_rustica": {"f": "latino", "g": "Librarie strette / gotiche", "slant": (3, 6), "aspect": (0.48, 0.15), "ang": (0.14, 0.08), "connect": (1.4, 0.5)},
    "occidentale_sutterlin": {"f": "latino", "g": "Librarie strette / gotiche", "slant": (6, 7), "aspect": (0.53, 0.15), "ang": (0.13, 0.08), "connect": (1.4, 0.5)},
    "occidentale_bastarda": {"f": "latino", "g": "Corsive moderatamente inclinate", "slant": (17, 9), "connect": (2.9, 1.0)},
    "occidentale_batarde_francaise": {"f": "latino", "g": "Corsive moderatamente inclinate", "slant": (18, 9), "connect": (2.9, 1.0)},
    "occidentale_gotica_cursiva": {"f": "latino", "g": "Corsive moderatamente inclinate", "slant": (15, 9), "connect": (2.9, 1.0)},
    "occidentale_kurrent": {"f": "latino", "g": "Corsive moderatamente inclinate", "slant": (19, 9), "connect": (2.9, 1.0)},
    "occidentale_cancelleresca": {"f": "latino", "g": "Corsive moderatamente inclinate", "slant": (22, 9), "connect": (2.9, 1.0)},
    "occidentale_copperplate": {"f": "latino", "g": "Corsive molto inclinate (punta flessibile)", "slant": (42, 9), "connect": (3.0, 1.0)},
    "occidentale_spencerian": {"f": "latino", "g": "Corsive molto inclinate (punta flessibile)", "slant": (44, 9), "connect": (3.0, 1.0)},
    "moderna_brush_lettering": {"f": "latino", "g": "Corsive molto inclinate (punta flessibile)", "slant": (28, 12), "connect": (2.9, 1.2)},
    # --- arabi / persiani --------------------------------------------------
    "araba_hijazi":    {"f": "arabo", "g": "Arabo", "ang": (1.5, 1.0), "curve": (.35, .2), "ortho": (.40, .25), "horiz": (.45, .2), "drift": (0, 12)},
    "araba_kufico":    {"f": "arabo", "g": "Arabo", "ang": (3.0, 1.2), "curve": (.08, .10), "ortho": (.85, .15), "horiz": (.55, .2), "drift": (0, 6)},
    "araba_naskh":     {"f": "arabo", "g": "Arabo", "ang": (.9, .8),  "curve": (.55, .2), "ortho": (.35, .2),  "horiz": (.45, .2), "drift": (0, 8)},
    "araba_thuluth":   {"f": "arabo", "g": "Arabo", "ang": (.6, .6),  "curve": (.70, .2), "ortho": (.30, .2),  "horiz": (.40, .2), "drift": (0, 12)},
    "araba_maghribi":  {"f": "arabo", "g": "Arabo", "ang": (.8, .8),  "curve": (.60, .2), "ortho": (.30, .2),  "horiz": (.50, .2), "drift": (0, 8)},
    "araba_nastaliq":  {"f": "arabo", "g": "Arabo", "ang": (.5, .6),  "curve": (.70, .2), "ortho": (.20, .15), "horiz": (.40, .2), "drift": (-18, 10)},
    # --- Asia orientale (cinese/giapponese: geometria non distinguibile) ----
    "cinese_oracolare": {"f": "cjk", "g": "Asia orientale", "ang": (2.5, 1.2), "curve": (.12, .12), "ortho": (.35, .2), "connect": (.9, .5), "nstroke": (4, 2)},
    "cinese_zhuanshu":  {"f": "cjk", "g": "Asia orientale", "ang": (.5, .5),  "curve": (.60, .2),  "ortho": (.55, .2), "connect": (1.4, .6), "nstroke": (4, 2), "closed": (.3, .3)},
    "cinese_lishu":     {"f": "cjk", "g": "Asia orientale", "ang": (1.8, 1.0), "curve": (.20, .15), "ortho": (.80, .15), "horiz": (.55, .15), "aspect": (1.3, .3), "nstroke": (5, 2)},
    "cinese_kaishu":    {"f": "cjk", "g": "Asia orientale", "ang": (1.8, 1.0), "curve": (.22, .15), "ortho": (.70, .2), "aspect": (1.0, .3), "connect": (.9, .4), "nstroke": (5, 2)},
    "cinese_xingshu":   {"f": "cjk", "g": "Asia orientale", "ang": (1.2, .9), "curve": (.40, .2),  "ortho": (.45, .2), "connect": (1.6, .7), "nstroke": (3, 1.5)},
    "cinese_caoshu":    {"f": "cjk", "g": "Asia orientale", "ang": (.8, .7),  "curve": (.60, .2),  "ortho": (.25, .15), "connect": (2.6, 1.0), "nstroke": (1.8, 1.0)},
    "giapponese_kaisho": {"f": "cjk", "g": "Asia orientale", "ang": (1.8, 1.0), "curve": (.22, .15), "ortho": (.70, .2), "aspect": (1.0, .3), "connect": (.9, .4), "nstroke": (5, 2)},
    "giapponese_gyosho": {"f": "cjk", "g": "Asia orientale", "ang": (1.2, .9), "curve": (.40, .2),  "ortho": (.45, .2), "connect": (1.6, .7), "nstroke": (3, 1.5)},
    "giapponese_sosho":  {"f": "cjk", "g": "Asia orientale", "ang": (.8, .7),  "curve": (.60, .2),  "ortho": (.25, .15), "connect": (2.6, 1.0), "nstroke": (1.8, 1.0)},
    "giapponese_kana":   {"f": "cjk", "g": "Asia orientale", "ang": (.6, .6),  "curve": (.65, .2),  "ortho": (.20, .15), "connect": (2.2, 1.0), "nstroke": (2, 1.0)},
}

# Alias di nome visualizzato -> id, nell'ordine di controllo (i più specifici prima).
_ALIAS_ID = [
    ("semionciale", "occidentale_semionciale"), ("onciale", "occidentale_onciale"),
    ("carolina", "occidentale_carolina"), ("umanistica", "occidentale_umanistica"),
    ("textura quadrata", "occidentale_textura_quadrata"), ("textura", "occidentale_textura"),
    ("rotunda", "occidentale_rotunda"), ("fraktur", "occidentale_fraktur"),
    ("bâtarde", "occidentale_batarde_francaise"), ("batarde", "occidentale_batarde_francaise"),
    ("gotica cursiva", "occidentale_gotica_cursiva"), ("bastarda", "occidentale_bastarda"),
    ("kurrent", "occidentale_kurrent"), ("sütterlin", "occidentale_sutterlin"),
    ("sutterlin", "occidentale_sutterlin"), ("cancelleresca", "occidentale_cancelleresca"),
    ("italica", "occidentale_cancelleresca"), ("copperplate", "occidentale_copperplate"),
    ("roundhand", "occidentale_copperplate"), ("spencerian", "occidentale_spencerian"),
    ("capitale romana", "occidentale_capitale_romana"), ("capitalis monumentalis", "occidentale_capitale_romana"),
    ("rustica", "occidentale_rustica"), ("brush", "moderna_brush_lettering"),
    ("hijazi", "araba_hijazi"), ("cufico", "araba_kufico"), ("kufic", "araba_kufico"),
    ("naskh", "araba_naskh"), ("thuluth", "araba_thuluth"), ("maghribi", "araba_maghribi"),
    ("nasta", "araba_nastaliq"), ("oracolar", "cinese_oracolare"), ("zhuanshu", "cinese_zhuanshu"),
    ("lishu", "cinese_lishu"), ("kaishu", "cinese_kaishu"), ("xingshu", "cinese_xingshu"),
    ("caoshu", "cinese_caoshu"), ("kaisho", "giapponese_kaisho"), ("gyōsho", "giapponese_gyosho"),
    ("gyosho", "giapponese_gyosho"), ("sōsho", "giapponese_sosho"), ("sosho", "giapponese_sosho"),
    ("kana", "giapponese_kana"),
]


def id_da_nome(nome):
    """Restituisce l'id del catalogo per un nome di stile (None se sconosciuto)."""
    chiave = (nome or "").casefold()
    for token, stile_id in _ALIAS_ID:
        if token in chiave:
            return stile_id
    return None


# ----------------------------------------------------------------------------
# Geometria di base
# ----------------------------------------------------------------------------
def _pulisci(strokes):
    """Accetta liste di punti (x, y[, p]) oppure dict {'points': [...]}."""
    out = []
    for s in strokes or []:
        pts = s.get("points", []) if isinstance(s, dict) else s
        pulito = []
        for p in pts:
            try:
                q = (float(p[0]), float(p[1]))
            except (TypeError, ValueError, IndexError, AttributeError):
                try:
                    q = (float(p.x()), float(p.y()))
                except Exception:
                    continue
            if not pulito or math.dist(q, pulito[-1]) > 0.5:
                pulito.append(q)
        if pulito:
            out.append(pulito)
    return out


def _lunghezza(pts):
    return sum(math.dist(a, b) for a, b in zip(pts, pts[1:]))


def _bbox(pts):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _leviga(pts, finestra=2):
    """Media mobile leggera: attenua il tremolio del mouse senza arrotondare gli angoli."""
    if len(pts) < 5:
        return pts
    out = [pts[0]]
    for i in range(1, len(pts) - 1):
        a = max(0, i - finestra // 2); b = min(len(pts), i + finestra // 2 + 1)
        seg = pts[a:b]
        out.append((sum(p[0] for p in seg) / len(seg), sum(p[1] for p in seg) / len(seg)))
    out.append(pts[-1])
    return out


def _ricampiona(pts, passo):
    """Punti equidistanti lungo il percorso."""
    if len(pts) < 2 or passo <= 0:
        return list(pts)
    out = [pts[0]]
    resto = passo
    for a, b in zip(pts, pts[1:]):
        d = math.dist(a, b)
        if d == 0:
            continue
        pos = 0.0
        while d - pos >= resto:
            pos += resto
            t = pos / d
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
            resto = passo
        resto -= d - pos
    if math.dist(out[-1], pts[-1]) > passo * 0.4:
        out.append(pts[-1])
    return out


def _angolo_svolta(p0, p1, p2):
    """Svolta in gradi (0 = dritto) nel punto p1."""
    a1 = math.atan2(p1[1] - p0[1], p1[0] - p0[0])
    a2 = math.atan2(p2[1] - p1[1], p2[0] - p1[0])
    d = math.degrees(a2 - a1)
    while d > 180: d -= 360
    while d < -180: d += 360
    return abs(d)


def _raggruppa(tratti):
    """Raggruppa i tratti in 'caratteri' per sovrapposizione orizzontale."""
    if not tratti:
        return []
    voci = sorted(((_bbox(t), i) for i, t in enumerate(tratti)), key=lambda v: v[0][0])
    gruppi = []
    for (x0, y0, x1, y1), i in voci:
        if gruppi:
            g = gruppi[-1]
            tol = 0.12 * max(g["x1"] - g["x0"], x1 - x0, 1.0)
            if x0 <= g["x1"] + tol:
                g["x1"] = max(g["x1"], x1); g["y0"] = min(g["y0"], y0); g["y1"] = max(g["y1"], y1)
                g["idx"].append(i)
                continue
        gruppi.append({"x0": x0, "x1": x1, "y0": y0, "y1": y1, "idx": [i]})
    return gruppi


# ----------------------------------------------------------------------------
# Estrazione delle caratteristiche
# ----------------------------------------------------------------------------
def estrai_caratteristiche(strokes):
    """Calcola le misure usate dal riconoscimento. Restituisce None se mancano dati."""
    tratti = _pulisci(strokes)
    tratti = [t for t in tratti if len(t) >= 2 or True]
    if not tratti:
        return None

    # Altezza di riferimento H: mediana delle altezze dei gruppi non puntiformi.
    gruppi0 = _raggruppa(tratti)
    altezze = [g["y1"] - g["y0"] for g in gruppi0 if g["y1"] - g["y0"] > 4]
    larghezze = [g["x1"] - g["x0"] for g in gruppi0 if g["x1"] - g["x0"] > 4]
    if not altezze and not larghezze:
        return None
    H = median(altezze) if altezze else median(larghezze)
    H = max(H, 12.0)

    # Puntini: tratti molto corti rispetto ad H.
    puntini = [t for t in tratti if _lunghezza(t) < 0.22 * H]
    corpo = [t for t in tratti if _lunghezza(t) >= 0.22 * H]
    if not corpo:
        return None

    gruppi = _raggruppa(corpo)
    passo = max(2.5, H * 0.06)
    lungh_totale = 0.0
    corner = 0
    curvo = 0
    rettilineo = 0
    campioni = 0
    ortho_len = 0.0
    horiz_len = 0.0
    slant_voci = []        # (angolo, peso)
    chiusi = 0
    lunghe = 0
    lunghezze_tratti = []
    sx_sinistra = 0
    sx_tot = 0

    for t in corpo:
        L = _lunghezza(t)
        lunghezze_tratti.append(L / H)
        r = _ricampiona(_leviga(t), passo)
        if len(r) < 3:
            continue
        lungh_totale += L
        # Chiusura a ovale
        if L >= 1.5 * H * 0.6 and math.dist(t[0], t[-1]) < 0.28 * H:
            chiusi += 1
        if L >= 0.6 * H:
            lunghe += 1
        # Direzione orizzontale dei tratti lunghi in senso orizzontale
        if abs(t[-1][0] - t[0][0]) > 0.8 * H:
            sx_tot += 1
            if t[-1][0] < t[0][0]:
                sx_sinistra += 1
        # Segmenti: inclinazione, assi
        i = 0
        ultimo_corner = -10
        for k in range(1, len(r) - 1):
            svolta = _angolo_svolta(r[k - 1], r[k], r[k + 1])
            campioni += 1
            if svolta > 55 and k - ultimo_corner >= 3:
                corner += 1; ultimo_corner = k
            elif 7 <= svolta <= 45:
                curvo += 1
            elif svolta < 7:
                rettilineo += 1
        for a, b in zip(r, r[1:]):
            dx, dy = b[0] - a[0], b[1] - a[1]
            d = math.hypot(dx, dy)
            if d < 1e-6:
                continue
            ang_x = abs(math.degrees(math.atan2(dy, dx)))      # 0..180 rispetto all'orizzontale
            ang_x = min(ang_x, 180 - ang_x)                     # 0..90
            if ang_x < 12 or ang_x > 78:
                ortho_len += d
            if ang_x < 20:
                horiz_len += d
            # inclinazione dalla verticale (segno: + = parte alta a destra)
            if dy > 0:
                dx, dy = -dx, -dy
            theta = math.degrees(math.atan2(dx, -dy))
            if abs(theta) <= 60 and ang_x > 30:
                slant_voci.append((theta, d))

    if lungh_totale <= 0:
        return None

    # Inclinazione: mediana pesata
    slant = None
    peso_slant = sum(w for _, w in slant_voci)
    if peso_slant >= 0.15 * lungh_totale and slant_voci:
        voci = sorted(slant_voci)
        meta = peso_slant / 2.0
        acc = 0.0
        for th, w in voci:
            acc += w
            if acc >= meta:
                slant = th
                break

    # Proporzione delle lettere (mediana sui gruppi)
    aspetti = []
    for g in gruppi:
        w = g["x1"] - g["x0"]; h = g["y1"] - g["y0"]
        if h > 0.35 * H and w > 0 and w < 2.2 * H:
            aspetti.append(w / h)
    aspect = median(aspetti) if aspetti else None

    # Direzione di scrittura (destra -> sinistra)
    rtl = None
    cx = []
    for t in corpo:
        x0, y0, x1, y1 = _bbox(t)
        cx.append((x0 + x1) / 2)
    parti = []
    if len(cx) >= 3:
        mosse = [(b - a) for a, b in zip(cx, cx[1:]) if abs(b - a) > 0.15 * H]
        if len(mosse) >= 2:
            parti.append(sum(1 for m in mosse if m < 0) / len(mosse))
    if sx_tot >= 2:
        parti.append(sx_sinistra / sx_tot)
    if parti:
        rtl = sum(parti) / len(parti)

    # Pendenza della riga (per il nastaʿliq): regressione sui centroidi dei gruppi
    drift = None
    if len(gruppi) >= 3:
        xs = [(g["x0"] + g["x1"]) / 2 for g in gruppi]
        ys = [(g["y0"] + g["y1"]) / 2 for g in gruppi]
        mx = sum(xs) / len(xs); my = sum(ys) / len(ys)
        den = sum((x - mx) ** 2 for x in xs)
        if den > 1e-6:
            drift = math.degrees(math.atan(sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den))

    n_gruppi = len(gruppi)
    tratti_per_gruppo = median([len(g["idx"]) for g in gruppi])
    largo_max = max((g["x1"] - g["x0"]) / H for g in gruppi)

    estensione = (max(g["x1"] for g in gruppi) - min(g["x0"] for g in gruppi)) / H
    densita = len(corpo) / max(estensione, 0.6)   # tratti per altezza di larghezza
    unita = lungh_totale / H            # lunghezza del percorso in altezze di lettera
    caratt = {
        "H": H,
        "n_tratti": len(corpo),
        "n_gruppi": n_gruppi,
        "puntini": len(puntini),
        "slant": slant,
        "aspect": aspect,
        "ang": corner / unita if unita else 0.0,
        "curve": curvo / campioni if campioni else 0.0,
        "dritto": rettilineo / campioni if campioni else 0.0,
        "connect": median(lunghezze_tratti),
        "ortho": ortho_len / lungh_totale,
        "horiz": horiz_len / lungh_totale,
        "closed": chiusi / max(1, lunghe),
        "nstroke": tratti_per_gruppo,
        "rtl": rtl,
        "drift": drift,
        "largo_max": largo_max,
        "densita": densita,
        "percorso_in_H": unita,
    }
    return caratt


# ----------------------------------------------------------------------------
# Punteggio
# ----------------------------------------------------------------------------
def _sim(valore, atteso):
    media, tol = atteso
    return math.exp(-0.5 * ((valore - media) / tol) ** 2)


def _rampa(x, x0, x1):
    """0 sotto x0, 1 sopra x1, lineare in mezzo."""
    if x1 == x0:
        return 1.0 if x >= x1 else 0.0
    return max(0.0, min(1.0, (x - x0) / (x1 - x0)))


def _probabilita_famiglia(c, forzata=None):
    """Stima grossolana della famiglia di scrittura: latino / arabo / cjk.

    Latino e CJK sono geometricamente vicini con pochi tratti: per questo si parte
    da un prior favorevole al latino e si può forzare la famiglia dall'interfaccia.
    """
    if forzata in ("latino", "arabo", "cjk"):
        return {k: (1.0 if k == forzata else 0.0) for k in ("latino", "arabo", "cjk")}
    pun_rel = c["puntini"] / max(1, c["n_gruppi"])
    # Arabo: richiede evidenza di scrittura da destra a sinistra
    ar = [_rampa(c["horiz"], 0.20, 0.50), _rampa(c["largo_max"], 1.4, 3.0), _rampa(pun_rel, 0.0, 0.6)]
    arabo = sum(ar) / len(ar)
    if c["rtl"] is None:
        arabo *= 0.35
    else:
        arabo *= _rampa(c["rtl"], 0.45, 0.85)
    # CJK: molti tratti brevi per unità di larghezza (caratteri compatti)
    cjk = _rampa(c["densita"], 3.0, 6.0)
    if c["aspect"] is not None:
        cjk *= 0.5 + 0.5 * _sim(c["aspect"], (1.0, .4))
    latino = 0.55 * (1.0 - cjk) * (1.0 - arabo) + 0.15
    tot = arabo + cjk + latino
    return {"latino": latino / tot, "arabo": arabo / tot, "cjk": cjk / tot}


def _punteggio_stile(c, profilo):
    pesi = 0.0
    somma = 0.0
    dettagli = {}
    for chiave, atteso in profilo.items():
        if chiave in ("f", "g"):
            continue
        valore = c.get(chiave)
        if valore is None:
            continue
        # Misure più discriminanti pesano di più
        peso = {"slant": 1.6, "aspect": 1.0, "ang": 0.8, "curve": 0.6, "connect": 1.6,
                "ortho": 1.0, "horiz": 0.8, "closed": 0.5, "nstroke": 0.8, "drift": 1.2}.get(chiave, 1.0)
        s = _sim(valore, atteso)
        dettagli[chiave] = s
        somma += s * peso
        pesi += peso
    if pesi == 0:
        return 0.0, dettagli
    return somma / pesi, dettagli


def _affidabilita(c):
    punti = 0
    if c["percorso_in_H"] >= 12: punti += 1
    if c["n_tratti"] >= 4: punti += 1
    if c["n_gruppi"] >= 3: punti += 1
    return {0: "molto bassa", 1: "bassa", 2: "media", 3: "buona"}[punti]


def _nome(stile_id):
    try:
        from biblioteca_stili import trova_stile
        s = trova_stile(stile_id)
        if s:
            return s["nome"]
    except Exception:
        pass
    return stile_id


def riconosci_stile(strokes, top=5, famiglia=None):
    """Analizza i tratti e restituisce un dizionario con i risultati.

    strokes: lista di tratti. Ogni tratto è una lista di punti (x, y[, pressione])
    oppure un dict con la chiave 'points' (come in CalligraphyCanvas.strokes).
    famiglia: None (automatica) oppure 'latino' / 'arabo' / 'cjk' per forzare la famiglia.
    """
    c = estrai_caratteristiche(strokes)
    if c is None:
        return {"ok": False, "messaggio": "Non ci sono abbastanza tratti: disegna almeno una parola (4-5 lettere) o 3-4 caratteri e riprova."}

    fam = _probabilita_famiglia(c, famiglia)
    classifica = []
    for stile_id, prof in PROFILI.items():
        punteggio, dett = _punteggio_stile(c, prof)
        classifica.append({"id": stile_id, "nome": _nome(stile_id), "gruppo": prof["g"],
                           "famiglia": prof["f"], "punteggio": punteggio, "dettagli": dett})
    # Peso della famiglia: gli stili di una famiglia improbabile vengono attenuati
    for voce in classifica:
        voce["peso"] = voce["punteggio"] * (0.25 + 0.75 * fam[voce["famiglia"]] * 1.0) if True else 0
    classifica.sort(key=lambda v: v["peso"], reverse=True)

    # Normalizzazione in "confidenza" (softmax con temperatura): somma ~100 %
    T = 0.06
    mx = classifica[0]["peso"]
    esp = [math.exp((v["peso"] - mx) / T) for v in classifica]
    s = sum(esp)
    for v, e in zip(classifica, esp):
        v["confidenza"] = round(100.0 * e / s, 1)

    # Gruppo (famiglia paleografica) più probabile
    per_gruppo = {}
    for v in classifica:
        per_gruppo[v["gruppo"]] = per_gruppo.get(v["gruppo"], 0.0) + v["confidenza"]
    gruppo_top = max(per_gruppo.items(), key=lambda kv: kv[1])

    famiglia_top = max(fam.items(), key=lambda kv: kv[1])[0]
    avvisi = []
    aff = _affidabilita(c)
    if aff in ("molto bassa", "bassa"):
        avvisi.append("Pochi dati: scrivi una parola intera di 4-5 lettere (o più caratteri) per un risultato meno casuale.")
    avvisi.append("Con il mouse non si vede la pressione: contrasto tra pieni e filetti non è misurabile. Stili vicini restano facilmente confondibili.")
    if famiglia_top == "cjk":
        avvisi.append("Cinese e giapponese hanno la stessa geometria di base: kaishu/kaisho, xingshu/gyōsho e caoshu/sōsho vanno considerati equivalenti.")

    return {
        "ok": True,
        "famiglia_script": famiglia_top,
        "probabilita_famiglia": {k: round(100 * v, 1) for k, v in fam.items()},
        "gruppo": gruppo_top[0],
        "gruppo_confidenza": round(gruppo_top[1], 1),
        "stili": classifica[:top],
        "caratteristiche": c,
        "affidabilita": aff,
        "motivazioni": _motivazioni(c, famiglia_top),
        "avvisi": avvisi,
    }


def _motivazioni(c, famiglia):
    r = []
    if c.get("slant") is not None and famiglia == "latino":
        s = c["slant"]
        if abs(s) < 6: r.append(f"Aste quasi verticali (inclinazione {s:+.0f}°): tipico di maiuscole, onciali, carolina e gotiche librarie.")
        elif s < 22: r.append(f"Inclinazione moderata ({s:+.0f}°): compatibile con cancelleresca, bastarda e corsive tedesche.")
        else: r.append(f"Forte inclinazione ({s:+.0f}°): tipica delle corsive a punta flessibile (copperplate, spencerian).")
    if c.get("aspect") is not None and famiglia == "latino":
        a = c["aspect"]
        r.append("Lettere strette (larghezza/altezza {:.2f}): ritmo verticale, tipico delle gotiche e delle corsive.".format(a) if a < .62
                 else "Lettere larghe (larghezza/altezza {:.2f}): tipico di onciale, rotunda e carolina.".format(a) if a > .9
                 else "Proporzioni medie delle lettere (larghezza/altezza {:.2f}).".format(a))
    if c["ang"] > 2.2:
        r.append("Molti angoli netti e spezzature: richiama le scritture gotiche o i tratti angolari.")
    elif c["curve"] > 0.55:
        r.append("Prevalenza di curve continue: richiama scritture rotonde o corsive.")
    if c["connect"] > 6:
        r.append("Tratti lunghi e collegati (pochi stacchi della penna): scrittura corsiva.")
    elif c["connect"] < 3:
        r.append("Molti stacchi della penna: scrittura libraria o maiuscola, non corsiva.")
    if famiglia == "arabo":
        r.append("Scrittura procede da destra a sinistra con tratti orizzontali e puntini: struttura compatibile con l'arabo.")
    if famiglia == "cjk":
        r.append("Molti tratti brevi per carattere, forma compatta: struttura compatibile con caratteri dell'Asia orientale.")
    return r


# ----------------------------------------------------------------------------
# Presentazione (HTML per QTextBrowser)
# ----------------------------------------------------------------------------
def formatta_risultato_html(ris):
    import html as _h
    if not ris.get("ok"):
        return f"<p>{_h.escape(ris.get('messaggio', 'Riconoscimento non disponibile.'))}</p>"
    nomi_fam = {"latino": "alfabeto latino", "arabo": "scrittura araba/persiana", "cjk": "scrittura dell'Asia orientale"}
    h = ["<h3 style='color:#573417'>Stile riconosciuto (stima)</h3>"]
    h.append(f"<p><b>Famiglia di scrittura:</b> {nomi_fam.get(ris['famiglia_script'], ris['famiglia_script'])} "
             f"· <b>Gruppo più probabile:</b> {_h.escape(ris['gruppo'])} ({ris['gruppo_confidenza']:.0f} %) "
             f"· <b>Affidabilità dei dati:</b> {ris['affidabilita']}</p>")
    h.append("<table cellpadding='4'><tr><th align='left'>Stile</th><th>Confidenza</th></tr>")
    for v in ris["stili"][:5]:
        h.append(f"<tr><td>{_h.escape(v['nome'])}</td><td align='right'>{v['confidenza']:.0f} %</td></tr>")
    h.append("</table>")
    if ris["motivazioni"]:
        h.append("<p><b>Cosa ho osservato:</b></p><ul>" + "".join(f"<li>{_h.escape(m)}</li>" for m in ris["motivazioni"]) + "</ul>")
    c = ris["caratteristiche"]
    sl = "n/d" if c["slant"] is None else f"{c['slant']:+.0f}°"
    asp = "n/d" if c["aspect"] is None else f"{c['aspect']:.2f}"
    h.append(f"<p style='color:#6b5a45'><i>Misure: inclinazione {sl}, proporzione {asp}, angoli {c['ang']:.1f}, "
             f"curve {100*c['curve']:.0f} %, tratti/lettera {c['nstroke']:.0f}, tratti {c['n_tratti']}.</i></p>")
    for a in ris["avvisi"]:
        h.append(f"<p style='color:#8a5a22'>⚠ {_h.escape(a)}</p>")
    h.append("<p><i>Stima euristica a scopo didattico: non è una perizia paleografica.</i></p>")
    return "".join(h)
