"""Ductus per stile: forme delle lettere, ordine dei tratti e angolo della penna.

A differenza delle varianti generiche di stili_modelli.py (che deformano lo stesso
alfabeto), qui ogni stile ha i propri tracciati, tratto per tratto, ciascuno con
un nome (asta, pancia, traversa...). L'ordine e la forma sono SCHEMI DIDATTICI
ricavati dalla descrizione paleografica generale di ogni scrittura: vanno
confrontati con un facsimile preciso prima di usarli come modello storico.
Coordinate normalizzate: corpo della lettera tra y=.28 e y=.77, ascendenti fino a
.12, discendenti fino a .94.
"""
import math

try:
    from riconoscimento_stile import id_da_nome
except ImportError:
    id_da_nome = lambda nome: None

# Angolo del taglio della penna rispetto alla riga (gradi, valori didattici).
NIB_ANGOLI = {
    "occidentale_onciale": 28, "occidentale_semionciale": 30, "occidentale_carolina": 30,
    "occidentale_umanistica": 30, "occidentale_textura": 42, "occidentale_textura_quadrata": 45,
    "occidentale_rotunda": 35, "occidentale_fraktur": 40, "occidentale_rustica": 30,
    "occidentale_capitale_romana": 25, "occidentale_bastarda": 35, "occidentale_cancelleresca": 40,
    "occidentale_gotica_cursiva": 35, "occidentale_batarde_francaise": 35,
}

# ----------------------------------------------------------------------------
# ONCIALE (maiuscola libraria rotonda). Ogni voce: lettera -> [(nome tratto, punti)]
# ----------------------------------------------------------------------------
_ONC = {
    "A": [("pancia (curva sinistra)", [(.58, .32), (.46, .28), (.34, .38), (.32, .58), (.42, .74), (.58, .68)]),
          ("asta destra con piede", [(.60, .30), (.58, .55), (.62, .77)])],
    "B": [("asta", [(.30, .26), (.30, .77)]),
          ("pancia superiore", [(.30, .28), (.52, .26), (.62, .36), (.52, .50), (.30, .50)]),
          ("pancia inferiore", [(.30, .50), (.56, .52), (.66, .64), (.54, .77), (.30, .76)])],
    "C": [("curva unica", [(.64, .34), (.52, .27), (.38, .32), (.30, .50), (.38, .70), (.54, .77), (.66, .70)])],
    "D": [("pancia", [(.58, .30), (.44, .28), (.32, .42), (.32, .62), (.44, .76), (.58, .68), (.62, .50)]),
          ("asta ricurva a sinistra", [(.60, .60), (.62, .35), (.54, .18), (.40, .12)])],
    "E": [("curva", [(.62, .38), (.50, .28), (.36, .34), (.30, .52), (.38, .70), (.52, .77), (.64, .70)]),
          ("traversa", [(.34, .52), (.62, .50)])],
    "F": [("asta discendente", [(.48, .26), (.46, .94)]),
          ("braccio superiore", [(.48, .28), (.58, .24), (.68, .30)]),
          ("traversa", [(.34, .52), (.62, .50)])],
    "G": [("curva (testa piatta)", [(.64, .32), (.48, .28), (.34, .38), (.32, .58), (.44, .74), (.58, .70)]),
          ("coda sotto il rigo", [(.58, .52), (.60, .76), (.54, .90), (.40, .94)])],
    "H": [("asta alta", [(.34, .12), (.34, .77)]),
          ("arco con piede", [(.34, .46), (.48, .32), (.62, .38), (.64, .60), (.60, .77), (.68, .74)])],
    "I": [("asta", [(.50, .26), (.50, .77)])],
    "K": [("asta alta", [(.34, .12), (.34, .77)]),
          ("braccio e gamba", [(.64, .28), (.36, .52), (.66, .77)])],
    "L": [("asta con piede curvo", [(.40, .12), (.40, .70), (.52, .77), (.66, .74)])],
    "M": [("braccio sinistro", [(.40, .30), (.28, .40), (.28, .62), (.34, .77)]),
          ("V centrale", [(.40, .30), (.51, .60), (.62, .30)]),
          ("braccio destro", [(.62, .30), (.74, .40), (.74, .62), (.68, .77)])],
    "N": [("asta sinistra", [(.30, .30), (.30, .77)]),
          ("diagonale", [(.30, .30), (.62, .77)]),
          ("asta destra", [(.62, .77), (.66, .30)])],
    "O": [("metà sinistra", [(.54, .28), (.40, .32), (.32, .52), (.40, .72), (.54, .77)]),
          ("metà destra", [(.50, .28), (.64, .34), (.70, .54), (.62, .72), (.50, .77)])],
    "P": [("asta discendente", [(.34, .30), (.34, .94)]),
          ("pancia", [(.34, .32), (.54, .28), (.66, .40), (.58, .56), (.34, .56)])],
    "Q": [("pancia", [(.58, .30), (.44, .28), (.32, .42), (.32, .62), (.44, .76), (.58, .70)]),
          ("asta discendente", [(.60, .30), (.60, .94)])],
    "R": [("asta", [(.34, .28), (.34, .77)]),
          ("pancia", [(.34, .30), (.54, .28), (.64, .40), (.54, .54), (.34, .54)]),
          ("gamba", [(.50, .54), (.66, .77)])],
    "S": [("curva a S", [(.64, .34), (.52, .28), (.38, .34), (.40, .48), (.56, .54), (.64, .66), (.52, .76), (.36, .72)])],
    "T": [("barra curva", [(.30, .34), (.38, .28), (.62, .28), (.70, .34)]),
          ("asta", [(.50, .28), (.50, .77)])],
    "U": [("curva sinistra", [(.32, .28), (.33, .62), (.45, .76), (.60, .68)]),
          ("asta destra", [(.64, .28), (.62, .77)])],
    "V": [("V", [(.30, .28), (.48, .77), (.66, .28)])],
    "X": [("diagonale discendente", [(.32, .28), (.66, .77)]),
          ("diagonale ascendente", [(.66, .28), (.32, .77)])],
    "Y": [("braccio sinistro", [(.32, .28), (.50, .58)]),
          ("braccio destro e coda", [(.68, .28), (.50, .58), (.46, .94)])],
    "Z": [("Z", [(.34, .30), (.64, .30), (.34, .76), (.66, .76)])],
}
_ONC_NOTE = {
    "D": "La D onciale ha la pancia tonda e l'asta che si piega a sinistra in alto: non è la D capitale.",
    "E": "La E è tonda, tipo «ε»: la traversa è l'ultimo tratto.",
    "G": "La G ha la testa piatta e la coda sotto il rigo; spesso ricorda una «ɡ» aperta.",
    "H": "La H ha l'asta alta e un arco che scende a destra con un piede; non ha la traversa della capitale.",
    "M": "La M è tonda: due bracci curvi e una V centrale che non scende fino alla riga.",
    "T": "La barra superiore curva si traccia prima dell'asta.",
    "O": "Le lettere tonde si fanno in due tratti (metà sinistra e metà destra), senza ruotare la penna.",
}

# ----------------------------------------------------------------------------
# TEXTURA (gotica libraria). Aste con testa e piede a losanga, curve spezzate.
# ----------------------------------------------------------------------------
def _asta(x, top=.29, bot=.73, nome="asta"):
    return (nome, [(x - .035, top + .03), (x, top), (x, bot), (x + .04, bot + .04)])


_TEX = {
    "i": [_asta(.50)],
    "l": [("asta alta", [(.46, .17), (.50, .12), (.50, .73), (.54, .77)])],
    "n": [_asta(.36), ("arco spezzato e asta", [(.36, .38), (.43, .29), (.57, .29), (.63, .36), (.63, .73), (.67, .77)])],
    "m": [_asta(.30), ("primo arco e asta", [(.30, .38), (.36, .29), (.45, .29), (.50, .36), (.50, .73), (.54, .77)]),
          ("secondo arco e asta", [(.50, .38), (.56, .29), (.65, .29), (.70, .36), (.70, .73), (.74, .77)])],
    "u": [("asta con piede che risale", [(.34, .29), (.34, .68), (.42, .77), (.50, .70)]), _asta(.64, nome="seconda asta")],
    "o": [("metà sinistra spezzata", [(.54, .28), (.42, .35), (.42, .70), (.54, .77)]),
          ("metà destra spezzata", [(.54, .28), (.66, .35), (.66, .70), (.54, .77)])],
    "c": [("curva spezzata", [(.62, .29), (.44, .35), (.44, .70), (.62, .77)]),
          ("terminale superiore", [(.58, .28), (.66, .30), (.66, .38)])],
    "e": [("curva spezzata", [(.62, .29), (.44, .35), (.44, .70), (.62, .77)]),
          ("terminale superiore", [(.58, .28), (.66, .30), (.66, .38)]),
          ("traversa", [(.46, .52), (.62, .50)])],
    "a": [("occhiello superiore", [(.62, .34), (.46, .32), (.42, .44), (.50, .52), (.62, .50)]),
          ("pancia inferiore", [(.46, .54), (.42, .66), (.50, .77), (.62, .74)]),
          _asta(.62, top=.28, nome="asta destra")],
    "b": [("asta alta", [(.36, .17), (.40, .12), (.40, .73), (.44, .77)]),
          ("pancia", [(.40, .34), (.58, .30), (.64, .42), (.64, .66), (.56, .76), (.40, .74)])],
    "d": [("pancia", [(.60, .30), (.46, .34), (.42, .50), (.46, .68), (.60, .76)]),
          ("asta ricurva a sinistra", [(.54, .20), (.62, .12), (.62, .73), (.66, .77)])],
    "h": [("asta alta", [(.36, .17), (.40, .12), (.40, .73), (.44, .77)]),
          ("arco spezzato con piede", [(.40, .40), (.46, .30), (.58, .30), (.64, .38), (.64, .70), (.60, .77), (.54, .76)])],
    "p": [("asta discendente", [(.34, .31), (.38, .27), (.38, .94)]),
          ("pancia", [(.38, .34), (.56, .30), (.64, .42), (.64, .62), (.56, .74), (.38, .72)])],
    "q": [("pancia", [(.60, .30), (.46, .34), (.42, .50), (.46, .66), (.60, .72)]),
          ("asta discendente", [(.62, .27), (.62, .94), (.66, .90)])],
    "f": [("gancio e asta", [(.66, .20), (.58, .12), (.48, .16), (.48, .77)]),
          ("traversa", [(.34, .33), (.60, .33)])],
    "t": [("asta con piede", [(.48, .18), (.48, .68), (.56, .77), (.64, .72)]),
          ("traversa", [(.36, .31), (.60, .31)])],
    "r": [_asta(.38), ("spalla", [(.38, .38), (.46, .30), (.58, .30), (.62, .38)])],
    "s": [("s breve spezzata", [(.62, .30), (.46, .30), (.42, .42), (.58, .54), (.62, .66), (.46, .76), (.40, .72)])],
    "g": [("occhiello", [(.60, .30), (.46, .30), (.42, .44), (.52, .54), (.62, .46), (.60, .30)]),
          ("coda sotto il rigo", [(.60, .46), (.60, .82), (.50, .94), (.38, .88)])],
    "j": [("asta con coda", [(.50, .29), (.50, .84), (.40, .94), (.32, .88)])],
    "k": [("asta alta", [(.36, .17), (.40, .12), (.40, .73), (.44, .77)]),
          ("braccio", [(.64, .30), (.42, .55)]), ("gamba", [(.46, .50), (.66, .77)])],
    "v": [("V spezzata", [(.34, .28), (.50, .77), (.66, .28)])],
    "w": [("prima V", [(.26, .28), (.38, .77), (.50, .28)]), ("seconda V", [(.50, .28), (.62, .77), (.74, .28)])],
    "x": [("diagonale discendente", [(.34, .29), (.66, .77)]), ("diagonale ascendente", [(.66, .29), (.34, .77)])],
    "y": [("braccio sinistro", [(.34, .28), (.46, .72)]),
          ("braccio destro e coda", [(.66, .28), (.46, .72), (.44, .90), (.34, .94)])],
    "z": [("Z spezzata", [(.36, .30), (.64, .30), (.38, .76), (.66, .76)])],
}
_TEX_NOTE = {
    "i": "Il ritmo della Textura nasce dalla ripetizione di aste identiche: lo spazio tra due aste è uguale allo spazio dentro la «o».",
    "n": "L'arco non è rotondo: due segmenti diritti che si incontrano in un angolo.",
    "o": "La «o» è un esagono schiacciato: due metà speculari che si toccano in alto e in basso.",
    "s": "In Textura la «s» in mezzo alla parola è lunga (ſ); questa è la forma breve di fine parola.",
    "a": "Occhiello e pancia sono compatti: l'asta destra chiude la lettera con il piede a losanga.",
}


# ----------------------------------------------------------------------------
# CAROLINA (minuscola carolingia): forme aperte e regolari, aste con clava (cuneo).
# ----------------------------------------------------------------------------
_CAR = {
    "a": [("pancia", [(.60, .32), (.46, .28), (.34, .40), (.34, .62), (.46, .76), (.60, .68)]),
          ("asta destra", [(.60, .30), (.60, .77)])],
    "b": [("asta con clava", [(.32, .17), (.38, .12), (.38, .77)]),
          ("pancia", [(.38, .40), (.52, .30), (.64, .42), (.64, .64), (.52, .77), (.38, .72)])],
    "c": [("curva unica", [(.64, .34), (.50, .28), (.38, .34), (.34, .52), (.38, .70), (.52, .77), (.64, .72)])],
    "d": [("pancia", [(.58, .30), (.44, .30), (.34, .44), (.34, .62), (.44, .76), (.58, .72)]),
          ("asta con clava", [(.54, .17), (.60, .12), (.60, .77)])],
    "e": [("traversa", [(.36, .52), (.62, .50)]),
          ("occhio", [(.62, .50), (.60, .36), (.48, .28), (.36, .36), (.34, .54), (.40, .70), (.52, .77), (.64, .70)])],
    "f": [("asta con gancio", [(.62, .20), (.54, .13), (.46, .20), (.46, .77)]),
          ("traversa", [(.36, .34), (.58, .34)])],
    "g": [("occhiello", [(.60, .30), (.44, .28), (.36, .40), (.42, .52), (.60, .52)]),
          ("asta e coda aperta", [(.60, .30), (.60, .72), (.52, .88), (.38, .92), (.34, .84)])],
    "h": [("asta con clava", [(.32, .17), (.38, .12), (.38, .77)]),
          ("arco", [(.38, .46), (.48, .32), (.60, .34), (.64, .48), (.64, .77)])],
    "i": [("asta", [(.50, .30), (.50, .77)])],
    "k": [("asta con clava", [(.32, .17), (.38, .12), (.38, .77)]),
          ("braccio", [(.64, .30), (.40, .54)]), ("gamba", [(.46, .50), (.66, .77)])],
    "l": [("asta con clava", [(.44, .17), (.50, .12), (.50, .77)]),
          ("piede", [(.50, .77), (.58, .74)])],
    "m": [("asta", [(.30, .28), (.30, .77)]),
          ("primo arco", [(.30, .42), (.38, .30), (.48, .30), (.50, .44), (.50, .77)]),
          ("secondo arco", [(.50, .42), (.58, .30), (.68, .30), (.70, .44), (.70, .77)])],
    "n": [("asta", [(.36, .28), (.36, .77)]),
          ("arco", [(.36, .42), (.44, .30), (.56, .30), (.62, .44), (.62, .77)])],
    "o": [("metà sinistra", [(.54, .28), (.42, .32), (.36, .52), (.42, .72), (.54, .77)]),
          ("metà destra", [(.52, .28), (.64, .34), (.68, .52), (.62, .72), (.52, .77)])],
    "p": [("asta discendente", [(.36, .28), (.36, .94)]),
          ("pancia", [(.36, .38), (.52, .30), (.64, .42), (.62, .62), (.50, .74), (.36, .70)])],
    "q": [("pancia", [(.58, .30), (.44, .28), (.34, .42), (.36, .62), (.46, .74), (.58, .72)]),
          ("asta discendente", [(.60, .28), (.60, .94)])],
    "r": [("asta", [(.38, .28), (.38, .77)]),
          ("spalla", [(.38, .44), (.46, .32), (.60, .30), (.64, .38)])],
    "s": [("s breve", [(.62, .32), (.50, .28), (.40, .34), (.44, .46), (.56, .54), (.62, .64), (.54, .76), (.40, .76), (.36, .68)])],
    "t": [("asta con piede", [(.46, .18), (.46, .70), (.54, .77), (.62, .72)]),
          ("traversa", [(.36, .32), (.58, .32)])],
    "u": [("curva sinistra", [(.34, .28), (.35, .64), (.46, .77), (.58, .66)]),
          ("asta destra", [(.62, .28), (.62, .77)])],
    "v": [("V", [(.32, .28), (.48, .77), (.64, .28)])],
    "x": [("diagonale discendente", [(.34, .29), (.64, .77)]), ("diagonale ascendente", [(.64, .29), (.34, .77)])],
    "y": [("braccio sinistro", [(.34, .28), (.46, .72)]),
          ("braccio destro e coda", [(.64, .28), (.46, .72), (.40, .90), (.30, .94)])],
    "z": [("Z", [(.36, .30), (.62, .30), (.36, .76), (.64, .76)])],
}
_CAR_NOTE = {
    "a": "Qui la «a» è aperta, a forma di «ɑ»: nella carolina si trovano anche «a» a due piani; scegli quella del tuo modello.",
    "d": "L'asta è dritta, senza il piegamento dell'onciale: la clava in cima è un piccolo cuneo.",
    "e": "La traversa è leggermente inclinata verso l'alto e va tracciata per prima.",
    "g": "La «g» carolina ha due occhielli: quello superiore chiuso e quello inferiore aperto.",
    "i": "Nella carolina antica la «i» non ha punto.",
    "t": "La «t» è bassa: l'asta non supera di molto il corpo delle altre lettere.",
}

# ----------------------------------------------------------------------------
# CAPITALE ROMANA (Capitalis Monumentalis): maiuscole con grazie principali.
# ----------------------------------------------------------------------------
def _gr(x, y, nome="grazia"):
    return (nome, [(x - .045, y), (x + .045, y)])


_CAP = {
    "A": [("asta sinistra sottile", [(.50, .18), (.28, .78)]), ("asta destra spessa", [(.50, .18), (.72, .78)]),
          ("traversa", [(.37, .56), (.63, .56)]), _gr(.28, .78), _gr(.72, .78)],
    "B": [("asta", [(.32, .18), (.32, .78)]),
          ("pancia superiore", [(.32, .18), (.50, .18), (.62, .24), (.62, .38), (.50, .48), (.32, .48)]),
          ("pancia inferiore", [(.32, .48), (.54, .48), (.68, .56), (.68, .70), (.54, .78), (.32, .78)]),
          _gr(.32, .18), _gr(.32, .78)],
    "C": [("curva unica", [(.70, .30), (.60, .20), (.46, .18), (.32, .28), (.28, .48), (.32, .68), (.46, .78), (.60, .76), (.70, .66)]),
          ("grazia superiore", [(.70, .24), (.70, .34)]), ("grazia inferiore", [(.70, .62), (.70, .72)])],
    "D": [("asta", [(.30, .18), (.30, .78)]),
          ("pancia", [(.30, .18), (.48, .18), (.66, .30), (.70, .48), (.66, .66), (.48, .78), (.30, .78)]),
          _gr(.30, .18), _gr(.30, .78)],
    "E": [("asta", [(.34, .18), (.34, .78)]), ("braccio superiore", [(.34, .18), (.66, .18)]),
          ("braccio medio", [(.34, .48), (.60, .48)]), ("braccio inferiore", [(.34, .78), (.68, .78)]),
          ("grazia superiore", [(.66, .18), (.66, .27)]), ("grazia inferiore", [(.68, .69), (.68, .78)])],
    "F": [("asta", [(.34, .18), (.34, .78)]), ("braccio superiore", [(.34, .18), (.66, .18)]),
          ("braccio medio", [(.34, .48), (.60, .48)]), ("grazia superiore", [(.66, .18), (.66, .27)]), _gr(.34, .78)],
    "G": [("curva unica", [(.70, .30), (.60, .20), (.46, .18), (.32, .28), (.28, .48), (.32, .68), (.46, .78), (.60, .76), (.70, .66), (.70, .52)]),
          ("sperone", [(.56, .52), (.70, .52)])],
    "H": [("asta sinistra", [(.32, .18), (.32, .78)]), ("asta destra", [(.68, .18), (.68, .78)]),
          ("traversa", [(.32, .48), (.68, .48)]), _gr(.32, .18), _gr(.32, .78), _gr(.68, .18), _gr(.68, .78)],
    "I": [("asta", [(.50, .18), (.50, .78)]), _gr(.50, .18), _gr(.50, .78)],
    "K": [("asta", [(.34, .18), (.34, .78)]), ("braccio", [(.66, .18), (.34, .52)]), ("gamba", [(.44, .44), (.68, .78)]),
          _gr(.34, .18), _gr(.34, .78)],
    "L": [("asta", [(.34, .18), (.34, .78)]), ("piede", [(.34, .78), (.66, .78)]),
          ("grazia del piede", [(.66, .70), (.66, .78)]), _gr(.34, .18)],
    "M": [("asta sinistra", [(.28, .18), (.28, .78)]), ("diagonale discendente", [(.28, .18), (.50, .78)]),
          ("diagonale ascendente", [(.50, .78), (.72, .18)]), ("asta destra", [(.72, .18), (.72, .78)])],
    "N": [("asta sinistra", [(.30, .18), (.30, .78)]), ("diagonale", [(.30, .18), (.70, .78)]),
          ("asta destra", [(.70, .78), (.70, .18)])],
    "O": [("metà sinistra", [(.54, .18), (.40, .24), (.30, .48), (.40, .72), (.54, .78)]),
          ("metà destra", [(.50, .18), (.64, .24), (.72, .48), (.64, .72), (.50, .78)])],
    "P": [("asta", [(.32, .18), (.32, .78)]),
          ("pancia", [(.32, .18), (.52, .18), (.66, .26), (.66, .40), (.52, .50), (.32, .50)]), _gr(.32, .78)],
    "Q": [("metà sinistra", [(.54, .18), (.40, .24), (.30, .48), (.40, .72), (.54, .78)]),
          ("metà destra", [(.50, .18), (.64, .24), (.72, .48), (.64, .72), (.50, .78)]),
          ("coda", [(.52, .66), (.72, .90)])],
    "R": [("asta", [(.32, .18), (.32, .78)]),
          ("pancia", [(.32, .18), (.52, .18), (.66, .26), (.66, .40), (.52, .50), (.32, .50)]),
          ("gamba", [(.48, .50), (.70, .78)]), _gr(.32, .78)],
    "S": [("curva a S", [(.66, .28), (.56, .20), (.42, .20), (.34, .30), (.38, .42), (.56, .50), (.66, .60), (.62, .72), (.48, .78), (.34, .76), (.30, .68)])],
    "T": [("barra", [(.28, .18), (.72, .18)]), ("asta", [(.50, .18), (.50, .78)]),
          ("grazia sinistra", [(.28, .18), (.28, .27)]), ("grazia destra", [(.72, .18), (.72, .27)]), _gr(.50, .78)],
    "V": [("diagonale sottile", [(.26, .18), (.50, .78)]), ("diagonale spessa", [(.50, .78), (.74, .18)])],
    "X": [("diagonale sottile", [(.28, .18), (.72, .78)]), ("diagonale spessa", [(.72, .18), (.28, .78)])],
    "Y": [("braccio sinistro", [(.28, .18), (.50, .48)]), ("braccio destro e asta", [(.72, .18), (.50, .48), (.50, .78)])],
    "Z": [("Z", [(.30, .18), (.70, .18), (.30, .78), (.72, .78)])],
}
_CAP_NOTE = {
    "O": "Nella capitale monumentale la «O» è quasi un cerchio: le due metà si toccano con il massimo spessore ai lati.",
    "A": "L'asta sinistra è sottile, la destra spessa: la penna a ≈ 25° produce da sola questo contrasto.",
    "M": "Le aste esterne sono quasi verticali; le grazie vanno aggiunte ai piedi in un secondo momento.",
    "E": "I bracci sono corti, l'inferiore è il più lungo: le grazie verticali chiudono i bracci.",
    "S": "La «S» è la lettera più delicata: la curva superiore è più piccola di quella inferiore.",
}
ALFABETO_CAROLINA = list("abcdefghiklmnopqrstuvxyz") + list("ABCDEFGHIKLMNOPQRSTVXYZ")
ALFABETO_CAPITALE = list("ABCDEFGHIKLMNOPQRSTVXYZ")
_CAROLINA_MAIUSCOLE_NOTA = {c: "Nelle maiuscole carolinge si usavano capitali quadrate: qui la capitale romana, da confrontare con il manoscritto." for c in ALFABETO_CAPITALE}

# ----------------------------------------------------------------------------
# Stili DERIVATI: partono dai tracciati di un altro stile e ne cambiano le
# caratteristiche distintive (arrotondamento, piedi, forcella). Non sono forme
# ricavate da un facsimile: servono a mostrare la differenza di costruzione.
# ----------------------------------------------------------------------------
import re as _re


def _deriva_rotunda():
    """Rotunda: stessa struttura della Textura, ma curve tonde e lettere più larghe."""
    out = {}
    for ch, voci in _TEX.items():
        nuove = []
        for n, p in voci:
            n2 = _re.sub(r" spezzat[oa]", "", n)
            p2 = [(0.5 + (x - 0.5) * 1.18, y) for x, y in p]
            nuove.append((n2, p2))
        out[ch] = nuove
    return out


def _deriva_umanistica():
    """Umanistica: carolina con piedi a grazia sulle aste, 'a' a due piani, proporzioni più larghe."""
    out = {}
    for ch, voci in _CAR.items():
        nuove = []
        for n, p in voci:
            p2 = [(0.5 + (x - 0.5) * 1.08, y) for x, y in p]
            nuove.append((n, p2))
            # piede a grazia dove il tratto finisce in verticale sul rigo di base
            if len(p2) >= 2 and 0.755 <= p2[-1][1] <= 0.785 and abs(p2[-1][0] - p2[-2][0]) < 0.03 and ch not in "vxyz":
                x = p2[-1][0]
                nuove.append(("piede a grazia", [(x - .045, .775), (x + .045, .775)]))
        out[ch] = nuove
    out["a"] = [(n, [(0.5 + (x - 0.5) * 1.08, y) for x, y in p]) for n, p in _TEX["a"]]
    out["a"] = [(n.replace(" spezzat", ""), p) for n, p in out["a"]]
    out.update({c: v for c, v in _CAP.items()})
    return out


def _deriva_fraktur():
    """Fraktur: struttura da Textura con forcella (biforcazione) sulle aste alte."""
    out = {}
    for ch, voci in _TEX.items():
        nuove = []
        for n, p in voci:
            nuove.append((n, [(0.5 + (x - 0.5) * 0.95, y) for x, y in p]))
            if n in ("asta alta", "asta ricurva a sinistra") and ch in "bdhkl":
                x0, y0 = nuove[-1][1][0] if n == "asta alta" else nuove[-1][1][1]
                nuove.append(("forcella in cima", [(x0 - .05, y0 - .04), (x0 + .02, y0 + .02)]))
        out[ch] = nuove
    return out


_ROT = _deriva_rotunda()
_UMA = _deriva_umanistica()
_FRA = _deriva_fraktur()
_ROT_NOTE = {
    "o": "Qui la «o» è davvero tonda: le due metà si uniscono senza spigoli, a differenza della Textura.",
    "n": "L'arco è una curva continua che nasce dall'asta, non due segmenti spezzati.",
    "a": "Occhiello e pancia sono rotondi e ben aperti; l'asta destra chiude con un piede appena accennato.",
}
_UMA_NOTE = {
    "i": "I piedi a grazia compaiono su quasi tutte le aste: è una differenza chiave rispetto alla carolina.",
    "a": "La «a» umanistica è a due piani, più chiusa della «ɑ» carolina.",
}
_FRA_NOTE = {
    "b": "La forcella in cima all'asta è il segno della Fraktur: un piccolo tratto che parte a sinistra prima di scendere.",
    "h": "Asta con forcella e arco spezzato con piede: confrontalo con la «h» della Textura.",
}

def _deriva_gotica_cursiva(shear, occhielli, disc=1.0):
    """Gotiche corsive (bastarda, bâtarde, cursiva): da Textura, con inclinazione, aste senza losanga,
    piede a uncino e, dove previsto, occhiello sulle aste alte."""
    out = {}
    for ch, voci in _TEX.items():
        nuove = []
        for n, p in voci:
            p = list(p)
            if n == "asta alta" and occhielli and ch in "bhkl":
                x = p[1][0]
                p = [(x - .04, .70), (x - .06, .40), (x - .04, .16), (x + .04, .10), (x + .06, .18), (x, .40), (x, .73), (x + .04, .77)]
                n = "asta con occhiello"
            elif n in ("asta", "asta destra", "seconda asta") and len(p) == 4:
                p = [p[1], p[2], (p[2][0] + .08, p[2][1] + .02)]          # senza testa a losanga, piede a uncino
            q = []
            for x, y in p:
                if y > .8:
                    y = .8 + (y - .8) * disc
                x = 0.5 + (x - 0.5) * 0.92 + (0.78 - y) * shear
                q.append((max(.04, min(.96, x)), y))
            nuove.append((n, q))
        out[ch] = nuove
    return out


_BAS = _deriva_gotica_cursiva(0.20, True)
_BATF = _deriva_gotica_cursiva(0.18, True, 1.12)
_GCUR = _deriva_gotica_cursiva(0.12, False)
_BAS_NOTE = {
    "l": "L'occhiello in cima all'asta è il segno della scrittura corsiva gotica: si sale a sinistra, si gira in alto e si scende.",
    "n": "Rispetto alla Textura i piedi sono a uncino e le aste non hanno la testa a losanga.",
}
ALFABETO_GOTICA_CURSIVA = list("abcdefghijklmnopqrstuvwxyz")

ALFABETO_ROTUNDA = list("abcdefghijklmnopqrstuvwxyz")
ALFABETO_UMANISTICA = list("abcdefghiklmnopqrstuvxyz") + list("ABCDEFGHIKLMNOPQRSTVXYZ")
ALFABETO_FRAKTUR = list("abcdefghijklmnopqrstuvwxyz")

ALFABETO_ONCIALE = list("ABCDEFGHIKLMNOPQRSTUVXYZ")
ALFABETO_TEXTURA = list("abcdefghijklmnopqrstuvwxyz")

def _deriva_semionciale():
    """Semionciale: base carolina con 'd' ad asta inclinata, 'g' a testa piatta, proporzioni più ampie."""
    out = {}
    for ch, voci in _CAR.items():
        out[ch] = [(n, [(0.5 + (x - 0.5) * 1.10, y) for x, y in p]) for n, p in voci]
    out["d"] = [("pancia", [(.58, .32), (.44, .30), (.34, .44), (.34, .62), (.44, .76), (.58, .72)]),
                ("asta inclinata", [(.58, .74), (.60, .45), (.56, .22), (.46, .12)])]
    out["g"] = [("testa e occhiello", [(.62, .30), (.40, .30), (.34, .42), (.40, .54), (.62, .52)]),
                ("coda aperta", [(.62, .30), (.62, .74), (.52, .90), (.38, .92)])]
    for ch, voci in _ONC.items():      # maiuscole: onciali
        out[ch] = voci
    return out


def _deriva_rustica():
    """Rustica: capitale stretta e compressa, quasi senza grazie."""
    out = {}
    for ch, voci in _CAP.items():
        nuove = []
        for n, p in voci:
            if n.startswith("grazia"):
                continue
            nuove.append((n, [(0.5 + (x - 0.5) * 0.74, y) for x, y in p]))
        out[ch] = nuove
    return out


_SEM = _deriva_semionciale()
_RUS = _deriva_rustica()
_SEM_NOTE = {
    "d": "La «d» ha l'asta inclinata che si piega a sinistra in cima: è la forma tipica della semionciale, diversa dalla «d» carolina dritta.",
    "g": "La «g» ha la testa piatta e la coda aperta sotto il rigo.",
    "a": "La «a» è aperta, a forma di «ɑ», come nell'onciale.",
}
_RUS_NOTE = {
    "O": "Le lettere tonde sono ellissi strette: la rustica è compressa per scrivere più in fretta e risparmiare spazio.",
    "E": "I bracci sono corti e i tratti orizzontali più sottili, quasi senza grazie.",
}
ALFABETO_SEMIONCIALE = list("abcdefghiklmnopqrstuvxyz") + ALFABETO_ONCIALE
ALFABETO_RUSTICA = list("ABCDEFGHIKLMNOPQRSTVXYZ")

_STILI = {
    "occidentale_onciale": {"modelli": _ONC, "note": _ONC_NOTE, "alfabeto": ALFABETO_ONCIALE,
        "intro": ("Onciale: maiuscola libraria rotonda. Penna a punta larga tenuta quasi piatta (≈ 25–30° sulla riga, valore didattico). "
                  "Le curve si fanno in due tratti (metà sinistra, metà destra) senza ruotare la penna; le aste scendono dall'alto. "
                  "Altezza del corpo ≈ 4–5 larghezze di penna. Verifica forme e angolo su un manoscritto preciso.")},
    "occidentale_carolina": {"modelli": {**_CAR, **_CAP}, "note": {**_CAROLINA_MAIUSCOLE_NOTA, **_CAR_NOTE}, "alfabeto": ALFABETO_CAROLINA,
        "intro": ("Carolina: minuscola chiara e regolare. Penna a punta larga a ≈ 30°; corpo ≈ 4 larghezze di penna, aste con clava a cuneo, lettere aperte e ben separate. "
                  "Le maiuscole qui sono capitali quadrate (come nei manoscritti carolingi). Verifica forme e proporzioni sul manoscritto scelto.")},
    "occidentale_capitale_romana": {"modelli": _CAP, "note": _CAP_NOTE, "alfabeto": ALFABETO_CAPITALE,
        "intro": ("Capitale romana (Capitalis Monumentalis): lettere maiuscole con contrasto tra aste spesse e tratti sottili, grazie alle estremità. "
                  "Penna a ≈ 25–30°; ordine abituale: prima le aste, poi le curve e i bracci, infine le grazie. Mancano J, U, W (non presenti nell'alfabeto latino classico). "
                  "Qui sono incluse le grazie principali: schema didattico, non il modello di una iscrizione precisa.")},
    "occidentale_semionciale": {"modelli": _SEM, "note": _SEM_NOTE, "alfabeto": ALFABETO_SEMIONCIALE,
        "intro": ("Semionciale (derivata dalla carolina e dall'onciale): penna a ≈ 30°, minuscola ampia con «d» ad asta inclinata, «g» a testa piatta e «a» aperta. "
                  "Le maiuscole sono onciali. Tracciati derivati: confrontali con un manoscritto di semionciale.")},
    "occidentale_rustica": {"modelli": _RUS, "note": _RUS_NOTE, "alfabeto": ALFABETO_RUSTICA,
        "intro": ("Capitale rustica (derivata dalla capitale romana): penna a ≈ 30°, lettere strette e compresse, quasi senza grazie, curve a ellisse stretta. "
                  "Tracciati derivati dalla capitale: confrontali con un manoscritto in rustica (per esempio il Virgilio Vaticano).")},
    "occidentale_bastarda": {"modelli": _BAS, "note": _BAS_NOTE, "alfabeto": ALFABETO_GOTICA_CURSIVA,
        "intro": ("Bastarda (derivata dalla Textura): penna a ≈ 35°, scrittura corsiva gotica con inclinazione di circa 11°, occhiello sulle aste alte e piedi a uncino. "
                  "Tracciati derivati, non rilevati da un manoscritto: confrontali con un esemplare. Solo minuscole.")},
    "occidentale_batarde_francaise": {"modelli": _BATF, "note": _BAS_NOTE, "alfabeto": ALFABETO_GOTICA_CURSIVA,
        "intro": ("Bâtarde française (derivata dalla Textura): come la bastarda con discendenti più lunghe e inclinazione ≈ 10°; penna a ≈ 35°. "
                  "Tracciati derivati: da confrontare con un manoscritto francese. Solo minuscole.")},
    "occidentale_gotica_cursiva": {"modelli": _GCUR, "note": _BAS_NOTE, "alfabeto": ALFABETO_GOTICA_CURSIVA,
        "intro": ("Gotica cursiva (derivata dalla Textura): inclinazione leggera (≈ 7°), aste semplici senza occhiello, piedi a uncino; penna a ≈ 35°. "
                  "Tracciati derivati: da confrontare con un esemplare. Solo minuscole.")},
    "occidentale_rotunda": {"modelli": _ROT, "note": _ROT_NOTE, "alfabeto": ALFABETO_ROTUNDA,
        "intro": ("Gotica Rotunda (derivata dalla Textura): penna a ≈ 35°, lettere più larghe e tonde. Le curve sono continue, non spezzate; i piedi sono piccoli. "
                  "Tracciati derivati dalla Textura con arrotondamento: confrontali con un manoscritto italiano di rotunda. Qui solo minuscole.")},
    "occidentale_umanistica": {"modelli": _UMA, "note": {**_CAROLINA_MAIUSCOLE_NOTA, **_UMA_NOTE}, "alfabeto": ALFABETO_UMANISTICA,
        "intro": ("Scrittura umanistica (derivata dalla carolina): penna a ≈ 30°, proporzioni più larghe e regolari, piedi a grazia sulle aste, «a» a due piani. "
                  "Tracciati derivati dalla carolina: verifica su una mano precisa, per esempio il manoscritto di riferimento indicato. Maiuscole: capitale quadrata.")},
    "occidentale_fraktur": {"modelli": _FRA, "note": _FRA_NOTE, "alfabeto": ALFABETO_FRAKTUR,
        "intro": ("Fraktur (derivata dalla Textura): penna a ≈ 40°, curve spezzate come nella Textura ma con la forcella in cima alle aste alte. "
                  "Le differenze più vistose con la Textura stanno nelle maiuscole, qui non incluse. Tracciati derivati: confrontali con un esemplare.")},
    "occidentale_textura": {"modelli": _TEX, "note": _TEX_NOTE, "alfabeto": ALFABETO_TEXTURA,
        "intro": ("Textura: penna a punta larga a ≈ 40–45°. Ogni lettera è fatta di aste verticali con testa e piede a losanga e di curve spezzate in segmenti diritti. "
                  "Aste ravvicinate: lo spazio tra due aste è uguale a quello interno alla «o» (effetto «trama»). Qui solo minuscole; le maiuscole lombardiche non sono ancora incluse.")},
    "occidentale_textura_quadrata": {"modelli": _TEX, "note": _TEX_NOTE, "alfabeto": ALFABETO_TEXTURA,
        "intro": ("Textura Quadrata: come la Textura ma con piedi nettamente quadrati e spezzature più rigide; penna a ≈ 45°, corpo ≈ 5 larghezze. "
                  "Qui solo minuscole; i tracciati sono gli stessi della Textura, il carattere quadrato nasce dal piede e dal taglio della penna.")},
}


def _chiave(nome):
    sid = id_da_nome(nome)
    return sid if sid in _STILI else None


def nib_angolo(nome):
    """Angolo della penna (gradi) o None se lo stile non usa punta larga.

    Per gli stili a punta larga il valore dell'archivio calligrafico dell'utente (dati_stili) ha la
    precedenza; la tabella interna NIB_ANGOLI resta come riserva se l'archivio manca o non lo indica.
    """
    sid = id_da_nome(nome) or nome
    if sid in NIB_ANGOLI:
        try:
            from gradi_stili import gradi_per_id
            g = gradi_per_id(sid)
            if g and g["angolo"] is not None:
                return g["angolo"]
        except ImportError:
            pass
    return NIB_ANGOLI.get(sid)


def alfabeto_stile(nome):
    k = _chiave(nome)
    return list(_STILI[k]["alfabeto"]) if k else None


def _chaikin(pts, giri=2):
    for _ in range(giri):
        nuovi = [pts[0]]
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            nuovi.append((0.75 * ax + 0.25 * bx, 0.75 * ay + 0.25 * by))
            nuovi.append((0.25 * ax + 0.75 * bx, 0.25 * ay + 0.75 * by))
        nuovi.append(pts[-1])
        pts = nuovi
    return pts


_NON_LISCIARE = {"Z", "V", "V centrale", "braccio e gamba", "braccio destro e coda", "braccio sinistro"}


def _da_lisciare(k, nome, pts):
    """Quali tratti ammorbidire: solo le curve, mai aste, diagonali, traverse e grazie."""
    if len(pts) < 4 or nome in _NON_LISCIARE:
        return False
    if k == "occidentale_onciale":
        return True
    if k == "occidentale_rotunda":
        return any(t in nome for t in ("arco", "pancia", "metà", "curva", "occhiello", "occhio", "spalla", "s breve", "coda"))
    if k == "occidentale_semionciale" and nome in ("asta inclinata",):
        return True
    if k in ("occidentale_carolina", "occidentale_capitale_romana", "occidentale_umanistica", "occidentale_semionciale", "occidentale_rustica"):
        if nome.startswith(("asta", "traversa", "grazia", "braccio", "gamba", "diagonale", "barra", "piede", "sperone", "coda", "forcella")) \
                and nome not in ("asta con gancio", "asta e coda aperta"):
            return False
        return nome not in ("Z", "V")
    return False


def modello_stile(nome, lettera):
    """Tratti (liste di punti) del ductus specifico dello stile, o None.

    Le curve sono ammorbidite (onciale, carolina, capitale); aste e diagonali restano dritte.
    Textura: nessun arrotondamento, la spezzatura fa parte dello stile.
    """
    k = _chiave(nome)
    if not k:
        return None
    voci = _STILI[k]["modelli"].get(lettera)
    if not voci:
        return None
    out = []
    for n, p in voci:
        p = list(p)
        if _da_lisciare(k, n, p):
            p = _chaikin(p, 2)
        out.append(p)
    return out


def introduzione_stile(nome):
    k = _chiave(nome)
    return _STILI[k]["intro"] if k else None


def _direzione(pts):
    (x0, y0), (x1, y1) = pts[0], pts[-1]
    v = "il basso" if y1 > y0 + .1 else ("l'alto" if y1 < y0 - .1 else "")
    o = "destra" if x1 > x0 + .1 else ("sinistra" if x1 < x0 - .1 else "")
    return " e verso ".join(x for x in (v, o) if x) or "il punto di partenza"


def passi_stile(nome, lettera):
    """Istruzioni tratto per tratto (con nome e direzione), più note e controllo finale."""
    k = _chiave(nome)
    if not k:
        return None
    voci = _STILI[k]["modelli"].get(lettera)
    if not voci:
        return None
    ang = NIB_ANGOLI.get(k)
    passi = []
    for i, (n, pts) in enumerate(voci, 1):
        passi.append(f"Tratto {i} · {n}: parti dal punto indicato e vai verso {_direzione(pts)}"
                     + (f", con la penna ferma a ≈ {ang}°." if ang else "."))
    nota = _STILI[k]["note"].get(lettera)
    if nota:
        passi.append("Nota · " + nota)
    passi.append("Controllo · Confronta forma, proporzioni e ordine dei tratti con un manoscritto dello stile: questo è uno schema didattico.")
    return passi


# ----------------------------------------------------------------------------
# Penna a punta larga simulata: poligoni da riempire (pure funzioni, senza Qt)
# ----------------------------------------------------------------------------
def poligoni_penna(punti, larghezza, angolo_gradi):
    """Per ogni segmento restituisce il quadrilatero spazzato dal taglio della penna.

    punti: [(x, y)] in pixel (y verso il basso); angolo: inclinazione del taglio
    rispetto alla riga, in gradi, antioraria come la vede chi scrive.
    Dove il movimento è parallelo al taglio il tratto è sottile, dove è
    perpendicolare è largo: è questo che dà ai tratti la loro forma.
    """
    a = math.radians(angolo_gradi)
    hx, hy = math.cos(a) * larghezza / 2.0, -math.sin(a) * larghezza / 2.0
    quads = []
    for (x0, y0), (x1, y1) in zip(punti, punti[1:]):
        quads.append(((x0 + hx, y0 + hy), (x1 + hx, y1 + hy), (x1 - hx, y1 - hy), (x0 - hx, y0 - hy)))
    return quads


def spessore_relativo(p0, p1, angolo_gradi):
    """0..1: quanto è largo il segno lasciato da un movimento p0->p1 con quel taglio."""
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    n = math.hypot(dx, dy)
    if n == 0:
        return 0.0
    a = math.radians(angolo_gradi)
    ex, ey = math.cos(a), -math.sin(a)
    return abs(dx * ey - dy * ex) / n
