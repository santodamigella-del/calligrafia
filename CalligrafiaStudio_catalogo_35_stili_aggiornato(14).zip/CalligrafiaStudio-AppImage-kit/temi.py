"""Temi grafici di Calligrafia Studio (senza dipendenze da Qt).

Il foglio di stile originale («Pergamena») è la base: ogni tema sostituisce i colori
con una tavolozza. Per leggibilità i temi scuri cambiano l'interfaccia ma il foglio resta
chiaro (come nei programmi di pittura): i tratti già disegnati con inchiostro scuro restano
visibili quando si cambia tema.

Le impostazioni (tema e gesto del mouse) si salvano in
~/.config/calligrafia-studio/impostazioni.json (o in $XDG_CONFIG_HOME).
"""
import json
import os
import re

STILE_BASE = r'''
            QMainWindow, QDialog { background: #f4e6c8; color: #24170f; }
            QWidget { color: #24170f; font-size: 14px; }
            QFrame#sidebar { background: #f4e6c8; border: 1px solid #b9945c; border-radius: 12px; }
            QLabel#appTitle { font-family: Georgia, serif; font-size: 25px; font-weight: bold; color: #70451f; }
            QLabel { color: #24170f; padding-top: 3px; font-size: 14px; }
            QLabel#hint { color: #59432f; font-size: 12px; }
            QLabel#sectionTitle { color: #573417; font-size: 12px; font-weight: bold; letter-spacing: 1px; }
            QLineEdit, QSpinBox, QComboBox {
                background: #fff8e9; color: #35251b; border: 1px solid #c6a36b;
                border-radius: 7px; padding: 9px; min-height: 22px;
                selection-background-color: #70451f;
            }
            QComboBox { font-weight: 600; min-height: 24px; }
            QComboBox::drop-down { background: #ead7b4; border-left: 1px solid #c6a36b; width: 26px; }
            QComboBox QAbstractItemView {
                background: #fffaf0; color: #24170f; border: 1px solid #9b7446;
                selection-background-color: #70451f; selection-color: #ffffff;
                outline: 0; padding: 5px;
            }
            QPushButton {
                background: #e8d2a7; color: #442e1c; border: 1px solid #b58a4d;
                border-radius: 8px; padding: 10px 10px; min-height: 20px;
                text-align: left; font-weight: 600;
            }
            QPushButton:hover { background: #f5e1b8; color: #24170f; border: 2px solid #8b5b2d; }
            QPushButton:pressed { background: #d9bd8b; }
            QPushButton#primaryButton { background: #70451f; color: #fff4dc; font-weight: bold; border: 1px solid #573417; }
            QPushButton#primaryButton:hover { background: #8b5b2d; }
            QDialog QLabel { color: #24170f; font-size: 14px; }
            QListWidget, QTextBrowser {
                background: #fffaf0; color: #24170f; border: 1px solid #b9945c;
                border-radius: 7px; padding: 8px; selection-background-color: #70451f;
                selection-color: #ffffff; font-size: 14px;
            }
            QListWidget::item { color: #24170f; padding: 7px 5px; }
            QListWidget::item:hover { background: #f1dfbd; color: #24170f; }
            QListWidget::item:selected { background: #70451f; color: #ffffff; }
            QTextBrowser a { color: #75451f; }
            QScrollArea { background: transparent; }
            QSlider::groove:horizontal { height: 5px; background: #d2b98e; border-radius: 2px; }
            QSlider::handle:horizontal { background: #80572d; width: 16px; margin: -6px 0; border-radius: 8px; }
            QCheckBox { color: #24170f; spacing: 9px; font-weight: 600; }
            QCheckBox::indicator { width: 18px; height: 18px; }
            
'''

# Nome semantico -> colore originale (tema «Pergamena»)
ORIGINALE = {
    "bg": "#f4e6c8", "text": "#24170f", "sidebar_border": "#b9945c", "accent": "#70451f", "text2": "#59432f",
    "accent_dark": "#573417", "field": "#fff8e9", "field_text": "#35251b", "border": "#c6a36b", "btn_alt": "#ead7b4",
    "field_light": "#fffaf0", "border_dark": "#9b7446", "sel_text": "#ffffff", "btn": "#e8d2a7", "btn_text": "#442e1c",
    "btn_border": "#b58a4d", "hover": "#f5e1b8", "accent_hover": "#8b5b2d", "pressed": "#d9bd8b",
    "primary_text": "#fff4dc", "list_hover": "#f1dfbd", "link": "#75451f", "groove": "#d2b98e", "handle": "#80572d",
}

TEMI = {
    "Pergamena": dict(ORIGINALE, carta="#f3e4c2"),
    "Carta bianca": dict(
        bg="#f2f4f7", text="#1b2430", sidebar_border="#aebacb", accent="#1f4e8c", text2="#4a5668", accent_dark="#17396b",
        field="#ffffff", field_text="#1b2430", border="#b8c2d0", btn_alt="#e3e8f0", field_light="#ffffff",
        border_dark="#8896ab", sel_text="#ffffff", btn="#e4e9f1", btn_text="#1f2a3a", btn_border="#a9b5c7",
        hover="#d6e2f3", accent_hover="#2d63ad", pressed="#c3d3ea", primary_text="#ffffff", list_hover="#e5edf8",
        link="#1f4e8c", groove="#c7d0dd", handle="#1f4e8c", carta="#fbfbf9"),
    "Notte": dict(
        bg="#1e1a16", text="#efe3cf", sidebar_border="#5a4a38", accent="#d9a35c", text2="#c3b49b", accent_dark="#e8bb7a",
        field="#2b251f", field_text="#f2e8d6", border="#5a4a38", btn_alt="#3a3027", field_light="#2b251f",
        border_dark="#7a6246", sel_text="#1e1a16", btn="#3a3027", btn_text="#efe3cf", btn_border="#6a5640",
        hover="#4a3d30", accent_hover="#e8bb7a", pressed="#2a221b", primary_text="#1e1a16", list_hover="#3d3328",
        link="#e8bb7a", groove="#5a4a38", handle="#d9a35c", carta="#f3e4c2"),
    "Bosco": dict(
        bg="#e3ead9", text="#1d2a1c", sidebar_border="#9fb08d", accent="#3e6b3a", text2="#445542", accent_dark="#2d5029",
        field="#f6f9f0", field_text="#1d2a1c", border="#aebd9a", btn_alt="#d5e0c6", field_light="#f9fbf4",
        border_dark="#7e946a", sel_text="#ffffff", btn="#d3dfc3", btn_text="#26391f", btn_border="#8fa57a",
        hover="#c4d5b0", accent_hover="#4f8248", pressed="#b5c9a0", primary_text="#f4faee", list_hover="#d9e5cb",
        link="#3e6b3a", groove="#b7c6a3", handle="#3e6b3a", carta="#f7f6ea"),
}
TEMA_PREDEFINITO = "Pergamena"


def foglio_stile(nome):
    """Foglio di stile Qt del tema scelto (colori sostituiti nell'originale)."""
    tema = TEMI.get(nome, TEMI[TEMA_PREDEFINITO])
    mappa = {ORIGINALE[k].lower(): tema[k] for k in ORIGINALE}
    return re.sub(r"#[0-9a-fA-F]{6}", lambda m: mappa.get(m.group(0).lower(), m.group(0)), STILE_BASE)


def _percorso():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "calligrafia-studio", "impostazioni.json")


def carica_impostazioni():
    try:
        with open(_percorso(), "r", encoding="utf-8") as f:
            dati = json.load(f)
        return dati if isinstance(dati, dict) else {}
    except (OSError, ValueError):
        return {}


def salva_impostazioni(dati):
    """Salva le impostazioni; restituisce False (senza errori) se il disco non è scrivibile."""
    try:
        p = _percorso()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(dati, f, ensure_ascii=False, indent=1)
        return True
    except OSError:
        return False
