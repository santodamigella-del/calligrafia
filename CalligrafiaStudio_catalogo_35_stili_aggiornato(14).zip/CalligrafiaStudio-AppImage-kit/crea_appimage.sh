#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME="CalligrafiaStudio"
APP_DIR="${APP_NAME}.AppDir"
VENV=".build-venv"

for cmd in python3 curl; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Errore: manca il comando '$cmd'." >&2; exit 1; }
done

if [[ ! -f main.py || ! -f biblioteca_stili.py ]]; then
  echo "Esegui questo script dalla cartella che contiene main.py e biblioteca_stili.py." >&2
  exit 1
fi

if [[ ! -d "$VENV" ]]; then
  python3 -m venv "$VENV"
fi
# Aggiorna gli strumenti di build e installa le dipendenze in un ambiente separato.
"$VENV/bin/python" -m pip install --upgrade pip wheel
"$VENV/bin/python" -m pip install --upgrade PySide6 PyInstaller

rm -rf build dist "$APP_DIR"
"$VENV/bin/pyinstaller" \
  --noconfirm --clean --onedir --windowed \
  --name "$APP_NAME" \
  --hidden-import biblioteca_stili \
  --hidden-import riconoscimento_stile \
  --hidden-import stili_modelli \
  --hidden-import ductus_stili \
  --hidden-import corsivo_legature \
  --hidden-import gesti_mouse \
  --hidden-import temi \
  --hidden-import tracciati_oriente \
  --hidden-import foglio_esercizi \
  --hidden-import gradi_stili \
  --hidden-import coerenza_scrittura \
  --add-data "calligrafia-studio.png:." \
  --add-data "dati_stili:dati_stili" \
  --collect-all PySide6 \
  main.py

# Icona: la foto del foglio con la dedica e la stilografica (regalo), in più misure.
mkdir -p "$APP_DIR/usr/bin"
cp -a "dist/$APP_NAME" "$APP_DIR/usr/bin/"
for SZ in 32 48 64 128 256; do
  mkdir -p "$APP_DIR/usr/share/icons/hicolor/${SZ}x${SZ}/apps"
  cp "icone/calligrafia-studio-${SZ}.png" "$APP_DIR/usr/share/icons/hicolor/${SZ}x${SZ}/apps/calligrafia-studio.png"
done
mkdir -p "$APP_DIR/usr/share/icons/hicolor/512x512/apps"
cp calligrafia-studio.png "$APP_DIR/usr/share/icons/hicolor/512x512/apps/calligrafia-studio.png"
cp calligrafia-studio.png "$APP_DIR/calligrafia-studio.png"
cp calligrafia-studio.png "$APP_DIR/.DirIcon"

cat > "$APP_DIR/AppRun" <<'APPRUN'
#!/usr/bin/env bash
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec "$HERE/usr/bin/CalligrafiaStudio/CalligrafiaStudio" "$@"
APPRUN
chmod +x "$APP_DIR/AppRun"

cat > "$APP_DIR/CalligrafiaStudio.desktop" <<'DESKTOP'
[Desktop Entry]
Type=Application
Name=Calligrafia Studio
Comment=Laboratorio e biblioteca storica della calligrafia
Exec=AppRun
Icon=calligrafia-studio
Categories=Graphics;Education;
Terminal=false
DESKTOP

# appimagetool richiede FUSE su alcuni sistemi; APPIMAGE_EXTRACT_AND_RUN permette
# di eseguire lo strumento anche su molti sistemi senza FUSE configurato.
TOOL="$PWD/appimagetool-x86_64.AppImage"
if [[ ! -x "$TOOL" ]]; then
  echo "Scarico appimagetool per Linux x86_64..."
  curl -fL --retry 3 \
    https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-x86_64.AppImage \
    -o "$TOOL"
  chmod +x "$TOOL"
fi

ARCH=x86_64 APPIMAGE_EXTRACT_AND_RUN=1 "$TOOL" "$APP_DIR" "$APP_NAME-x86_64.AppImage"
echo
echo "Creato: $PWD/$APP_NAME-x86_64.AppImage"
echo "Prova ad avviarlo con: ./$APP_NAME-x86_64.AppImage"
