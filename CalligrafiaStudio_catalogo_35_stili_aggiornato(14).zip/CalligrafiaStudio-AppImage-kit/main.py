
import sys
import os
import json
import html
import math
import time
from pathlib import Path

from PySide6.QtCore import Qt, QPointF, QEvent, QTimer
from PySide6.QtGui import (QPolygonF, 
    QPainter, QPen, QColor, QPainterPath, QImage,
    QAction, QFont, QFontDatabase
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QPushButton, QLabel, QComboBox,
    QSlider, QColorDialog, QFileDialog, QMessageBox,
    QCheckBox, QFrame, QScrollArea, QDialog, QLineEdit,
    QFontComboBox, QSpinBox, QDoubleSpinBox, QDialogButtonBox, QFormLayout, QListWidget, QTextBrowser
)
from PySide6.QtGui import QDesktopServices, QIcon, QPdfWriter, QPageSize
from PySide6.QtCore import QUrl

try:
    from lezioni_tratti_oriente import lezione_tratti
except ImportError:
    lezione_tratti = lambda carattere: None

try:
    from atlante_modelli_storici import (scheda_lettera_carolina, scheda_maiuscola_carolina, scheda_lettera_storica, scheda_maiuscola_storica, scheda_lettera_bastarda, scheda_maiuscola_cancelleresca, scheda_lettera_araba)
except ImportError:
    scheda_lettera_carolina = lambda lettera: None
    scheda_maiuscola_carolina = lambda lettera: None
    scheda_lettera_storica = lambda stile, lettera: None
    scheda_maiuscola_storica = lambda stile, lettera: None
    scheda_lettera_bastarda = lambda lettera: None
    scheda_maiuscola_cancelleresca = lambda lettera: None
    scheda_lettera_araba = lambda stile, lettera: None

try:
    from biblioteca_stili import BIBLIOTECA_STILI, cerca_stili, tradizioni_disponibili, guida_tecnica, passi_esercizio
except ImportError:
    BIBLIOTECA_STILI = []
    cerca_stili = lambda testo="", tradizione=None: []
    tradizioni_disponibili = lambda: []


try:
    from riconoscimento_stile import riconosci_stile, formatta_risultato_html, id_da_nome
except ImportError:
    riconosci_stile = None
    formatta_risultato_html = None
    id_da_nome = lambda nome: None

try:
    from stili_modelli import (trasforma_tratto, tutti_i_modelli, descrivi_tratti,
                               GRECO_MAIUSCOLE, GRECO_MINUSCOLE, ARABO_LETTERE, HIRAGANA)
except ImportError:
    trasforma_tratto = None
    tutti_i_modelli = None
    descrivi_tratti = None
    GRECO_MAIUSCOLE = GRECO_MINUSCOLE = []
    ARABO_LETTERE = list("ابتثجحخدذرزسشصضطظعغفقكلمنهوي")
    HIRAGANA = list("あいうえお")

try:
    from ductus_stili import (modello_stile, passi_stile, alfabeto_stile, introduzione_stile,
                              nib_angolo, poligoni_penna)
except ImportError:
    modello_stile = passi_stile = alfabeto_stile = introduzione_stile = nib_angolo = poligoni_penna = None

try:
    from corsivo_legature import (costruisci_testo, parola_valida, segmenti_pressione,
                                  lunghezza as lunghezza_tratti, STILI_CORSIVI, svg_testo)
except ImportError:
    costruisci_testo = None
    STILI_CORSIVI = {}
    svg_testo = None

try:
    from gesti_mouse import GestoMouse, PRESET as PRESET_GESTO, PRESET_PREDEFINITO as GESTO_PREDEFINITO, linea_retta
except ImportError:
    GestoMouse = None
    PRESET_GESTO = {}
    GESTO_PREDEFINITO = ""

try:
    from temi import TEMI, TEMA_PREDEFINITO, foglio_stile, carica_impostazioni, salva_impostazioni
except ImportError:
    TEMI = {}
    TEMA_PREDEFINITO = ""
    foglio_stile = None
    carica_impostazioni = None
    salva_impostazioni = None

try:
    from coerenza_scrittura import analizza_regolarita, formatta_regolarita_html
except ImportError:
    analizza_regolarita = None
    formatta_regolarita_html = None

try:
    from tracciati_oriente import (modello_oriente, passi_oriente, HIRAGANA_LISTA, KATAKANA_LISTA, KANJI_LISTA)
except ImportError:
    modello_oriente = None
    passi_oriente = None
    HIRAGANA_LISTA = list("あいうえお")
    KATAKANA_LISTA = []
    KANJI_LISTA = list("永山川")

try:
    from foglio_esercizi import costruisci_fogli
except ImportError:
    costruisci_fogli = None

try:
    from gradi_stili import gradi_per_nome, descrizione as descrizione_gradi
except ImportError:
    gradi_per_nome = None
    descrizione_gradi = None

ARAB_TOKENS = ("naskh", "kufic", "cufico", "thuluth", "maghribi", "hijazi", "nasta")

def disegna_primitive(painter, primitive):
    """Esegue le primitive prodotte da foglio_esercizi.costruisci_fogli (linee, polilinee, poligoni, testi)."""
    for p in primitive:
        tipo = p[0]
        if tipo == "linea":
            _t, x0, y0, x1, y1, colore, spessore, tratteggiata = p
            painter.setPen(QPen(QColor(colore), spessore, Qt.PenStyle.DashLine if tratteggiata else Qt.PenStyle.SolidLine))
            painter.drawLine(QPointF(x0, y0), QPointF(x1, y1))
        elif tipo == "poli":
            _t, punti, colore, spessore = p
            painter.setPen(QPen(QColor(colore), spessore, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPolyline(QPolygonF([QPointF(x, y) for x, y in punti]))
        elif tipo == "riempi":
            _t, punti, colore = p
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(colore))
            painter.drawPolygon(QPolygonF([QPointF(x, y) for x, y in punti]))
            painter.setBrush(Qt.BrushStyle.NoBrush)
        elif tipo == "testo":
            _t, x, y, testo, altezza, colore = p
            font = QFont("Georgia")
            font.setPixelSize(int(altezza))
            painter.setFont(font)
            painter.setPen(QColor(colore))
            painter.drawText(QPointF(x, y), testo)


def percorso_risorsa(nome):
    """Percorso di un file incluso nell'app (anche dentro l'AppImage/PyInstaller)."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, nome)


def icona_applicazione():
    """Icona dell'app: la foto della dedica con la stilografica; icona vuota se il file manca."""
    percorso = percorso_risorsa("calligrafia-studio.png")
    return QIcon(percorso) if os.path.exists(percorso) else QIcon()


STYLES = {
    "Cancelleresca / Italica": "Scrittura rinascimentale elegante, inclinata e fluida.",
    "Gotica Textura": "Stile medievale angolare, compatto e solenne.",
    "Gotica Rotunda": "Scrittura gotica arrotondata, adatta ai manoscritti.",
    "Fraktur": "Stile nero tedesco, ricco di contrasti e ornamenti.",
    "Onciale": "Lettere tondeggianti della tradizione manoscritta antica.",
    "Semionciale": "Scrittura storica morbida e ricca di personalità.",
    "Minuscola carolina": "Scrittura medievale leggibile e armoniosa.",
    "Umanistica": "Lettere classiche ispirate alla cultura rinascimentale.",
    "Copperplate / Roundhand": "Tratti fini e spessi, con eleganti svolazzi.",
    "Spencerian": "Stile corsivo americano, leggero e ornamentale.",
    "Brush lettering": "Lettering espressivo ispirato al pennello.",
    "Cinese": "Percorsi ispirati alla calligrafia tradizionale cinese.",
    "Naskh": "Scrittura araba corsiva: forme contestuali, legature e punti diacritici.",
    "Cufico (Kufic)": "Famiglia araba con varianti angolari; distinguere manoscritto e geometria monumentale.",
    "Thuluth": "Calligrafia araba monumentale: proporzioni, rombo-punto e composizione.",
    "Capitale Romana (Capitalis Monumentalis)": "Maiuscola epigrafica romana: proporzioni, ritmo e spaziatura.",
    "Rustica Romana (Capitalis Rustica)": "Scrittura libraria romana slanciata, eseguita con punta larga.",
    "Kurrent": "Corsiva storica tedesca: legature e forme angolose.",
    "Sütterlin": "Modello scolastico tedesco introdotto nel 1915, distinto dalla Kurrent.",
    "Bâtarde Française": "Famiglia di corsive gotiche francesi, variabile secondo mano e periodo.",
    "Textura Quadrata": "Variante gotica libraria con moduli compatti e terminali quadrangolari.",
    "Gotica Cursiva": "Famiglia di mani gotiche corsive con legature e varianti regionali.",
}

# Famiglie calligrafiche preferite. Verrà scelta solo una famiglia
# effettivamente installata; in assenza si usa un serif corsivo di riserva.
STYLE_FONT_CANDIDATES = {
    "Cancelleresca / Italica": ["Italianno", "Tangerine", "Allura", "EB Garamond"],
    "Gotica Textura": ["UnifrakturMaguntia", "Pirata One"],
    "Gotica Rotunda": ["Pirata One", "UnifrakturMaguntia"],
    "Fraktur": ["UnifrakturMaguntia", "Pirata One"],
    "Onciale": ["Almendra", "EB Garamond", "DejaVu Serif"],
    "Semionciale": ["Almendra", "EB Garamond", "DejaVu Serif"],
    "Minuscola carolina": ["EB Garamond", "Almendra", "DejaVu Serif"],
    "Umanistica": ["EB Garamond", "Almendra", "DejaVu Serif"],
    "Copperplate / Roundhand": ["Pinyon Script", "Great Vibes", "Allura"],
    "Spencerian": ["Tangerine", "Italianno", "Great Vibes", "Allura"],
    "Brush lettering": ["Kaushan Script", "Pacifico", "Great Vibes"],
    "Cinese": ["Noto Serif CJK SC", "Noto Sans CJK SC", "WenQuanYi Zen Hei"],
    "Capitale Romana (Capitalis Monumentalis)": ["Cinzel", "Trajan Pro", "DejaVu Serif"],
    "Rustica Romana (Capitalis Rustica)": ["Forum", "Cinzel", "DejaVu Serif"],
    "Kurrent": ["DejaVu Sans", "DejaVu Serif"],
    "Sütterlin": ["DejaVu Sans", "DejaVu Serif"],
    "Bâtarde Française": ["Pirata One", "UnifrakturMaguntia"],
    "Textura Quadrata": ["UnifrakturMaguntia", "Pirata One"],
    "Gotica Cursiva": ["Pirata One", "UnifrakturMaguntia"],
}

PARCHMENT = QColor("#f3e4c2")
INK_DEFAULT = QColor("#292018")


class CalligraphyCanvas(QWidget):
    def __init__(self):
        super().__init__()

        self.setMinimumSize(700, 500)
        self.setAttribute(Qt.WidgetAttribute.WA_TabletTracking, True)
        self.setMouseTracking(True)

        self.ink = QColor(INK_DEFAULT)
        self.base_width = 5
        self.nib_width_mm = 2.0
        self.nib_angle_degrees = 30.0  # orientamento del taglio rispetto all’orizzontale
        self.nib_pressure_scale = 1.0
        self.cancelleresca_guides = False
        self.progetto_con_gradi = True
        self.guide_nibs = 5.0          # larghezze di pennino per corpo, ascendenti e discendenti (dallo stile)
        self.slant_degrees = 10.0  # inclinazione delle aste rispetto alla verticale
        self.ink_opacity = 100
        self.show_guides = True

        # Ogni tratto contiene punti, larghezza e colore.
        self.strokes = []
        self.text_items = []
        self.pending_text = None
        self.typing_mode = False
        self.typing_text = ""
        self.typing_x = 90.0
        self.typing_y = 100.0
        self.typing_font = "DejaVu Serif"
        self.typing_size = 36
        self.current_stroke = None
        self.last_point = None
        self.last_pressure = 1.0
        self.gesto = GestoMouse() if GestoMouse is not None else None
        self.paper = QColor(PARCHMENT)
        self._insert_y = None
        self._gruppo_n = 0
        self._gesture_on = False
        self.pointer_position = QPointF(110.0, 150.0)
        self.show_nib_cursor = True
        self.show_letter_ghost = False
        self.ghost_letter = "a"
        self.ductus_animation_active = False
        self.ductus_animation_progress = 0.0
        self.ductus_animation_speed = 1.0
        self.ductus_animation_loop = False
        self.ductus_animation_timer = QTimer(self)
        self.ductus_animation_timer.setInterval(30)
        self.ductus_animation_timer.timeout.connect(self._advance_ductus_animation)

        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def _pressure(self, event):
        try:
            pressure = float(event.pressure())
            if pressure > 0:
                return max(0.15, min(1.0, pressure))
        except (AttributeError, TypeError, ValueError):
            pass
        return 1.0

    def _start_stroke(self, point, pressure=1.0):
        stroke_color = QColor(self.ink)
        stroke_color.setAlpha(
            round(255 * max(0, min(100, self.ink_opacity)) / 100)
        )

        self.current_stroke = {
            "points": [(point.x(), point.y(), pressure)],
            "color": stroke_color.name(QColor.NameFormat.HexArgb),
            "width": float(self.base_width),
            "nib_width_mm": float(self.nib_width_mm),
            "nib_angle": float(self.nib_angle_degrees),
            "pressure_scale": float(self.nib_pressure_scale),
        }
        self.strokes.append(self.current_stroke)
        self.last_point = point
        self.last_pressure = pressure
        self.update()

    def _continue_stroke(self, point, pressure=1.0):
        if self.current_stroke is None:
            self._start_stroke(point, pressure)
            return

        self.current_stroke["points"].append(
            (point.x(), point.y(), pressure)
        )
        self.last_point = point
        self.last_pressure = pressure
        self.update()

    def _finish_stroke(self):
        self.current_stroke = None
        self.last_point = None
        self.update()

    @staticmethod
    def _event_time(event):
        try:
            return float(event.timestamp())
        except Exception:
            return None

    def _gesture_press(self, pos, event, pressure):
        """Inizio tratto con stabilizzatore e pressione simulata (stile Krita). Shift = linea retta, Shift+Ctrl = scatto di 15°."""
        g = self.gesto
        if g is None or not g.attivo:
            self._gesture_on = False
            self._start_stroke(pos, 1.0 if pressure is None else pressure)
            return
        try:
            mods = event.modifiers()
        except Exception:
            mods = Qt.KeyboardModifier.NoModifier
        if (mods & Qt.KeyboardModifier.ShiftModifier) and self.strokes and self.strokes[-1].get("points"):
            ux, uy, up = self.strokes[-1]["points"][-1]
            snap = 15 if (mods & Qt.KeyboardModifier.ControlModifier) else None
            punti = linea_retta((ux, uy), (pos.x(), pos.y()), pressione=up, scatto_gradi=snap)
            self._start_stroke(QPointF(punti[0][0], punti[0][1]), punti[0][2])
            for x, y, p in punti[1:]:
                self._continue_stroke(QPointF(x, y), p)
            self._gesture_on = False
            self._finish_stroke()
            return
        x, y, p = g.inizia(pos.x(), pos.y(), self._event_time(event), pressure)
        self._gesture_on = True
        self._start_stroke(QPointF(x, y), p)

    def _gesture_move(self, pos, event, pressure):
        g = self.gesto
        if g is None or not self._gesture_on:
            self._continue_stroke(pos, 1.0 if pressure is None else pressure)
            return
        for x, y, p in g.muovi(pos.x(), pos.y(), self._event_time(event), pressure):
            self._continue_stroke(QPointF(x, y), p)

    def _gesture_release(self):
        g = self.gesto
        if g is not None and self._gesture_on and self.current_stroke is not None:
            self.current_stroke["points"] = g.termina(self.current_stroke["points"])
        self._gesture_on = False
        self._finish_stroke()

    def mousePressEvent(self, event):
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        if event.button() == Qt.MouseButton.LeftButton:
            if self.typing_mode:
                self.typing_x = float(event.position().x())
                self.typing_y = float(event.position().y())
                self.setFocus(Qt.FocusReason.MouseFocusReason)
                self.update()
                event.accept()
                return
            if self.pending_text is not None:
                item = dict(self.pending_text)
                item["x"] = float(event.position().x())
                item["y"] = float(event.position().y())
                self.text_items.append(item)
                self.pending_text = None
                self.setCursor(Qt.CursorShape.ArrowCursor)
                self.update()
                event.accept()
                return
            self._gesture_press(event.position(), event, None)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        self.pointer_position = QPointF(event.position())
        if (
            self.current_stroke is not None
            and event.buttons() & Qt.MouseButton.LeftButton
        ):
            self._gesture_move(event.position(), event, None)
            event.accept()
            return
        self.update()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._gesture_release()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def tabletEvent(self, event):
        event_type = event.type()
        point = event.position()
        pressure = self._pressure(event)

        if event_type == QEvent.Type.TabletPress:
            self._gesture_press(point, event, pressure)
        elif event_type == QEvent.Type.TabletMove:
            self._gesture_move(point, event, pressure)
        elif event_type == QEvent.Type.TabletRelease:
            self._gesture_release()

        event.accept()

    def paintEvent(self, event):
        # Il painter viene creato e chiuso esclusivamente qui.
        painter = QPainter(self)

        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.fillRect(self.rect(), self.paper)

            if self.show_guides:
                self._draw_guides(painter)

            for stroke in self.strokes:
                self._draw_stroke(painter, stroke)
            self._draw_text_items(painter)
            self._draw_letter_ghost(painter)
            self._draw_ductus_animation(painter)
            self._draw_nib_cursor(painter)
            if self.typing_mode and self.typing_text:
                font = QFont(self.typing_font)
                font.setPointSize(self.typing_size)
                font.setItalic(True)
                painter.setFont(font)
                painter.setPen(QColor(self.ink))
                painter.drawText(QPointF(self.typing_x, self.typing_y), self.typing_text + "▏")

        finally:
            painter.end()

    def start_ductus_animation(self):
        """Riproduce sul foglio il ductus vettoriale della lettera selezionata."""
        if not DuctusCanvas.MODELS.get(self.ghost_letter):
            return
        self.ductus_animation_progress = 0.0
        self.ductus_animation_active = True
        self.ductus_animation_timer.start()
        self.update()

    def restart_ductus_animation(self):
        """Riporta l'animazione all'inizio senza cambiare lettera o velocità."""
        self.stop_ductus_animation()
        self.ductus_animation_progress = 0.0
        self.update()

    def set_ductus_speed(self, value):
        self.ductus_animation_speed = max(0.25, min(3.0, float(value) / 10.0))

    def set_ductus_loop(self, enabled):
        self.ductus_animation_loop = bool(enabled)

    def stop_ductus_animation(self):
        self.ductus_animation_timer.stop()
        self.ductus_animation_active = False
        self.update()

    def _advance_ductus_animation(self):
        self.ductus_animation_progress += 0.012 * self.ductus_animation_speed
        if self.ductus_animation_progress >= 1.0:
            self.ductus_animation_progress = 1.0
            self.update()
            if self.ductus_animation_loop:
                self.ductus_animation_progress = 0.0
            else:
                self.ductus_animation_timer.stop()
                self.ductus_animation_active = False
        self.update()

    def _draw_ductus_animation(self, painter):
        if self.ductus_animation_progress <= 0.0:
            return
        strokes = DuctusCanvas.MODELS.get(self.ghost_letter, [])
        if not strokes:
            return
        painter.save()
        unit = max(12.0, self.nib_width_mm * 3.78 * 5.0)
        width = unit * (0.95 if self.ghost_letter.isupper() else 0.72)
        height = unit * (1.35 if self.ghost_letter.isupper() else 1.0)
        left, baseline = 115.0, 300.0
        top = baseline - height
        # La progressione totale viene distribuita uniformemente tra i tratti.
        total = len(strokes)
        scaled = self.ductus_animation_progress * total
        for index, stroke in enumerate(strokes):
            if index >= scaled:
                break
            local = min(1.0, max(0.0, scaled - index))
            points = [QPointF(left + x * width, top + y * height) for x, y in stroke]
            if len(points) < 2:
                continue
            lengths = [math.hypot(b.x()-a.x(), b.y()-a.y()) for a,b in zip(points, points[1:])]
            total_len = sum(lengths)
            target = total_len * local
            travelled = 0.0
            path = QPainterPath(); path.moveTo(points[0])
            tip = points[0]
            for (a,b), distance in zip(zip(points, points[1:]), lengths):
                if travelled + distance <= target:
                    path.lineTo(b); tip = b; travelled += distance
                else:
                    part = 0.0 if distance == 0 else (target-travelled)/distance
                    if part > 0:
                        tip = QPointF(a.x()+(b.x()-a.x())*part, a.y()+(b.y()-a.y())*part)
                        path.lineTo(tip)
                    break
            color = QColor('#a34f19')
            painter.setPen(QPen(color, max(2.0, self.nib_width_mm*1.15), Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            painter.drawPath(path)
            if index == int(scaled) and self.ductus_animation_active:
                painter.setBrush(QColor('#e6a23c')); painter.setPen(QPen(QColor('#6d3516'), 1.5))
                painter.drawEllipse(tip, 5.5, 5.5)
        painter.restore()

    def _draw_letter_ghost(self, painter):
        """Mostra sul foglio il modello vettoriale usato nel Laboratorio del Ductus."""
        if not self.show_letter_ghost or not self.ghost_letter:
            return
        painter.save()
        letter = self.ghost_letter
        # Riutilizza gli stessi tracciati del laboratorio: il modello sul foglio
        # non è più un glifo tipografico indipendente.
        if letter.isupper():
            strokes = DuctusCanvas.CAPITAL_MODELS.get(letter, [])
        else:
            strokes = DuctusCanvas.MODELS.get(letter, [])
        if not strokes:
            painter.restore()
            return
        # Area di riferimento: dimensione adattata alla punta e alla lettera.
        unit = max(12.0, self.nib_width_mm * 3.78 * 5.0)
        width = unit * (0.95 if letter.isupper() else 0.72)
        height = unit * (1.35 if letter.isupper() else 1.0)
        left = 115.0
        baseline = 300.0
        top = baseline - height
        color = QColor('#80664d')
        color.setAlpha(92)
        painter.setPen(QPen(color, max(1.4, self.nib_width_mm * 0.55), Qt.PenStyle.DashLine,
                            Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        for stroke in strokes:
            if not stroke:
                continue
            path = QPainterPath()
            x0, y0 = stroke[0]
            path.moveTo(left + x0 * width, top + y0 * height)
            for x, y in stroke[1:]:
                path.lineTo(left + x * width, top + y * height)
            painter.drawPath(path)
        guide_pen = QPen(QColor(128, 102, 77, 90), 1.0, Qt.PenStyle.DotLine)
        painter.setPen(guide_pen)
        painter.drawLine(int(left - 12), int(baseline), int(left + width + 12), int(baseline))
        painter.restore()

    def _draw_nib_cursor(self, painter):
        """Mostra sul foglio l'impronta orientata della punta virtuale."""
        if not self.show_nib_cursor or self.current_stroke is not None:
            return
        painter.save()
        painter.translate(self.pointer_position)
        painter.rotate(-self.nib_angle_degrees)
        width = max(5.0, self.nib_width_mm * 3.78)
        height = max(3.0, width * 0.34)
        painter.setPen(QPen(QColor("#70451f"), 1.2))
        fill = QColor("#b78a4d")
        fill.setAlpha(105)
        painter.setBrush(fill)
        painter.drawRoundedRect(-width / 2, -height / 2, width, height, 1.5, 1.5)
        painter.setPen(QPen(QColor("#70451f"), 1, Qt.PenStyle.DotLine))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QPointF(0, 0), width * 0.8, width * 0.8)
        painter.restore()

    def start_typing(self, font_family, size):
        self.typing_mode = True
        self.typing_text = ""
        self.typing_font = font_family or "DejaVu Serif"
        self.typing_size = int(size)
        self.pending_text = None
        self.setCursor(Qt.CursorShape.IBeamCursor)
        self.setFocus(Qt.FocusReason.OtherFocusReason)
        self.update()

    def stop_typing(self, commit=True):
        if self.typing_mode and commit and self.typing_text:
            self.text_items.append({
                "text": self.typing_text,
                "font": self.typing_font,
                "size": self.typing_size,
                "color": self.ink.name(QColor.NameFormat.HexArgb),
                "italic": True,
                "x": self.typing_x,
                "y": self.typing_y,
            })
        self.typing_mode = False
        self.typing_text = ""
        self.setCursor(Qt.CursorShape.ArrowCursor)
        self.update()

    def keyPressEvent(self, event):
        if not self.typing_mode:
            super().keyPressEvent(event)
            return
        key = event.key()
        if key == Qt.Key.Key_Escape:
            self.stop_typing(commit=False)
        elif key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.stop_typing(commit=True)
        elif key == Qt.Key.Key_Backspace:
            self.typing_text = self.typing_text[:-1]
            self.update()
        elif key == Qt.Key.Key_Space:
            self.typing_text += " "
            self.update()
        else:
            text = event.text()
            if text and text.isprintable() and not (event.modifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier | Qt.KeyboardModifier.MetaModifier)):
                self.typing_text += text
                self.update()
            else:
                super().keyPressEvent(event)

    def _draw_guides(self, painter):
        guide_pen = QPen(QColor("#cdbd9d"), 1)
        painter.setPen(guide_pen)

        if self.cancelleresca_guides:
            # Modulo didattico: corpo, ascendenti e discendenti = N larghezze di pennino ciascuno,
            # con N preso dallo stile scelto (default 5). 96 dpi approssimati: 1 mm = 3.78 pixel.
            unit = self.nib_width_mm * 3.78
            n = max(1.0, float(self.guide_nibs))
            body = n * unit
            asc = n * unit
            desc = n * unit
            group = body + asc + desc
            baseline = 45 + asc + body
            y = baseline - asc - body
            guide_colors = ["#b89b70", "#c9aa78", "#9d684f", "#c9aa78", "#b89b70", "#c9aa78"]
            for index, offset in enumerate((0, asc, asc + body, asc + body + desc)):
                pen = QPen(QColor(guide_colors[min(index, len(guide_colors)-1)]), 1.4)
                if index in (1, 2):
                    pen.setStyle(Qt.PenStyle.DashLine)
                painter.setPen(pen)
                painter.drawLine(0, baseline - offset, self.width(), baseline - offset)
            painter.setPen(QPen(QColor("#d5a09a"), 1))
            painter.drawLine(65, 0, 65, self.height())
            # Reticolo leggero dell'inclinazione: l'angolo è misurato dalla verticale.
            import math
            slant = math.tan(math.radians(self.slant_degrees))
            guide_height = asc + body
            painter.setPen(QPen(QColor("#d8c9ad"), 1, Qt.PenStyle.DotLine))
            x = 110
            while x < self.width():
                painter.drawLine(QPointF(x, baseline), QPointF(x + slant * guide_height, baseline - guide_height))
                x += max(guide_height * 0.55, 28)
            # Ripetizione del rigo in base all'altezza totale del modulo.
            painter.setPen(QPen(QColor("#dfd0b3"), 1))
            next_base = baseline + group
            while next_base < self.height():
                for offset in (0, asc, asc + body, asc + body + desc):
                    painter.drawLine(0, int(next_base - offset), self.width(), int(next_base - offset))
                next_base += group
        else:
            spacing = 36
            y = spacing
            while y < self.height():
                painter.drawLine(0, y, self.width(), y)
                y += spacing
            margin_pen = QPen(QColor("#d5a09a"), 1)
            painter.setPen(margin_pen)
            painter.drawLine(65, 0, 65, self.height())

    def _draw_stroke(self, painter, stroke):
        points = stroke.get("points", [])
        if not points:
            return
        color = QColor(stroke.get("color", "#292018"))
        base_width = float(stroke.get("width", 5))
        nib_angle = math.radians(float(stroke.get("nib_angle", self.nib_angle_degrees)))
        pressure_scale = float(stroke.get("pressure_scale", 1.0))
        nib_mm = float(stroke.get("nib_width_mm", self.nib_width_mm))
        widths = stroke.get("widths")        # larghezze esplicite per segmento (parole in corsivo inserite)
        if len(points) == 1:
            x, y, pressure = points[0]
            painter.setPen(QPen(color, max(1.0, base_width * pressure * pressure_scale), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            painter.drawPoint(QPointF(x, y))
            return
        # Simulazione del pennino tronco: ogni segmento riceve lo spessore
        # in base all'orientamento del gesto rispetto al taglio della punta.
        for index in range(1, len(points)):
            x1, y1, p1 = points[index - 1]
            x2, y2, p2 = points[index]
            dx, dy = x2 - x1, y2 - y1
            if abs(dx) + abs(dy) < 0.01:
                continue
            direction = math.atan2(dy, dx)
            projection = abs(math.sin(direction - nib_angle))
            nib_factor = 0.10 + 0.90 * projection
            pressure = (float(p1) + float(p2)) / 2.0
            width = max(0.8, base_width * nib_factor * pressure * pressure_scale)
            if widths is not None and index - 1 < len(widths):
                width = max(0.8, float(widths[index - 1]))
            pen = QPen(color, width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
            painter.setPen(pen)
            painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))


    def _draw_text_items(self, painter):
        for item in self.text_items:
            font = QFont(item.get("font", "DejaVu Serif"))
            font.setPointSize(int(item.get("size", 32)))
            if item.get("italic", False):
                font.setItalic(True)
            painter.setFont(font)
            painter.setPen(QColor(item.get("color", "#292018")))
            painter.drawText(
                QPointF(float(item.get("x", 100)), float(item.get("y", 100))),
                item.get("text", "")
            )

    def arm_text_placement(self, text, font_family, size, color):
        self.pending_text = {
            "text": text,
            "font": font_family,
            "size": int(size),
            "color": QColor(color).name(QColor.NameFormat.HexArgb),
            "italic": True,
        }
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setFocus(Qt.FocusReason.OtherFocusReason)

    def undo(self):
        if self.text_items:
            self.text_items.pop()
            self.update()
        elif self.strokes:
            gruppo = self.strokes[-1].get("gruppo")
            self.strokes.pop()
            while gruppo is not None and self.strokes and self.strokes[-1].get("gruppo") == gruppo:
                self.strokes.pop()          # una parola inserita si annulla in un solo passo
            self.current_stroke = None
            self.update()

    def remove_group(self, gruppo):
        """Toglie dal foglio tutti i tratti di un gruppo (una parola inserita)."""
        self.strokes[:] = [s for s in self.strokes if s.get("gruppo") != gruppo]
        self.update()

    def insert_word_strokes(self, tratti, riga, par, scala=None, x=None, y=None, sostituisci=None):
        """Inserisce nel foglio i tratti di una parola in corsivo con le larghezze della punta simulata.

        Le parole successive si dispongono una sotto l'altra. Restituisce il numero di tratti inseriti.
        """
        if not tratti or not riga:
            return 0
        if sostituisci is not None:
            self.remove_group(sostituisci)
        larghezza = max(self.width(), 700)
        span_x = max(riga["x1"] - riga["x0"], 1.0)
        # scala: altezza della x in pixel (automatica se non indicata)
        sc = float(scala) if scala else max(14.0, min((larghezza - 120) / span_x, 44.0))
        if self._insert_y is None:
            self._insert_y = 40 + 2.4 * sc
        if y:
            base_y = float(y)
        else:
            base_y = min(self._insert_y, max(self.height() - 1.6 * sc, 60))
        ox = (float(x) if x else 60.0) - riga["x0"] * sc
        colore = QColor(self.ink)
        colore.setAlpha(round(255 * max(0, min(100, self.ink_opacity)) / 100))
        self._gruppo_n += 1
        inseriti = 0
        for tratto in tratti:
            segs = segmenti_pressione(tratto, par["spessore"], par["filetto"], par.get("penna_larga"))
            if not segs:
                continue
            punti = [(ox + segs[0][0][0] * sc, base_y + segs[0][0][1] * sc, 1.0)]
            larghezze = []
            for (_a, b, w) in segs:
                punti.append((ox + b[0] * sc, base_y + b[1] * sc, max(0.1, min(1.0, w / par["spessore"]))))
                larghezze.append(w * sc)
            self.strokes.append({
                "points": punti, "widths": larghezze,
                "color": colore.name(QColor.NameFormat.HexArgb),
                "width": float(self.base_width), "nib_width_mm": float(self.nib_width_mm),
                "nib_angle": float(self.nib_angle_degrees), "pressure_scale": float(self.nib_pressure_scale),
                "gruppo": self._gruppo_n,
            })
            inseriti += 1
        if not y:
            self._insert_y = base_y + (riga["y1"] - riga["y0"] + 0.9) * sc
        self.update()
        return inseriti

    def clear_canvas(self):
        self._insert_y = None
        self.strokes.clear()
        self.text_items.clear()
        self.pending_text = None
        self.typing_mode = False
        self.typing_text = ""
        self.setCursor(Qt.CursorShape.ArrowCursor)
        self.current_stroke = None
        self.update()

    def export_png(self, filename):
        image = QImage(
            self.size(),
            QImage.Format.Format_ARGB32_Premultiplied
        )
        image.fill(self.paper)

        painter = QPainter(image)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            if self.show_guides:
                self._draw_guides(painter)
            for stroke in self.strokes:
                self._draw_stroke(painter, stroke)
            self._draw_text_items(painter)
        finally:
            painter.end()

        if not image.save(filename, "PNG"):
            raise OSError("Impossibile salvare l'immagine PNG.")

    def save_project(self, filename, style_name):
        data = {
            "version": 1,
            "style": style_name,
            "ink": self.ink.name(QColor.NameFormat.HexArgb),
            "base_width": self.base_width,
            "nib_width_mm": self.nib_width_mm,
            "nib_angle_degrees": self.nib_angle_degrees,
            "slant_degrees": self.slant_degrees,
            "guide_nibs": self.guide_nibs,
            "style_guides": self.cancelleresca_guides,
            "nib_pressure_scale": self.nib_pressure_scale,
            "opacity": self.ink_opacity,
            "show_guides": self.show_guides,
            "strokes": self.strokes,
            "text_items": self.text_items,
        }

        with open(filename, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False)

    def load_project(self, filename):
        with open(filename, "r", encoding="utf-8") as file:
            data = json.load(file)

        strokes = data.get("strokes", [])
        if not isinstance(strokes, list):
            raise ValueError("Il progetto non contiene tratti validi.")

        self.strokes = strokes
        self.nib_width_mm = float(data.get("nib_width_mm", self.nib_width_mm))
        self.nib_angle_degrees = float(data.get("nib_angle_degrees", self.nib_angle_degrees))
        self.progetto_con_gradi = "slant_degrees" in data      # i vecchi progetti non hanno i gradi salvati
        self.slant_degrees = float(data.get("slant_degrees", self.slant_degrees))
        self.guide_nibs = float(data.get("guide_nibs", self.guide_nibs))
        self.cancelleresca_guides = bool(data.get("style_guides", self.cancelleresca_guides))
        self.nib_pressure_scale = float(data.get("nib_pressure_scale", self.nib_pressure_scale))
        self.text_items = data.get("text_items", [])
        if not isinstance(self.text_items, list):
            self.text_items = []
        self.pending_text = None
        self.current_stroke = None
        self.ink = QColor(data.get("ink", "#292018"))
        self.base_width = int(data.get("base_width", 5))
        self.ink_opacity = int(data.get("opacity", 100))
        self.show_guides = bool(data.get("show_guides", True))
        self.update()

        return data.get("style", "Cancelleresca / Italica")


# Ductus didattico iniziale: sequenze operative semplificate per esercitarsi.
# Le forme sono modelli di studio, non una ricostruzione paleografica universale.
DUCTUS_CANCELLERESCA = {
    "i": ["Tratto 1 · Asta principale: scendi dall'alto alla linea di base con inclinazione costante.", "Tratto 2 · Punto: aggiungilo centrato sopra l'asta, separato e leggero."],
    "l": ["Tratto 1 · Asta ascendente: parti dalla zona superiore e scendi con movimento continuo fino alla base.", "Controllo · Mantieni la stessa inclinazione delle altre aste e una pressione uniforme."],
    "t": ["Tratto 1 · Asta: scendi dall'altezza delle ascendenti verso la linea di base.", "Tratto 2 · Barra: attraversa l'asta nella zona alta del corpo, con tratto breve e deciso."],
    "o": ["Tratto 1 · Forma ovale: inizia nella zona alta a destra e costruisci il controtratto con curva continua.", "Controllo · Chiudi senza angoli; conserva asse e larghezza coerenti con il modulo."],
    "c": ["Tratto 1 · Curva aperta: entra dall'alto, gira verso sinistra e ridiscendi.", "Tratto 2 · Uscita: termina sul lato destro lasciando aperta la forma."],
    "e": ["Tratto 1 · Corpo ovale aperto: costruisci la curva come per la o.", "Tratto 2 · Barra mediana: attraversa il corpo con gesto leggero, mantenendo l'apertura."],
    "n": ["Tratto 1 · Asta d'ingresso: scendi fino alla base.", "Tratto 2 · Spalla: risali con curva e ridiscendi formando la seconda asta.", "Controllo · La spalla deve essere regolare, non appuntita."],
    "m": ["Tratto 1 · Asta d'ingresso.", "Tratto 2 · Prima spalla e seconda asta.", "Tratto 3 · Seconda spalla e asta finale.", "Controllo · Distribuisci le due spalle in modo equilibrato nel corpo di 5 larghezze."],
    "u": ["Tratto 1 · Asta discendente fino alla base.", "Tratto 2 · Fondo arrotondato e risalita verso l'altezza del corpo.", "Controllo · Evita un fondo troppo appuntito."],
    "r": ["Tratto 1 · Asta principale.", "Tratto 2 · Spalla breve in uscita dalla parte alta dell'asta.", "Controllo · Non trasformare la spalla in un arco troppo ampio."],
    "a": ["Tratto 1 · Corpo ovale, proporzionato al modulo.", "Tratto 2 · Asta di chiusura sul lato destro, con uscita fluida.", "Controllo · Mantieni il controspazio aperto e leggibile."],
    "d": ["Tratto 1 · Corpo ovale.", "Tratto 2 · Asta ascendente sul lato destro, fino alla quota superiore.", "Controllo · L'asta deve superare il corpo senza alterarne la larghezza."],
}


# Completamento dell'alfabeto: le sequenze testuali sono indicazioni didattiche
# generali; i tracciati qui sotto sono schemi vettoriali semplificati da calibrare
# sul facsimile storico scelto, non un ductus canonico valido per ogni mano.
for _ch in "abcdefghijklmnopqrstuvwxyz":
    DUCTUS_CANCELLERESCA.setdefault(_ch, [
        "Tratto 1 · Costruisci il corpo della lettera entro la fascia mediana (modulo iniziale 5× pennino).",
        "Tratto 2 · Completa asta, curva o legatura secondo la forma del modello.",
        "Controllo · Mantieni inclinazione coerente, controspazi leggibili e uscita fluida."
    ])
for _ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
    DUCTUS_CANCELLERESCA[_ch] = [
        "Tratto 1 · Imposta la struttura principale della maiuscola, dall'alto verso il basso dove possibile.",
        "Tratto 2 · Completa diagonali e curve rispettando l'equilibrio tra pieni e filetti.",
        "Controllo · Le maiuscole ammettono varianti ornamentali: confronta sempre il modello con l'esemplare scelto."
    ]



class DuctusCanvas(QWidget):
    """Anteprima grafica: rivela progressivamente i tratti del modello."""
    MODELS = {
        "i": [[(0.34,0.30),(0.30,0.78)],[(0.34,0.17),(0.34,0.18)]],
        "l": [[(0.42,0.12),(0.34,0.78)]],
        "t": [[(0.43,0.16),(0.36,0.78)],[(0.25,0.42),(0.58,0.37)]],
        "o": [[(0.55,0.28),(0.43,0.22),(0.30,0.31),(0.28,0.56),(0.39,0.76),(0.53,0.72),(0.61,0.48),(0.55,0.28)]],
        "c": [[(0.58,0.29),(0.45,0.22),(0.31,0.34),(0.29,0.58),(0.43,0.75),(0.58,0.68)]],
        "e": [[(0.29,0.49),(0.58,0.45),(0.54,0.29),(0.40,0.23),(0.29,0.39),(0.31,0.62),(0.46,0.75),(0.59,0.66)]],
        "n": [[(0.28,0.78),(0.34,0.28)],[(0.34,0.43),(0.47,0.25),(0.58,0.34),(0.57,0.78)]],
        "m": [[(0.22,0.78),(0.28,0.28)],[(0.28,0.43),(0.39,0.25),(0.47,0.37),(0.46,0.78)],[(0.46,0.42),(0.57,0.25),(0.68,0.37),(0.66,0.78)]],
        "u": [[(0.28,0.28),(0.27,0.61),(0.38,0.76),(0.51,0.70),(0.59,0.28)]],
        "r": [[(0.31,0.78),(0.36,0.28)],[(0.36,0.43),(0.49,0.27),(0.61,0.34)]],
        "a": [[(0.54,0.30),(0.43,0.22),(0.30,0.33),(0.29,0.57),(0.40,0.75),(0.53,0.68)],[(0.55,0.28),(0.51,0.78)]],
        "d": [[(0.48,0.30),(0.39,0.22),(0.28,0.34),(0.28,0.58),(0.39,0.75),(0.50,0.67)],[(0.53,0.12),(0.49,0.78)]]
    }
    # Schemi vettoriali delle maiuscole: tratti separati per la lezione animata.
    CAPITAL_MODELS = {
        "A": [[(.18,.78),(.48,.16),(.78,.78)],[(.31,.52),(.66,.52)]],
        "B": [[(.27,.78),(.27,.16),(.53,.16),(.72,.27),(.69,.42),(.53,.49),(.27,.49)],[(.27,.49),(.56,.49),(.74,.60),(.70,.74),(.55,.78),(.27,.78)]],
        "C": [[(.73,.25),(.60,.16),(.39,.17),(.23,.34),(.22,.60),(.40,.77),(.62,.76),(.74,.66)]],
        "D": [[(.27,.78),(.27,.16),(.48,.16),(.70,.29),(.76,.49),(.68,.68),(.48,.78),(.27,.78)]],
        "E": [[(.70,.16),(.27,.16),(.27,.78),(.72,.78)],[(.27,.47),(.62,.47)]],
        "F": [[(.28,.78),(.28,.16),(.72,.16)],[(.28,.46),(.63,.46)]],
        "G": [[(.72,.27),(.60,.17),(.39,.17),(.23,.34),(.22,.60),(.40,.77),(.67,.74),(.72,.53),(.52,.53)]],
        "H": [[(.25,.16),(.25,.78)],[(.73,.16),(.73,.78)],[(.25,.48),(.73,.48)]],
        "I": [[(.35,.16),(.65,.16)],[(.50,.16),(.50,.78)],[(.35,.78),(.65,.78)]],
        "J": [[(.66,.16),(.66,.61),(.57,.76),(.39,.78),(.25,.68)]],
        "K": [[(.27,.16),(.27,.78)],[(.72,.16),(.29,.49),(.74,.78)]],
        "L": [[(.28,.16),(.28,.78),(.72,.78)]],
        "M": [[(.18,.78),(.22,.16),(.49,.55),(.76,.16),(.81,.78)]],
        "N": [[(.24,.78),(.24,.16),(.75,.78),(.75,.16)]],
        "O": [[(.49,.16),(.29,.23),(.21,.47),(.27,.69),(.49,.78),(.70,.69),(.78,.47),(.70,.23),(.49,.16)]],
        "P": [[(.27,.78),(.27,.16),(.55,.16),(.73,.28),(.70,.43),(.54,.50),(.27,.50)]],
        "Q": [[(.49,.16),(.29,.23),(.21,.47),(.27,.69),(.49,.78),(.70,.69),(.78,.47),(.70,.23),(.49,.16)],[(.56,.63),(.79,.84)]],
        "R": [[(.27,.78),(.27,.16),(.55,.16),(.73,.28),(.70,.43),(.54,.50),(.27,.50)],[(.50,.50),(.75,.78)]],
        "S": [[(.72,.25),(.59,.16),(.38,.18),(.25,.31),(.35,.45),(.63,.53),(.74,.66),(.61,.77),(.37,.77),(.24,.68)]],
        "T": [[(.20,.16),(.80,.16)],[(.50,.16),(.50,.78)]],
        "U": [[(.25,.16),(.25,.59),(.36,.76),(.63,.76),(.75,.59),(.75,.16)]],
        "V": [[(.20,.16),(.49,.78),(.80,.16)]],
        "W": [[(.16,.16),(.30,.78),(.49,.43),(.68,.78),(.84,.16)]],
        "X": [[(.23,.16),(.76,.78)],[(.76,.16),(.23,.78)]],
        "Y": [[(.20,.16),(.50,.47),(.80,.16)],[(.50,.47),(.50,.78)]],
        "Z": [[(.23,.16),(.77,.16),(.23,.78),(.77,.78)]]
    }
    MODELS.update(CAPITAL_MODELS)
    MODELS.update({
        "b": [[(.34,.12),(.32,.78)],[(.33,.48),(.45,.27),(.59,.30),(.65,.49),(.59,.70),(.43,.76),(.33,.66)]],
        "f": [[(.53,.12),(.40,.20),(.39,.78)],[(.25,.42),(.58,.39)]],
        "g": [[(.52,.30),(.41,.23),(.29,.34),(.29,.57),(.41,.72),(.54,.64)],[(.54,.30),(.53,.84),(.42,.94),(.29,.90)]],
        "h": [[(.32,.12),(.31,.78)],[(.32,.47),(.46,.27),(.59,.32),(.60,.78)]],
        "j": [[(.53,.30),(.52,.84),(.42,.94),(.30,.90)],[(.53,.16),(.53,.17)]],
        "k": [[(.32,.12),(.31,.78)],[(.59,.29),(.32,.54),(.62,.78)]],
        "p": [[(.31,.30),(.31,.94)],[(.32,.43),(.45,.27),(.59,.32),(.63,.53),(.54,.70),(.32,.66)]],
        "q": [[(.52,.30),(.41,.23),(.29,.34),(.29,.57),(.41,.72),(.53,.64)],[(.54,.30),(.54,.94)]],
        "s": [[(.59,.33),(.48,.24),(.34,.31),(.38,.46),(.55,.54),(.59,.66),(.47,.76),(.32,.69)]],
        "v": [[(.27,.29),(.43,.77),(.61,.29)]],
        "w": [[(.23,.29),(.34,.77),(.47,.46),(.57,.77),(.70,.29)]],
        "x": [[(.29,.29),(.61,.77)],[(.61,.29),(.29,.77)]],
        "y": [[(.27,.29),(.43,.72),(.60,.29)],[(.60,.29),(.48,.82),(.35,.94)]],
        "z": [[(.30,.30),(.62,.30),(.30,.76),(.63,.76)]]
    })
    if tutti_i_modelli is not None:
        # Alfabeto greco (maiuscole e minuscole) e arabo (forme isolate): schemi didattici.
        MODELS.update(tutti_i_modelli(dict(MODELS)))
    def __init__(self, parent=None):
        super().__init__(parent); self.setMinimumHeight(190); self.setMinimumWidth(240)
        self.letter = 'a'; self.visible_count = 1; self.animation_progress = 1.0
        self.style_name = 'Minuscola carolina'
        self.nib_angle = None
        self.setStyleSheet("background:#fffaf0;border:1px solid #c6a36b;border-radius:10px")
    def set_style(self, name):
        self.style_name = str(name)
        self.nib_angle = nib_angolo(self.style_name) if nib_angolo else None
        self.update()
    @staticmethod
    def model_stilizzato(style, letter):
        """Tratti da mostrare: ductus specifico dello stile se esiste, altrimenti la variante dell'alfabeto base."""
        spec = modello_stile(style, letter) if modello_stile else None
        if spec:
            return spec
        base = DuctusCanvas.MODELS.get(letter)
        if base is None:
            return modello_oriente(letter) if modello_oriente is not None else None
        if trasforma_tratto is not None:
            return [trasforma_tratto(style, pts) for pts in base]
        return base
    def _styled_points(self, pts):
        if trasforma_tratto is not None:
            return trasforma_tratto(self.style_name, pts)
        # Varianti grafiche didattiche preliminari: non sono ancora tracciati
        # digitalizzati dal facsimile. Servono a rendere visibili le differenze
        # strutturali e saranno sostituite da coordinate rilevate sulle fonti.
        name = self.style_name.casefold()
        out = []
        for x, y in pts:
            if 'textura' in name:
                # Fascia stretta e verticalità accentuata.
                x = 0.5 + (x - 0.5) * 0.78
            elif 'rotunda' in name:
                # Modulo più largo e curve meno compresse.
                x = 0.5 + (x - 0.5) * 1.12
            elif 'bastarda' in name:
                # Inclinazione verso destra progressiva dall'alto al basso.
                x = x + (0.78 - y) * 0.20
            elif 'umanistica' in name:
                x = 0.5 + (x - 0.5) * 1.06
            out.append((max(0.04, min(0.96, x)), y))
        return out
    def set_model(self, letter, count):
        self.letter = letter; self.visible_count = count; self.animation_progress = 1.0; self.update()
    def set_animation_progress(self, progress):
        self.animation_progress = max(0.0, min(1.0, float(progress))); self.update()
    def paintEvent(self, event):
        painter = QPainter(self); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(18,12,-18,-12)
        _w = min(r.width(), int(r.height() * 1.3))   # i modelli sono disegnati per un riquadro ~1.3:1
        r.moveLeft(r.left() + (r.width() - _w) // 2); r.setWidth(_w)
        painter.setPen(QPen(QColor('#eadcc3'),1,Qt.PenStyle.DashLine))
        painter.drawLine(r.left(),int(r.top()+r.height()*.78),r.right(),int(r.top()+r.height()*.78))
        painter.drawLine(r.left(),int(r.top()+r.height()*.22),r.right(),int(r.top()+r.height()*.22))
        strokes = self.model_stilizzato(self.style_name, self.letter)
        if strokes is None:
            # Caratteri CJK: mostra il glifo come riferimento tipografico; il
            # percorso del pennello è spiegato nella lezione, non simulato qui.
            painter.setPen(QColor('#39251a'))
            font = QFont("Noto Serif CJK JP")
            font.setPointSize(max(42, int(min(r.width(), r.height()) * 0.43)))
            painter.setFont(font)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter, self.letter)
            return
        pen_tip = None
        nib = self.nib_angle if (self.nib_angle and poligoni_penna) else None
        for i, pts in enumerate(strokes):
            if i >= self.visible_count: break
            colore = QColor('#9a5a22') if i == self.visible_count-1 else QColor('#39251a')
            points=[QPointF(r.left()+x*r.width(),r.top()+y*r.height()) for x,y in pts]
            drawn=[]
            if points:
                drawn.append(points[0])
                if i == self.visible_count-1 and self.animation_progress < 1.0:
                    lengths=[]; total=0.0
                    for a,b in zip(points,points[1:]):
                        d=((b.x()-a.x())**2+(b.y()-a.y())**2)**0.5; lengths.append(d); total+=d
                    target=total*self.animation_progress; travelled=0.0; pen_tip=points[0]
                    for (a,b),d in zip(zip(points,points[1:]),lengths):
                        if travelled+d <= target:
                            drawn.append(b); pen_tip=b; travelled+=d
                        else:
                            fraction=0 if d==0 else (target-travelled)/d
                            pen_tip=QPointF(a.x()+(b.x()-a.x())*fraction,a.y()+(b.y()-a.y())*fraction)
                            if fraction>0: drawn.append(pen_tip)
                            break
                else:
                    drawn.extend(points[1:])
                    pen_tip=points[-1]
            if nib:
                # Penna a punta larga: il tratto è sottile quando il movimento segue il taglio.
                width = max(8.0, r.height()*0.10)
                painter.setPen(Qt.PenStyle.NoPen); painter.setBrush(colore)
                for quad in poligoni_penna([(p.x(), p.y()) for p in drawn], width, nib):
                    painter.drawPolygon(QPolygonF([QPointF(x, y) for x, y in quad]))
                painter.setBrush(Qt.BrushStyle.NoBrush)
            else:
                painter.setPen(QPen(colore, 7, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                path=QPainterPath()
                if drawn:
                    path.moveTo(drawn[0])
                    for point in drawn[1:]: path.lineTo(point)
                painter.drawPath(path)
        if pen_tip is not None and self.animation_progress < 1.0 and self.visible_count:
            painter.setPen(QPen(QColor('#6d3516'),2)); painter.setBrush(QColor('#e6a23c'))
            painter.drawEllipse(pen_tip,6,6)
        if nib:
            # Indicatore del taglio della penna (angolo sulla riga).
            import math as _m
            cx, cy = r.left()+22, r.top()+14
            dx, dy = _m.cos(_m.radians(nib))*13, -_m.sin(_m.radians(nib))*13
            painter.setPen(QPen(QColor('#6d3516'), 4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.FlatCap))
            painter.drawLine(QPointF(cx-dx, cy-dy), QPointF(cx+dx, cy+dy))
            painter.setPen(QColor('#6d3516'))
            painter.drawText(QPointF(cx+22, cy+5), f"penna {nib}°")
        painter.end()


class ParolaCanvas(QWidget):
    """Mostra una parola corsiva legata, con pressione simulata (pieni in discesa, filetti in salita)."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(260)
        self.tratti = []
        self.riga = None
        self.stile_id = "occidentale_copperplate"
        self.progress = 1.0
        self.totale = 0.0
        self.setStyleSheet("background:#fffaf0;border:1px solid #c6a36b;border-radius:10px")

    def imposta(self, tratti, riga, stile_id):
        self.tratti, self.riga, self.stile_id = tratti, riga, stile_id
        self.totale = lunghezza_tratti(tratti) if tratti else 0.0
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        if not self.tratti or not self.riga:
            painter.setPen(QColor('#8a7355'))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Scrivi una parola e premi «Scrivi».")
            painter.end(); return
        r = self.riga
        span_x = max(r["x1"] - r["x0"], 1.0); span_y = max(r["y1"] - r["y0"], 1.0)
        sc = min((w - 40) / span_x, (h - 30) / span_y)
        ox = (w - span_x * sc) / 2 - r["x0"] * sc
        oy = (h - span_y * sc) / 2 - r["y0"] * sc
        painter.setPen(QPen(QColor('#e6d3b3'), 1, Qt.PenStyle.DashLine))
        for y in (0, -1, -2.2, 1.3):
            painter.drawLine(QPointF(10, oy + y * sc), QPointF(w - 10, oy + y * sc))
        par = STILI_CORSIVI[self.stile_id]
        limite = self.progress * self.totale
        percorso = 0.0
        punta = None
        for tratto in self.tratti:
            for (a, b, spessore) in segmenti_pressione(tratto, par["spessore"], par["filetto"], par.get("penna_larga")):
                d = ((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2) ** 0.5
                if percorso >= limite:
                    break
                fine = b
                if percorso + d > limite and d > 0:
                    t = (limite - percorso) / d
                    fine = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
                painter.setPen(QPen(QColor('#39251a'), max(1.0, spessore * sc), Qt.PenStyle.SolidLine,
                                    Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.drawLine(QPointF(ox + a[0] * sc, oy + a[1] * sc), QPointF(ox + fine[0] * sc, oy + fine[1] * sc))
                punta = fine
                percorso += d
            if percorso >= limite:
                break
        if punta is not None and self.progress < 1.0:
            painter.setPen(QPen(QColor('#6d3516'), 2)); painter.setBrush(QColor('#e6a23c'))
            painter.drawEllipse(QPointF(ox + punta[0] * sc, oy + punta[1] * sc), 5, 5)
        painter.end()


class ParolaCorsivaDialog(QDialog):
    """Scrive una parola in corsivo legato con lo stile scelto (copperplate o spencerian)."""
    def __init__(self, parent=None, stile_id=None, foglio=None):
        super().__init__(parent)
        self.foglio = foglio
        self.setWindowTitle("Parola in corsivo · legature")
        self.resize(860, 440)
        layout = QVBoxLayout(self)
        self.ids = list(STILI_CORSIVI.keys())
        riga = QHBoxLayout()
        riga.addWidget(QLabel("Testo:"))
        self.testo = QLineEdit("amore")
        riga.addWidget(self.testo, 1)
        riga.addWidget(QLabel("Stile:"))
        self.stile = QComboBox()
        self.stile.addItems([STILI_CORSIVI[i]["nome"] for i in self.ids])
        if stile_id in self.ids:
            self.stile.setCurrentText(STILI_CORSIVI[stile_id]["nome"])
        riga.addWidget(self.stile)
        scrivi = QPushButton("✒ Scrivi")
        scrivi.clicked.connect(self.scrivi)
        tutto = QPushButton("Mostra tutto")
        tutto.clicked.connect(self.mostra_tutto)
        esporta_svg = QPushButton("💾 Esporta SVG")
        esporta_svg.setEnabled(svg_testo is not None)
        esporta_svg.clicked.connect(self.esporta_svg)
        riga.addWidget(scrivi); riga.addWidget(tutto); riga.addWidget(esporta_svg)
        inserisci = QPushButton("📌 Inserisci nel foglio")
        inserisci.setEnabled(foglio is not None)
        inserisci.clicked.connect(lambda: self.inserisci_nel_foglio(False))
        riga.addWidget(inserisci)
        layout.addLayout(riga)

        # Controllo di dimensione e posizione (0 = automatico)
        controlli = QHBoxLayout()
        controlli.addWidget(QLabel("Dimensione:"))
        self.spin_scala = QSpinBox(); self.spin_scala.setRange(0, 90); self.spin_scala.setSuffix(" px"); self.spin_scala.setSpecialValueText("auto")
        controlli.addWidget(self.spin_scala)
        controlli.addWidget(QLabel("X:"))
        self.spin_x = QSpinBox(); self.spin_x.setRange(0, 4000); self.spin_x.setSpecialValueText("auto")
        controlli.addWidget(self.spin_x)
        controlli.addWidget(QLabel("Y (riga di base):"))
        self.spin_y = QSpinBox(); self.spin_y.setRange(0, 4000); self.spin_y.setSpecialValueText("auto")
        controlli.addWidget(self.spin_y)
        self.btn_sostituisci = QPushButton("↻ Sostituisci l'ultima parola")
        self.btn_sostituisci.setEnabled(False)
        self.btn_sostituisci.clicked.connect(lambda: self.inserisci_nel_foglio(True))
        controlli.addWidget(self.btn_sostituisci)
        controlli.addStretch(1)
        layout.addLayout(controlli)
        self._ultimo_gruppo = None
        self.canvas = ParolaCanvas(self)
        layout.addWidget(self.canvas, 1)
        self.info = QLabel("")
        self.info.setWordWrap(True)
        layout.addWidget(self.info)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.passo)
        self.scrivi()

    def _costruisci(self):
        sid = self.ids[self.stile.currentIndex()]
        pulito, mancanti = parola_valida(self.testo.text(), sid)
        if not pulito.strip():
            self.canvas.imposta([], None, sid)
            self.info.setText("Scrivi almeno una lettera minuscola (a–z)." + (f" Non supportate: {' '.join(mancanti)}." if mancanti else ""))
            return False
        tratti, riga = costruisci_testo(pulito, sid)
        self.canvas.imposta(tratti, riga, sid)
        nota = f" Lettere non supportate e ignorate: {' '.join(mancanti)} (accenti, cifre e punteggiatura non ancora inclusi)." if mancanti else ""
        self.info.setText("Il filetto sale tra le lettere, i pieni scendono con la pressione; le traverse e i punti si fanno a parola finita. "
                          "Schema didattico: confrontalo con un manuale." + nota)
        return True

    def esporta_svg(self):
        """Salva la parola come SVG vettoriale: un contorno continuo per tratto, adatto a stampa,
        taglio laser e ricamo (la digitalizzazione per il ricamo resta da fare a parte)."""
        pulito, mancanti = parola_valida(self.testo.text(), self.ids[self.stile.currentIndex()])
        if not pulito.strip():
            QMessageBox.warning(self, "Niente da esportare", "Scrivi almeno una lettera prima di esportare.")
            return
        sid = self.ids[self.stile.currentIndex()]
        nome, _filtro = QFileDialog.getSaveFileName(self, "Esporta SVG", pulito.strip().replace(" ", "_") + ".svg", "Immagine vettoriale SVG (*.svg)")
        if not nome:
            return
        if not nome.lower().endswith(".svg"):
            nome += ".svg"
        try:
            contenuto = svg_testo(pulito, sid, titolo=pulito)
            with open(nome, "w", encoding="utf-8") as f:
                f.write(contenuto)
        except OSError as errore:
            QMessageBox.critical(self, "Errore di salvataggio", str(errore))
            return
        avviso = f" (lettere ignorate: {' '.join(mancanti)})" if mancanti else ""
        QMessageBox.information(self, "SVG salvato", f"Salvato: {nome}{avviso}")

    def inserisci_nel_foglio(self, sostituisci=False):
        """Porta la parola sul foglio principale con dimensione e posizione scelte (0 = automatico).

        Con «Sostituisci» la parola inserita per ultima viene rifatta con i nuovi valori.
        """
        if self.foglio is None or not self._costruisci():
            return
        sid = self.ids[self.stile.currentIndex()]
        vecchio = self._ultimo_gruppo if (sostituisci and self._ultimo_gruppo is not None) else None
        n = self.foglio.insert_word_strokes(self.canvas.tratti, self.canvas.riga, STILI_CORSIVI[sid],
                                            scala=self.spin_scala.value() or None,
                                            x=self.spin_x.value() or None, y=self.spin_y.value() or None,
                                            sostituisci=vecchio)
        self._ultimo_gruppo = self.foglio._gruppo_n
        self.btn_sostituisci.setEnabled(True)
        self.canvas.progress = 1.0
        self.canvas.update()
        verbo = "sostituita" if vecchio is not None else "inserita"
        self.info.setText(f"Parola {verbo} nel foglio ({n} tratti). Con «Annulla» la togli in un solo passo; "
                          "cambia dimensione, X e Y e premi «Sostituisci l'ultima parola» per spostarla o ingrandirla. "
                          "Con «auto» le parole si dispongono una sotto l'altra.")

    def scrivi(self):
        self.timer.stop()
        if self._costruisci():
            self.canvas.progress = 0.0
            self.timer.start(30)

    def mostra_tutto(self):
        self.timer.stop()
        if self._costruisci():
            self.canvas.progress = 1.0
            self.canvas.update()

    def passo(self):
        self.canvas.progress = min(1.0, self.canvas.progress + 0.012)
        self.canvas.update()
        if self.canvas.progress >= 1.0:
            self.timer.stop()


class PracticeCanvas(QWidget):
    """Foglio di esercizio: registra il gesto libero dell'allievo."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(420, 280)
        self.setMouseTracking(True)
        self.letter = "a"
        self.style_name = ""
        self.strokes = []
        self.current = None
        self.pressure = 1.0
        self.nib_width = 5.0
        self.nib_angle = 30.0
        self.stroke_times = []
        self.current_times = None
        self.recording_started = None
        self.playback_elapsed = 0.0
        self.playback_active = False
        self.playback_started_at = None
        self.playback_timer = QTimer(self)
        self.playback_timer.setInterval(25)
        self.playback_timer.timeout.connect(self._advance_playback)
        self.setStyleSheet("background:#fffaf0;border:1px solid #c6a36b;border-radius:8px")

    def set_model(self, letter):
        self.letter = letter
        self.strokes.clear(); self.current = None; self.update()

    def clear(self):
        self.playback_timer.stop(); self.playback_active = False
        self.playback_started_at = None
        self.strokes.clear(); self.stroke_times.clear()
        self.current = None; self.current_times = None
        self.recording_started = None
        self.playback_elapsed = 0.0; self.update()

    def _elapsed_ms(self):
        return max(0.0, (time.perf_counter() - self.recording_started) * 1000.0) if self.recording_started else 0.0

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.playback_timer.stop(); self.playback_active = False
            # Un unico orologio per l'intera sessione: così le pause tra
            # tratti restano reali e la riproduzione non sovrappone i tratti.
            if self.recording_started is None:
                self.recording_started = time.perf_counter()
            self.current = [event.position()]
            self.current_times = [0.0]
            self.strokes.append(self.current); self.stroke_times.append(self.current_times)
            self.update()

    def mouseMoveEvent(self, event):
        if self.current is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.current.append(event.position())
            self.current_times.append(self._elapsed_ms())
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.current = None; self.current_times = None; self.update()

    def start_playback(self):
        if not self.strokes:
            return False
        self.playback_timer.stop()
        self.playback_elapsed = 0.0
        self.playback_started_at = time.perf_counter()
        self.playback_active = True
        self.playback_timer.start()
        self.update()
        return True

    def stop_playback(self):
        self.playback_timer.stop()
        self.playback_active = False
        self.playback_started_at = None
        self.update()

    def _advance_playback(self):
        # Usa un orologio monotono reale: il timer Qt è solo il battito di
        # aggiornamento e non accumula ritardi se il sistema è impegnato.
        if self.playback_started_at is not None:
            self.playback_elapsed = (time.perf_counter() - self.playback_started_at) * 1000.0
        total = max((times[-1] for times in self.stroke_times if times), default=0.0)
        if self.playback_elapsed >= total:
            self.playback_elapsed = total
            self.stop_playback()
        else:
            self.update()

    def _model_points(self, pts):
        r = self.rect().adjusted(55, 28, -55, -28)
        return [QPointF(r.left()+x*r.width(), r.top()+y*r.height()) for x,y in pts]

    def paintEvent(self, event):
        painter = QPainter(self); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(20, 20, -20, -20)
        painter.setPen(QPen(QColor('#eadcc3'), 1, Qt.PenStyle.DashLine))
        painter.drawLine(r.left(), int(r.top()+r.height()*.22), r.right(), int(r.top()+r.height()*.22))
        painter.drawLine(r.left(), int(r.top()+r.height()*.78), r.right(), int(r.top()+r.height()*.78))
        # Modello tenue: guida visiva, non un binario obbligatorio.
        models = DuctusCanvas.model_stilizzato(self.style_name, self.letter) or []
        pen = QPen(QColor(190, 160, 120, 105), 3, Qt.PenStyle.DashLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen)
        for stroke in models:
            pts = self._model_points(stroke)
            path = QPainterPath()
            if pts:
                path.moveTo(pts[0])
                for pt in pts[1:]: path.lineTo(pt)
                painter.drawPath(path)
        # Pennino tronco: lo spessore dipende dall'angolo tra il movimento
        # e il taglio della punta. È una simulazione didattica, non un modello
        # fisico completo della deformazione dell'inchiostro.
        color = QColor('#39251a')
        blade = math.radians(self.nib_angle)
        for stroke in self.strokes:
            if len(stroke) == 1:
                painter.setPen(QPen(color, max(1.0, self.nib_width * self.pressure * 0.18), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                painter.drawPoint(stroke[0])
                continue
            for a, b in zip(stroke, stroke[1:]):
                dx, dy = b.x() - a.x(), b.y() - a.y()
                if abs(dx) + abs(dy) < 0.01:
                    continue
                direction = math.atan2(dy, dx)
                projection = abs(math.sin(direction - blade))
                # Un piccolo spessore minimo mantiene visibili i raccordi.
                width = max(0.8, self.nib_width * self.pressure * (0.10 + 0.90 * projection))
                pen = QPen(color, width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
                painter.setPen(pen)
                painter.drawLine(a, b)
        # Riproduzione temporale del gesto registrato: mantiene pause e ordine dei tratti.
        if self.playback_active or self.playback_elapsed > 0:
            playback_pen = QPen(QColor('#c04b22'), 3.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
            painter.setPen(playback_pen)
            tip = None
            for stroke, times in zip(self.strokes, self.stroke_times):
                if len(stroke) < 2 or len(times) != len(stroke):
                    continue
                if self.playback_elapsed < times[0]:
                    continue
                path = QPainterPath()
                path.moveTo(stroke[0])
                reached = False
                for idx in range(1, len(stroke)):
                    t0, t1 = times[idx-1], times[idx]
                    a, b = stroke[idx-1], stroke[idx]
                    if self.playback_elapsed >= t1:
                        path.lineTo(b)
                        tip = b
                    elif self.playback_elapsed >= t0:
                        # Interpola la punta fra due campioni: il cursore
                        # avanza in modo continuo invece di saltare punto-punto.
                        fraction = 0.0 if t1 <= t0 else (self.playback_elapsed-t0)/(t1-t0)
                        fraction = max(0.0, min(1.0, fraction))
                        tip = QPointF(a.x()+(b.x()-a.x())*fraction,
                                      a.y()+(b.y()-a.y())*fraction)
                        path.lineTo(tip)
                        reached = True
                        break
                    else:
                        break
                if tip is not None and (self.playback_elapsed >= times[0]):
                    painter.drawPath(path)
                if reached:
                    break
            if tip is not None and self.playback_active:
                painter.setPen(QPen(QColor('#7b321b'), 1.2))
                painter.setBrush(QColor('#f0a34a'))
                painter.drawEllipse(tip, 4.5, 4.5)
        painter.end()


class PracticeDialog(QDialog):
    """Esercizio libero con guida tenue e feedback geometrico indicativo."""
    def __init__(self, letter, parent=None, style=None):
        super().__init__(parent)
        self.setWindowTitle(f"Esercitati · lettera {letter}")
        self.resize(720, 560)
        layout = QVBoxLayout(self)
        intro = QLabel("Ripassa la forma sul foglio. La traccia chiara è un riferimento: puoi interpretare il gesto con naturalezza. Con il mouse la pressione è simulata; una tavoletta può fornire dati di pressione reali se supportata.")
        intro.setWordWrap(True); layout.addWidget(intro)
        self.canvas = PracticeCanvas(self); self.canvas.style_name = style or ""; self.canvas.set_model(letter); layout.addWidget(self.canvas, 1)
        row = QHBoxLayout(); row.addWidget(QLabel("Pressione simulata:"))
        self.pressure = QSlider(Qt.Orientation.Horizontal); self.pressure.setRange(25, 150); self.pressure.setValue(100)
        self.pressure.valueChanged.connect(self.change_pressure); row.addWidget(self.pressure)
        self.pressure_label = QLabel("100%"); row.addWidget(self.pressure_label); layout.addLayout(row)
        nib_row = QHBoxLayout(); nib_row.addWidget(QLabel("Larghezza pennino:"))
        self.nib_size = QDoubleSpinBox(); self.nib_size.setRange(0.5, 8.0); self.nib_size.setSingleStep(0.5)
        self.nib_size.setValue(1.5); self.nib_size.setSuffix(" mm")
        self.nib_size.valueChanged.connect(self.change_nib_size); nib_row.addWidget(self.nib_size)
        nib_row.addWidget(QLabel("Angolo del taglio:"))
        self.nib_angle = QSpinBox(); self.nib_angle.setRange(0, 90); self.nib_angle.setValue(30); self.nib_angle.setSuffix("°")
        self.nib_angle.valueChanged.connect(self.change_nib_angle); nib_row.addWidget(self.nib_angle)
        layout.addLayout(nib_row)
        self.canvas.nib_angle = float(self.nib_angle.value())
        self.nib_note = QLabel("Pennino tronco simulato: lo spessore cambia con larghezza, pressione impostata e direzione del gesto rispetto al taglio.")
        self.nib_note.setWordWrap(True); layout.addWidget(self.nib_note)
        self.result = QLabel("Disegna la lettera e premi «Valuta il gesto» per un riscontro orientativo.")
        self.result.setWordWrap(True); layout.addWidget(self.result)
        buttons = QHBoxLayout()
        clear = QPushButton("Cancella"); clear.clicked.connect(self.canvas.clear)
        play = QPushButton("▶ Riproduci gesto"); play.clicked.connect(self.play_gesture)
        restart = QPushButton("↺ Da capo"); restart.clicked.connect(self.restart_playback)
        evaluate = QPushButton("Valuta il gesto"); evaluate.clicked.connect(self.evaluate)
        close = QPushButton("Chiudi"); close.clicked.connect(self.accept)
        buttons.addWidget(clear); buttons.addWidget(play); buttons.addWidget(restart)
        buttons.addWidget(evaluate); buttons.addStretch(1); buttons.addWidget(close); layout.addLayout(buttons)

    def play_gesture(self):
        if not self.canvas.start_playback():
            self.result.setText("Prima disegna almeno un tratto, poi potrai rivedere il tuo gesto.")

    def restart_playback(self):
        self.canvas.stop_playback()
        self.canvas.playback_elapsed = 0.0
        self.canvas.update()

    def change_pressure(self, value):
        self.canvas.pressure = value/100.0
        self.pressure_label.setText(f"{value}%"); self.canvas.update()

    def change_nib_size(self, value):
        # Conversione indicativa mm -> pixel a 96 dpi.
        self.canvas.nib_width = value * 3.78
        self.canvas.update()
        self.nib_note.setText(f"Pennino tronco {value:g} mm · taglio a {self.nib_angle.value()}°. Spessore orientato in base alla direzione del tratto; pressione impostata manualmente.")

    def change_nib_angle(self, value):
        self.canvas.nib_angle = float(value)
        self.canvas.update()
        self.nib_note.setText(f"Pennino tronco {self.nib_size.value():g} mm · taglio a {value}°. Lo spessore varia ora in base alla direzione del gesto rispetto al taglio; il mouse non rileva la pressione reale.")

    def evaluate(self):
        strokes = [s for s in self.canvas.strokes if len(s) > 1]
        if not strokes:
            self.result.setText("Non vedo ancora un tratto: disegna la lettera sul foglio."); return
        pts = [pt for st in strokes for pt in st]
        xs = [pt.x() for pt in pts]; ys = [pt.y() for pt in pts]
        width = max(xs)-min(xs); height = max(ys)-min(ys)
        if height < 8 or width < 8:
            self.result.setText("Il gesto è molto piccolo. Prova a occupare meglio lo spazio tra le righe guida."); return
        ratio = width/height
        model = DuctusCanvas.model_stilizzato(self.canvas.style_name, self.canvas.letter)
        if not model:
            self.result.setText("Per questo carattere non c'è ancora uno schema vettoriale: il confronto geometrico non è disponibile. Usa la traccia di riferimento nella lezione e confronta a occhio con un modello storico.")
            return
        model_pts = [pt for st in model for pt in st]
        mx = max(x for x,y in model_pts)-min(x for x,y in model_pts)
        my = max(y for x,y in model_pts)-min(y for x,y in model_pts)
        target = mx/my if my else 0.6
        diff = abs(ratio-target)
        shape = "proporzioni vicine al riferimento" if diff < .22 else ("forma più larga del riferimento: prova a stringere il corpo" if ratio > target else "forma più stretta del riferimento: prova ad aprire il corpo")
        expected_strokes = len(model)
        stroke_feedback = ("numero di tratti in linea con lo schema" if len(strokes) == expected_strokes else
                           f"lo schema propone {expected_strokes} tratto/i: verifica la suddivisione del gesto")
        ratio_score = max(0, min(100, round(100 * (1 - diff / max(target, 0.1)))) )

        # Confronto didattico dell'ordine e del verso: normalizza i punti
        # nell'area utile del foglio e confronta inizio/fine dei tratti.
        area = self.canvas.rect().adjusted(55, 28, -55, -28)
        def norm_point(pt):
            return ((pt.x() - area.left()) / max(1, area.width()),
                    (pt.y() - area.top()) / max(1, area.height()))
        actual = [(norm_point(st[0]), norm_point(st[-1])) for st in strokes]
        expected = [(st[0], st[-1]) for st in model if len(st) >= 2]
        # Associa i tratti per somiglianza geometrica, non per indice:
        # una diversa sequenza esecutiva non deve falsare il confronto.
        def best_assignment(costs):
            if not costs:
                return []
            rows, cols = len(costs), len(costs[0])
            # DP bitmask: trova l'abbinamento globale minimo per il lato più corto.
            if rows <= cols:
                states = {0: (0.0, [])}
                for i in range(rows):
                    nxt = {}
                    for mask, (score, pairs) in states.items():
                        for j in range(cols):
                            if mask & (1 << j):
                                continue
                            nm = mask | (1 << j)
                            candidate = (score + costs[i][j], pairs + [(i, j)])
                            if nm not in nxt or candidate[0] < nxt[nm][0]:
                                nxt[nm] = candidate
                    states = nxt
                return min(states.values(), key=lambda item: item[0])[1]
            transposed = [[costs[i][j] for i in range(rows)] for j in range(cols)]
            return [(i, j) for j, i in best_assignment(transposed)]

        endpoint_costs = []
        for (a0, a1) in actual:
            row = []
            for e0, e1 in expected:
                # Il verso è parte del ductus: non consideriamo equivalente
                # un tratto eseguito al contrario solo perché ha gli stessi estremi.
                direct = (math.dist(a0, e0) + math.dist(a1, e1)) / 2
                row.append(direct)
            endpoint_costs.append(row)
        endpoint_pairs = best_assignment(endpoint_costs)
        endpoint_errors = [endpoint_costs[i][j] for i, j in endpoint_pairs]
        if endpoint_errors:
            mean_error = sum(endpoint_errors) / len(endpoint_errors)
            direction_score = max(0, min(100, round(100 * (1 - mean_error / 0.45))))
            # Tratti mancanti o aggiunti non devono sparire dal punteggio solo
            # perché l'assegnazione ottimale abbina il sottoinsieme più piccolo.
            count_gap = abs(len(strokes) - len(expected))
            direction_score = round(direction_score * min(1.0, len(expected) / max(len(strokes), len(expected), 1)))
            direction_feedback = ("partenze, arrivi e verso abbastanza vicini al modello" if mean_error < .16 and count_gap == 0 else
                                  "controlla partenze, arrivi e verso dei tratti; verifica anche eventuali tratti mancanti o aggiunti")
        else:
            direction_score = 0
            direction_feedback = "servono almeno due punti per ogni tratto"
        # Confronto della traiettoria: ricampionamento uniforme dei punti e
        # distanza simmetrica fra gesto e modello. È un feedback di forma,
        # non una certificazione paleografica né un obbligo di ricalco.
        def resample(points, count=24):
            if len(points) < 2:
                return points * count
            lengths = [0.0]
            for p0, p1 in zip(points, points[1:]):
                lengths.append(lengths[-1] + math.dist(p0, p1))
            total = lengths[-1]
            if total <= 1e-9:
                return [points[0]] * count
            out = []
            j = 1
            for k in range(count):
                target_d = total * k / (count - 1)
                while j < len(lengths)-1 and lengths[j] < target_d:
                    j += 1
                a, b = points[j-1], points[j]
                span = lengths[j] - lengths[j-1]
                t = 0.0 if span <= 1e-9 else (target_d-lengths[j-1])/span
                out.append((a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t))
            return out

        def align_gesture_shape(points):
            """Centra e uniforma la scala del singolo tratto, senza ruotarlo.

            In questo modo piccoli scostamenti di posizione e dimensione non
            vengono scambiati per errori di forma; direzione e collocazione
            restano valutate separatamente dai criteri precedenti.
            """
            if not points:
                return []
            cx = sum(x for x, _ in points) / len(points)
            cy = sum(y for _, y in points) / len(points)
            centered = [(x-cx, y-cy) for x, y in points]
            scale = max((math.hypot(x, y) for x, y in centered), default=0.0)
            if scale <= 1e-9:
                return [(0.0, 0.0) for _ in centered]
            return [(x/scale, y/scale) for x, y in centered]

        normalized_actual = [[norm_point(p) for p in st] for st in strokes]
        normalized_model = [list(st) for st in model if len(st) >= 2]
        actual_shapes = [align_gesture_shape(resample(st)) for st in normalized_actual]
        model_shapes = [align_gesture_shape(resample(st)) for st in normalized_model]

        def trajectory_dtw(a, b):
            """DTW simmetrica nel tempo: conserva il verso del tratto e tollera
            velocità diverse, senza confondere una traiettoria invertita con quella corretta.
            """
            if not a or not b:
                return 1.0
            previous = [float('inf')] * (len(b) + 1)
            previous[0] = 0.0
            for pa in a:
                current = [float('inf')] * (len(b) + 1)
                for j, pb in enumerate(b, 1):
                    cost = math.dist(pa, pb)
                    current[j] = cost + min(current[j-1], previous[j], previous[j-1])
                previous = current
            return previous[-1] / max(1, len(a) + len(b))

        shape_costs = [[trajectory_dtw(a, b) for b in model_shapes] for a in actual_shapes]
        shape_pairs = best_assignment(shape_costs)
        shape_errors = [shape_costs[i][j] for i, j in shape_pairs]
        # Penalizza esplicitamente tratti extra/mancanti: l'abbinamento parziale
        # non deve produrre un punteggio alto ignorando ciò che resta fuori.
        unmatched = abs(len(actual_shapes) - len(model_shapes))
        order_note = ("; sequenza dei tratti diversa dal modello, ma confronto geometrico abbinato"
                      if shape_pairs and [j for _, j in shape_pairs] != sorted(j for _, j in shape_pairs)
                      else "")
        if shape_errors:
            mean_shape_error = sum(shape_errors) / len(shape_errors)
            trajectory_score = max(0, min(100, round(100 * (1 - mean_shape_error / 0.32))))
            if model_shapes:
                trajectory_score = round(trajectory_score * max(0.0, 1.0 - unmatched / max(len(model_shapes), len(actual_shapes), 1)))
            trajectory_feedback = ("il percorso segue abbastanza da vicino la guida" if trajectory_score >= 75 and unmatched == 0 else
                                    (f"ci sono {unmatched} tratto/i in più o in meno rispetto al modello; " if unmatched else "") +
                                    "riguarda curvatura, verso e corrispondenza dei tratti")
        else:
            trajectory_score = 0
            trajectory_feedback = "non è stato possibile confrontare le traiettorie"

        # Analisi temporale: durata, pause tra tratti e ordine registrato.
        all_times = [t for seq in self.canvas.stroke_times for t in seq]
        duration = max(all_times, default=0.0) / 1000.0
        stroke_starts = [seq[0] for seq in self.canvas.stroke_times if seq]
        pauses = [(b-a)/1000.0 for a,b in zip(stroke_starts, stroke_starts[1:])]
        longest_pause = max(pauses, default=0.0)
        # Profilo del ritmo: descrittivo, non un voto. Si calcolano le velocità
        # dei segmenti solo quando l'intervallo temporale è sufficientemente
        # grande da non amplificare il rumore del mouse o del campionamento.
        segment_speeds = []
        for stroke, times in zip(self.canvas.strokes, self.canvas.stroke_times):
            if len(stroke) != len(times) or len(stroke) < 2:
                continue
            for p0, p1, t0, t1 in zip(stroke, stroke[1:], times, times[1:]):
                dt = (t1 - t0) / 1000.0
                if dt >= 0.008:
                    distance = math.hypot(p1.x() - p0.x(), p1.y() - p0.y())
                    if distance > 0.05:
                        segment_speeds.append(distance / dt)
        if len(segment_speeds) >= 3:
            ordered_speeds = sorted(segment_speeds)
            median_speed = ordered_speeds[len(ordered_speeds)//2]
            mean_speed = sum(segment_speeds) / len(segment_speeds)
            variance = sum((v - mean_speed) ** 2 for v in segment_speeds) / len(segment_speeds)
            speed_cv = math.sqrt(variance) / max(mean_speed, 1e-6)
            rhythm_note = ("andamento abbastanza uniforme" if speed_cv < 0.45 else
                           "andamento variabile: può essere una scelta espressiva oppure un segnale per rallentare nei raccordi")
            rhythm_feedback = f"velocità mediana {median_speed:.0f} px/s; {rhythm_note}"
        else:
            rhythm_feedback = "campioni temporali insufficienti per descrivere il ritmo"
        timing_feedback = (f"durata registrata {duration:.1f} s; pausa più lunga tra tratti {longest_pause:.1f} s; "
                           f"ordine di esecuzione: {len(strokes)} tratto/i; {rhythm_feedback}")

        self.result.setText(
            f"Riscontro orientativo — proporzioni: {ratio_score}/100; partenze/arrivi: {direction_score}/100; "
            f"somiglianza della traiettoria (DTW, tolleranza a velocità, posizione e scala): {trajectory_score}/100. "
            f"Hai eseguito {len(strokes)} tratto/i ({stroke_feedback}). {direction_feedback.capitalize()}; {trajectory_feedback}. "
            f"{timing_feedback}{order_note}. Puoi rivedere il gesto con «Riproduci gesto». "
            f"Ingombro: {width:.0f} × {height:.0f} px. {shape.capitalize()}. "
            "Punteggi geometrici indicativi, non voti: non valutano pressione reale, ritmo, qualità calligrafica o varianti storiche legittime. "
            "Il modello visivo disponibile può essere didattico e non una trascrizione certificata del manoscritto."
        )


# Riferimenti storico-documentari: distinguere sempre la famiglia grafica dal singolo esemplare.
# Le schede indicano dove verificare forme e varianti; non attestano ancora un alfabeto
# vettoriale integralmente trascritto per ciascuna scuola.
DUCTUS_HISTORICAL_REFERENCES = {
    "Onciale": ("Ad fontes · Uncial and Half-Uncial", "https://www.adfontes.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/unziale-und-halbunziale", "Confrontare mani onciali librarie: non trattare tutte le maiuscole come un unico alfabeto.", "Maiuscola libraria; ascendente/descendente non applicabili come nella minuscola."),
    "Semionciale": ("Ad fontes · Uncial and Half-Uncial", "https://www.adfontes.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/unziale-und-halbunziale", "Famiglia di mani diverse: scegliere un manoscritto preciso prima di fissare le forme.", "Sistema di rigatura e proporzioni da rilevare sull'esemplare selezionato."),
    "Minuscola carolina": ("Ad fontes · Caroline Minuscule", "https://histadfontes02.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/karolingische-minuskel", "Riferimento universitario per forme, evoluzione e varianti della minuscola carolina.", "Minuscola a quattro linee: misurare corpo, aste e discendenti sul facsimile scelto."),
    "Gotica Textura": ("Ad fontes · Gothic Textura / Textualis", "https://histadfontes02.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/spaetkarolingische-und-fruehgotische-minuskeln", "Textura documentata anche nel manoscritto di Rudolf von Ems, Weltchronik, circa 1350, UZH Ms. Rh. 15.", "Osservare fascia mediana compressa, aste e spezzature; misure da ricavare dal foglio."),
    "Gotica Rotunda": ("Ad fontes · Textura and Rotunda", "https://histadfontes02.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/spaetkarolingische-und-fruehgotische-minuskeln", "La pagina confronta una Rotunda italiana del XV secolo (UZH Ms. Rh. 182) con Textura.", "Non applicare le spezzature della Textura alle curve della Rotunda."),
    "Scrittura umanistica": ("University of Copenhagen · Script", "https://manuscript.ku.dk/production/writing/script/", "Descrizione della minuscola umanistica rinascimentale e del suo rapporto con la Carolina.", "Distinguere la libraria umanistica dalla corsiva umanistica."),
    "Cancelleresca / Italica": ("Stanford Libraries · Medieval fragments study collection", "https://oac.cdlib.org/findaid/ark:/13030/tf900006z6", "La raccolta include testimonianze di cancelleresca; per il ductus servirà identificare il singolo frammento.", "Inclinazione e rapporti dipendono dalla mano e dal manuale di riferimento."),
    "Copperplate / Roundhand": ("Internet Archive · Historical penmanship manuals", "https://archive.org/search?query=roundhand+penmanship+manual", "Usare un manuale storico identificato per ricostruire tratti, inclinazione e pressione.", "Pennino flessibile: non misurare il contrasto come larghezza costante di una punta larga."),
    "Bastarda (scrittura bastarda)": ("Ad fontes · Bastarda and Gothic Cursives", "https://histadfontes02.uzh.ch/en/tutorium/schriften-lesen/schriftgeschichte/spaetkarolingische-und-fruehgotische-minuskeln", "La pagina descrive la Bastarda e cita un Livre d'heures di Tours del XV secolo, UZH Ms. C 168.", "Famiglia variabile: scegliere una regione e un manoscritto per la tavola modello."),
    "Fraktur": ("University of Copenhagen · Script", "https://manuscript.ku.dk/production/writing/script/", "La Fraktur tipografica e la scrittura gotica manoscritta sono correlate ma non intercambiabili.", "Per esercizi a penna, non copiare automaticamente i glifi del carattere tipografico."),
    "Spencerian": ("Internet Archive · Spencerian penmanship manuals", "https://archive.org/search?query=spencerian+penmanship", "Selezionare un'edizione storica precisa del manuale Spencer prima della trascrizione dei modelli.", "Sistema a punta flessibile: ritmo, inclinazione e modulazione della pressione."),
}


class DuctusDialog(QDialog):
    """Guida interattiva al ductus delle minuscole e maiuscole cancelleresche."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Laboratorio del ductus · Cancelleresca")
        self.resize(650, 510)
        self.steps = []
        self.index = 0
        self.current_style = "Cancelleresca / Italica"
        self.grade_body = 5.0
        self.grade_asc = 5.0
        self.grade_desc = 5.0
        layout = QVBoxLayout(self)
        intro = QLabel("Scegli lo stile e la lettera. Il grado calligrafico è espresso in larghezze del pennino (modulo didattico modificabile, da verificare sul modello storico scelto).")
        intro.setWordWrap(True)
        layout.addWidget(intro)
        style_row = QHBoxLayout()
        style_row.addWidget(QLabel("Stile da studiare:"))
        self.style = QComboBox()
        self.style.addItems([x.get("nome", "") for x in BIBLIOTECA_STILI if x.get("tradizione") in ("Occidentale", "Araba e islamica", "Persiana e islamica", "Cinese", "Giapponese", "Moderna")])
        if self.style.count() == 0:
            self.style.addItems(["Cancelleresca / Italica", "Minuscola carolina"])
        self.style.setCurrentText("Cancelleresca / Italica")
        self.style.currentTextChanged.connect(self.change_style)
        style_row.addWidget(self.style, 1)
        style_row.addWidget(QLabel("Alfabeto:"))
        self.alphabet = QComboBox()
        self.alphabet.addItems(["Latino", "Greco"] if GRECO_MINUSCOLE else ["Latino"])
        self.alphabet.currentTextChanged.connect(lambda _t: self.change_style(self.current_style))
        style_row.addWidget(self.alphabet)
        layout.addLayout(style_row)
        grades = QHBoxLayout()
        self.body_grade_spin = QDoubleSpinBox(); self.body_grade_spin.setRange(1, 15); self.body_grade_spin.setSingleStep(0.5); self.body_grade_spin.setValue(5); self.body_grade_spin.setSuffix("× corpo")
        self.asc_grade_spin = QDoubleSpinBox(); self.asc_grade_spin.setRange(0, 15); self.asc_grade_spin.setSingleStep(0.5); self.asc_grade_spin.setValue(5); self.asc_grade_spin.setSuffix("× asc.")
        self.desc_grade_spin = QDoubleSpinBox(); self.desc_grade_spin.setRange(0, 15); self.desc_grade_spin.setSingleStep(0.5); self.desc_grade_spin.setValue(5); self.desc_grade_spin.setSuffix("× disc.")
        for w in (self.body_grade_spin, self.asc_grade_spin, self.desc_grade_spin):
            w.valueChanged.connect(self.update_grade_info); grades.addWidget(w)
        layout.addLayout(grades)
        self.grade_info = QLabel("Corpo 5× · ascendente 5× · discendente 5× · totale 15× pennino")
        self.grade_info.setObjectName("hint"); layout.addWidget(self.grade_info)
        row = QHBoxLayout()
        row.addWidget(QLabel("Lettera:"))
        self.letter = QComboBox()
        self.letter.addItems(list(DUCTUS_CANCELLERESCA.keys()))
        self.letter.currentTextChanged.connect(self.load_letter)
        row.addWidget(self.letter)
        self.glyph = QLabel("a")
        self.glyph.setStyleSheet("font-family: 'EB Garamond', 'DejaVu Serif'; font-size: 112px; color: #35251b; background: #fffaf0; border: 1px solid #c6a36b; border-radius: 10px; padding: 8px;")
        self.glyph.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.glyph.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        row.addWidget(self.glyph, 1)
        layout.addLayout(row)
        self.canvas = DuctusCanvas(self)
        self.canvas.set_style(self.current_style)
        layout.addWidget(self.canvas)
        self.description = QTextBrowser()
        self.description.setMinimumHeight(135)
        layout.addWidget(self.description, 1)
        self.progress = QLabel()
        layout.addWidget(self.progress)
        controls = QHBoxLayout()
        self.prev = QPushButton("← Indietro")
        self.prev.clicked.connect(self.previous_step)
        self.next = QPushButton("Tratto successivo →")
        self.next.clicked.connect(self.next_step)
        self.play = QPushButton("▶ Mostra sequenza")
        self.play.clicked.connect(self.play_sequence)
        self.animate_stroke = QPushButton("✒ Anima il tratto")
        self.animate_stroke.clicked.connect(self.animate_current_stroke)
        self.practice = QPushButton("✍ Esercitati sul foglio")
        self.practice.clicked.connect(self.open_practice)
        self.sheet_button = QPushButton("🖨 Foglio da stampare")
        self.sheet_button.setEnabled(costruisci_fogli is not None)
        self.sheet_button.clicked.connect(self.esporta_foglio)
        self.word_button = QPushButton("✒ Parola in corsivo")
        self.word_button.setEnabled(costruisci_testo is not None)
        self.word_button.clicked.connect(self.open_word)
        controls.addWidget(self.prev); controls.addWidget(self.next); controls.addWidget(self.animate_stroke); controls.addWidget(self.play); controls.addWidget(self.practice); controls.addWidget(self.word_button); controls.addWidget(self.sheet_button)
        layout.addLayout(controls)
        self.timer = QTimer(self)
        self.timer.setInterval(1400)
        self.timer.timeout.connect(self.next_step)
        self.stroke_timer = QTimer(self)
        self.stroke_timer.setInterval(25)
        self.stroke_timer.timeout.connect(self._advance_stroke_animation)
        self.stroke_progress = 0.0
        self.load_letter(self.letter.currentText())

    def esporta_foglio(self):
        """Crea un foglio di esercizi A4 (PDF a più pagine o PNG) per lo stile e l'alfabeto scelti."""
        stile = self.current_style
        lettere = [self.letter.itemText(i) for i in range(self.letter.count())]
        sottotitolo = []
        nib = nib_angolo(stile) if nib_angolo else None
        if nib:
            sottotitolo.append(f"Penna a punta larga a ≈ {nib}° · corpo ≈ 5 larghezze di penna")
        sottotitolo.append("Ricalca il modello grigio, poi scrivi da solo")
        pagine = costruisci_fogli(f"{stile} · foglio di esercizio", lettere,
                                  lambda c: DuctusCanvas.model_stilizzato(stile, c),
                                  nib=nib, stile_id=id_da_nome(stile), sottotitolo=" · ".join(sottotitolo))
        if not pagine:
            QMessageBox.information(self, "Foglio non disponibile", "Per questo stile non ci sono ancora tracciati da mostrare nel foglio.")
            return
        base = "foglio_" + "".join(ch if ch.isalnum() else "_" for ch in stile.casefold()).strip("_")
        nome, _filtro = QFileDialog.getSaveFileName(self, "Salva il foglio da stampare", base + ".pdf", "PDF (*.pdf);;Immagine PNG (*.png)")
        if not nome:
            return
        try:
            if nome.lower().endswith(".png"):
                for i, pagina in enumerate(pagine, 1):
                    img = QImage(pagina["larghezza"], pagina["altezza"], QImage.Format.Format_ARGB32)
                    img.fill(QColor("white"))
                    painter = QPainter(img); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
                    disegna_primitive(painter, pagina["prim"])
                    painter.end()
                    img.save(nome if len(pagine) == 1 else f"{nome[:-4]}_{i}.png")
            else:
                if not nome.lower().endswith(".pdf"):
                    nome += ".pdf"
                writer = QPdfWriter(nome)
                writer.setResolution(150)
                writer.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
                painter = QPainter(writer); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
                for i, pagina in enumerate(pagine):
                    if i:
                        writer.newPage()
                    disegna_primitive(painter, pagina["prim"])
                painter.end()
        except Exception as errore:
            QMessageBox.critical(self, "Errore di salvataggio", str(errore))
            return
        QMessageBox.information(self, "Foglio salvato", f"Foglio di esercizi salvato: {len(pagine)} pagine.\n{nome}")

    def open_word(self):
        sid = id_da_nome(self.current_style)
        foglio = getattr(self.parent(), "canvas", None)
        ParolaCorsivaDialog(self, sid if sid in STILI_CORSIVI else "occidentale_copperplate", foglio).exec()

    def open_practice(self):
        PracticeDialog(self.letter.currentText(), self, self.current_style).exec()

    def update_grade_info(self, *_):
        style_key = self.current_style.casefold()
        if any(token in style_key for token in ARAB_TOKENS):
            self.grade_info.setText("Sistema arabo: niente maiuscole/minuscole latine né gradi ascendenti/discendenti. Studia rombo-punto, linea di base e forme contestuali.")
            return
        if any(token in style_key for token in ("zhuanshu", "lishu", "kaishu", "xingshu", "caoshu", "ossa oracolari", "kaisho", "gyōsho", "gyosho", "sōsho", "sosho", "kana")):
            return
        self.grade_body = self.body_grade_spin.value()
        self.grade_asc = self.asc_grade_spin.value()
        self.grade_desc = self.desc_grade_spin.value()
        total = self.grade_body + self.grade_asc + self.grade_desc
        self.grade_info.setText(
            f"Corpo {self.grade_body:g}× · ascendente {self.grade_asc:g}× · "
            f"discendente {self.grade_desc:g}× · totale {total:g}× pennino"
        )

    def change_style(self, name):
        self.current_style = name
        self.canvas.set_style(name)
        self.setWindowTitle(f"Laboratorio del ductus · {name}")
        # Direzione e allineamento del glifo seguono il sistema di scrittura.
        # Qt applica lo shaping OpenType del font disponibile per l'arabo.
        is_rtl_script = any(token in name.casefold() for token in ARAB_TOKENS)
        if hasattr(self, "glyph"):
            self.glyph.setLayoutDirection(Qt.LayoutDirection.RightToLeft if is_rtl_script else Qt.LayoutDirection.LeftToRight)
            self.glyph.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.glyph.setTextFormat(Qt.TextFormat.PlainText)
            self.glyph.setToolTip("Scrittura da destra verso sinistra" if is_rtl_script else "Carattere di riferimento; non è un facsimile storico")
        # Profili iniziali orientativi: non sostituiscono le misure di un facsimile.
        profiles = {
            "Cancelleresca / Italica": (5, 5, 5),
            "Minuscola carolina": (4, 3, 3),
            "Gotica Textura": (4, 3, 3),
            "Gotica Rotunda": (5, 3, 3),
            "Fraktur": (5, 4, 4),
            "Bastarda": (5, 4, 4),
            "Onciale": (5, 0, 0),
            "Semionciale": (4, 2, 2),
            "Scrittura umanistica": (5, 3, 3),
            "Capitale Romana (Capitalis Monumentalis)": (7, 0, 0),
            "Rustica Romana (Capitalis Rustica)": (7, 0, 0),
        }
        is_arabic = any(token in name.casefold() for token in ARAB_TOKENS)
        is_chinese = any(token in name.casefold() for token in ("zhuanshu", "lishu", "kaishu", "xingshu", "caoshu", "ossa oracolari"))
        is_japanese = any(token in name.casefold() for token in ("kaisho", "gyōsho", "gyosho", "sōsho", "sosho", "kana"))
        if is_chinese or is_japanese:
            if is_chinese:
                sample_chars = list(KANJI_LISTA) + [c for c in "永地" if c not in KANJI_LISTA]
                self.grade_info.setText("Tradizione cinese: studia ordine e direzione dei tratti, struttura del carattere, centro di gravità e ritmo del pennello. Le proporzioni latine non si applicano.")
            else:
                if "kana" in name.casefold():
                    sample_chars = list(HIRAGANA_LISTA) + list(KATAKANA_LISTA)
                else:
                    sample_chars = list(KANJI_LISTA) + [c for c in "永春花道" if c not in KANJI_LISTA]
                self.grade_info.setText("Tradizione giapponese: esercita i tratti fondamentali e l'equilibrio del carattere; per i kana considera ritmo, continuità e tradizione manoscritta. Non usare gradi latini.")
            self.letter.blockSignals(True)
            self.letter.clear(); self.letter.addItems(sample_chars)
            self.letter.blockSignals(False)
            body, asc, desc = (0, 0, 0)
            self.alphabet.setEnabled(False)
            self.body_grade_spin.setEnabled(False); self.asc_grade_spin.setEnabled(False); self.desc_grade_spin.setEnabled(False)
        elif is_arabic:
            self.alphabet.setEnabled(False)
            arabic_letters = list(ARABO_LETTERE)
            self.letter.blockSignals(True)
            self.letter.clear(); self.letter.addItems(arabic_letters)
            self.letter.blockSignals(False)
            body, asc, desc = (0, 0, 0)
            self.body_grade_spin.setEnabled(False); self.asc_grade_spin.setEnabled(False); self.desc_grade_spin.setEnabled(False)
            self.grade_info.setText("Sistema arabo: niente maiuscole/minuscole latine né gradi ascendenti/discendenti. Studia rombo-punto, linea di base e forme contestuali.")
        else:
            self.body_grade_spin.setEnabled(True); self.asc_grade_spin.setEnabled(True); self.desc_grade_spin.setEnabled(True)
            wanted = self._latin_letters()
            if [self.letter.itemText(i) for i in range(self.letter.count())] != wanted:
                self.letter.blockSignals(True); self.letter.clear(); self.letter.addItems(wanted); self.letter.blockSignals(False)
            body, asc, desc = profiles.get(name, (5, 4, 4))
            self.alphabet.setEnabled(True)
        for spin, value in ((self.body_grade_spin, body), (self.asc_grade_spin, asc), (self.desc_grade_spin, desc)):
            spin.blockSignals(True); spin.setValue(value); spin.blockSignals(False)
        self.update_grade_info()
        self.load_letter(self.letter.currentText())

    def _latin_letters(self):
        if self.alphabet.currentText() == "Greco":
            return list(GRECO_MAIUSCOLE) + list(GRECO_MINUSCOLE)
        specifico = alfabeto_stile(self.current_style) if alfabeto_stile else None
        if specifico:
            return specifico
        return list(DUCTUS_CANCELLERESCA.keys())

    def load_letter(self, letter):
        self.timer.stop(); self.stroke_timer.stop()
        specific = passi_stile(self.current_style, letter) if (passi_stile and self.alphabet.currentText() == "Latino") else None
        if specific:
            # Ductus proprio dello stile: introduzione + un passo per tratto + note.
            self.steps = [introduzione_stile(self.current_style)] + specific
            self.step_offset = 1
            self.index = 0
            self.glyph.setText(letter)
            self.show_step()
            return
        ori = passi_oriente(letter) if passi_oriente is not None else None
        if ori:
            # Kana e caratteri semplici: tratti nell'ordine standard (sostituisce le vecchie lezioni generiche).
            self.steps = ["Tradizione dell'Asia orientale: tratti nell'ordine standard di scrittura; per il tratto del pennello osserva appoggio, corsa e rilascio."] + ori
            self.step_offset = 1
            self.index = 0
            self.glyph.setText(letter)
            self.show_step()
            return
        self.step_offset = 0
        base_steps = DUCTUS_CANCELLERESCA.get(letter)
        if base_steps is None:
            # Alfabeti aggiuntivi (greco, arabo): istruzioni generate dallo schema vettoriale.
            modello = DuctusCanvas.MODELS.get(letter)
            base_steps = descrivi_tratti(modello) if (modello and descrivi_tratti) else []
        self.steps = self._steps_for_style(letter, base_steps)
        self.index = 0
        self.glyph.setText(letter)
        self.show_step()

    def _steps_for_style(self, letter, base_steps):
        name = self.current_style.casefold()
        if any(token in name for token in ("zhuanshu", "lishu", "kaishu", "xingshu", "caoshu", "ossa oracolari", "kaisho", "gyōsho", "gyosho", "sōsho", "sosho", "kana")):
            prefix = ["Tradizione dell'Asia orientale: il carattere mostrato è un riferimento di studio, non un facsimile. Prima di scrivere, individua il modello storico e osserva numero e ordine dei tratti.", "Prepara il pennello: punta umida ma non sovraccarica; imposta postura, appoggio e dimensione del carattere.", "Esegui i tratti secondo la convenzione del carattere: dall'alto verso il basso e da sinistra verso destra quando previsto, rispettando eccezioni e precedenze.", "Controlla inizio, andamento e chiusura: pressione, velocità e sollevamento cambiano la qualità della linea.", "Valuta l'equilibrio complessivo: centro di gravità, spazi interni, pieni e vuoti.", "Ripeti lentamente, poi aumenta la continuità senza sacrificare struttura e leggibilità."]
            lezione = lezione_tratti(letter) if lezione_tratti else None
            if lezione:
                prefix += [f"Tratto {i}: {passo}" for i, passo in enumerate(lezione['passi'], 1)]
                prefix.append(lezione['nota'])
        elif any(token in name for token in ARAB_TOKENS):
            prefix = ["Tradizione araba: leggi e costruisci da destra verso sinistra. La forma isolata mostrata è solo un punto di partenza: studia le forme iniziale, mediana e finale, le connessioni e i punti diacritici sul modello scelto."]
        elif "carolina" in name:
            prefix = ["Modello carolino: costruisci forme regolari, aperte e ben separate; usa la punta larga secondo il facsimile scelto."]
        elif "textura" in name or "fraktur" in name or "bastarda" in name:
            prefix = ["Modello gotico: osserva aste, spezzature e densità; la forma esatta dipende dalla variante storica selezionata."]
        elif "rotunda" in name:
            prefix = ["Modello rotunda: privilegia curve più arrotondate rispetto alla textura; verifica le forme sul manoscritto di riferimento."]
        elif "onciale" in name:
            prefix = ["Modello onciale: studia le forme maiuscole/unciali e le curve; non applicare automaticamente le proporzioni della minuscola corsiva."]
        elif "umanistica" in name:
            prefix = ["Modello umanistico: cerca chiarezza, proporzioni classiche e ritmo regolare, riferendoti a una mano specifica."]
        elif "copperplate" in name or "roundhand" in name:
            prefix = ["Modello a punta flessibile: alleggerisci i risalti e aumenta gradualmente la pressione nei discendenti previsti; la sequenza va verificata sul manuale scelto."]
        elif "spencerian" in name:
            prefix = ["Modello Spencerian: privilegia movimento leggero, ovali e ritmo; non trasferire automaticamente il ductus Copperplate."]
        else:
            prefix = ["Modello introduttivo: usa le istruzioni come esercizio di scomposizione, non come ricostruzione storica certificata."]
        return prefix + list(base_steps)

    def show_step(self):
        if not self.steps: return
        self.stroke_timer.stop(); self.stroke_progress = 1.0
        html_steps = "".join(f"<p style='color:{'#70451f' if i == self.index else '#59432f'};font-size:15px;'><b>{'▶ ' if i == self.index else ''}{step}</b></p>" for i, step in enumerate(self.steps))
        ref = DUCTUS_HISTORICAL_REFERENCES.get(self.current_style)
        reference_html = ""
        if ref:
            title, url, evidence, proportions = ref
            reference_html = (
                "<div style='background:#f2e8d5;padding:9px;border:1px solid #c6a36b;border-radius:7px;'>"
                "<b>Riferimento storico da consultare</b><br>"
                f"<a href='{html.escape(url, quote=True)}'>{html.escape(title)}</a><br>"
                f"{html.escape(evidence)}<br><i>{html.escape(proportions)}</i><br>"
                "<b>Stato del modello:</b> riferimento documentario individuato; trascrizione vettoriale completa della singola mano ancora da verificare.</div><br>"
            )
        letter_note_html = ""
        if True:
            selected_letter = self.letter.currentText()
            nome_stile = self.current_style.casefold()
            if selected_letter and ord(selected_letter[0]) >= 0x0600:
                note = scheda_lettera_araba(self.current_style, selected_letter)
            elif selected_letter.isupper() and "carolina" in nome_stile:
                note = scheda_maiuscola_carolina(selected_letter)
            elif selected_letter.isupper() and ("canceller" in nome_stile or "italica" in nome_stile):
                note = scheda_maiuscola_cancelleresca(selected_letter)
            elif selected_letter.isupper():
                note = scheda_maiuscola_storica(self.current_style, selected_letter)
            elif "bastarda" in nome_stile:
                note = scheda_lettera_bastarda(selected_letter) or scheda_lettera_storica(self.current_style, selected_letter)
            else:
                note = scheda_lettera_storica(self.current_style, selected_letter)
            if note:
                items = "".join(f"<li>{html.escape(item)}</li>" for item in note["esercizio"])
                letter_note_html = (
                    "<div style='background:#fff8e9;padding:9px;border:1px solid #c6a36b;border-radius:7px;margin:8px 0;'>"
                    "<b>Osservazione paleografica della lettera</b><br>"
                    f"<b>Forma:</b> {html.escape(note['forma'])}<br>"
                    f"<b>Da osservare:</b> {html.escape(note['osservazione'])}"
                    f"<ol>{items}</ol></div>"
                )
        self.description.setOpenExternalLinks(True)
        self.description.setHtml(reference_html + "<h3 style='color:#573417'>" + html.escape(self.current_style) + " · lettera «" + html.escape(self.letter.currentText()) + "»</h3>" + letter_note_html + html_steps + "<p><i>Le indicazioni qui sotto sono esercizi introduttivi: non sono presentate come ductus storico certificato finché i tratti non saranno trascritti dal facsimile indicato.</i></p>")
        self.progress.setText(f"Passaggio {self.index + 1} di {len(self.steps)}")
        # Mostra i tratti grafici corrispondenti al passaggio corrente.
        self.canvas.set_style(self.current_style)
        n_tratti = len(DuctusCanvas.model_stilizzato(self.current_style, self.letter.currentText()) or [])
        offset = getattr(self, "step_offset", 0)
        if offset:
            # Introduzione: lettera completa; poi un tratto per passo; note finali: lettera completa.
            visibili = n_tratti if self.index < offset else min(self.index - offset + 1, n_tratti)
        else:
            visibili = min(self.index + 1, n_tratti)
        self.canvas.set_model(self.letter.currentText(), visibili)
        self.prev.setEnabled(self.index > 0)
        self.next.setEnabled(self.index < len(self.steps) - 1)

    def next_step(self):
        if self.index < len(self.steps) - 1: self.index += 1
        else: self.timer.stop()
        self.show_step()

    def previous_step(self):
        self.index = max(0, self.index - 1)
        self.timer.stop(); self.show_step()

    def animate_current_stroke(self):
        self.timer.stop()
        self.stroke_progress = 0.0
        self.canvas.set_animation_progress(0.0)
        self.stroke_timer.start()

    def _advance_stroke_animation(self):
        self.stroke_progress = min(1.0, self.stroke_progress + 0.025)
        self.canvas.set_animation_progress(self.stroke_progress)
        if self.stroke_progress >= 1.0:
            self.stroke_timer.stop()

    def play_sequence(self):
        self.stroke_timer.stop()
        self.index = 0; self.show_step(); self.animate_current_stroke(); self.timer.start()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self._ui_pronta = False
        self._applicando_progetto = False
        self.tema_corrente = TEMA_PREDEFINITO
        self.setWindowIcon(icona_applicazione())

        self.setWindowTitle("Calligrafia Studio")
        self.resize(1200, 780)
        self.setMinimumSize(850, 600)

        central = QWidget()
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        # Pannello laterale
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setMinimumWidth(260)
        sidebar.setMaximumWidth(280)

        side = QVBoxLayout(sidebar)
        side.setSpacing(12)

        title = QLabel("Calligrafia Studio")
        title.setObjectName("appTitle")
        title.setWordWrap(True)
        side.addWidget(title)

        subtitle = QLabel("Il tuo laboratorio di scrittura")
        subtitle.setWordWrap(True)
        side.addWidget(subtitle)

        side.addWidget(QLabel("TEMA"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(list(TEMI.keys()))
        self.theme_combo.setEnabled(bool(TEMI))
        self.theme_combo.currentTextChanged.connect(self.apply_theme)
        side.addWidget(self.theme_combo)

        side.addWidget(QLabel("BIBLIOTECA DEGLI STILI"))

        self.style_combo = QComboBox()
        self.style_combo.addItems(list(STYLES.keys()))
        self.style_combo.currentTextChanged.connect(self.update_description)
        side.addWidget(self.style_combo)

        self.description = QLabel(STYLES[self.style_combo.currentText()])
        self.description.setWordWrap(True)
        side.addWidget(self.description)

        library_button = QPushButton("📚 Apri biblioteca storica")
        library_button.clicked.connect(self.open_history_library)
        side.addWidget(library_button)

        side.addWidget(QLabel("SPESSORE DELL'INCHIOSTRO"))

        self.width_slider = QSlider(Qt.Orientation.Horizontal)
        self.width_slider.setRange(1, 24)
        self.width_slider.setValue(5)
        self.width_slider.valueChanged.connect(self.change_width)
        side.addWidget(self.width_slider)

        side.addWidget(QLabel("PENNINO TRONCO · LARGHEZZA"))
        self.nib_combo = QComboBox()
        self.nib_combo.addItems(["1 mm", "1,5 mm", "2 mm", "2,5 mm", "3 mm", "4 mm"])
        self.nib_combo.setCurrentText("2 mm")
        self.nib_combo.currentTextChanged.connect(self.change_nib_width)
        side.addWidget(self.nib_combo)

        side.addWidget(QLabel("ANGOLO DEL TAGLIO DEL PENNINO"))
        self.sheet_nib_angle = QSpinBox()
        self.sheet_nib_angle.setRange(0, 90)
        self.sheet_nib_angle.setValue(30)
        self.sheet_nib_angle.setSuffix("°")
        self.sheet_nib_angle.valueChanged.connect(self.change_sheet_nib_angle)
        side.addWidget(self.sheet_nib_angle)

        side.addWidget(QLabel("GESTO DEL MOUSE · STILE KRITA"))
        self.gesture_combo = QComboBox()
        self.gesture_combo.addItems(list(PRESET_GESTO.keys()))
        self.gesture_combo.setEnabled(bool(PRESET_GESTO))
        self.gesture_combo.currentTextChanged.connect(self.change_gesture_preset)
        side.addWidget(self.gesture_combo)
        self.gesture_slider = QSlider(Qt.Orientation.Horizontal)
        self.gesture_slider.setRange(0, 100)
        self.gesture_slider.valueChanged.connect(self.change_stabilizer)
        side.addWidget(self.gesture_slider)
        self.gesture_label = QLabel("")
        self.gesture_label.setObjectName("hint")
        self.gesture_label.setWordWrap(True)
        side.addWidget(self.gesture_label)
        gesture_hint = QLabel("Shift = linea retta · Shift+Ctrl = scatto 15°. Per scritture angolose (textura, fraktur) abbassa lo stabilizzatore: gli angoli netti si arrotondano.")
        gesture_hint.setObjectName("hint")
        gesture_hint.setWordWrap(True)
        side.addWidget(gesture_hint)

        side.addWidget(QLabel("PRESSIONE DEL TRATTO"))
        self.sheet_pressure = QSlider(Qt.Orientation.Horizontal)
        self.sheet_pressure.setRange(25, 150)
        self.sheet_pressure.setValue(100)
        self.sheet_pressure.valueChanged.connect(self.change_sheet_pressure)
        side.addWidget(self.sheet_pressure)
        self.sheet_pressure_label = QLabel("100% · simulata con il mouse")
        self.sheet_pressure_label.setObjectName("hint")
        side.addWidget(self.sheet_pressure_label)

        side.addWidget(QLabel("INCLINAZIONE DELLE ASTE · DALLA VERTICALE"))
        self.slant_spin = QDoubleSpinBox()
        self.slant_spin.setRange(0.0, 45.0)
        self.slant_spin.setSingleStep(0.5)
        self.slant_spin.setSuffix("°")
        self.slant_spin.setValue(10.0)
        self.slant_spin.setToolTip("Angolo delle aste rispetto alla verticale; regolabile secondo il modello scelto.")
        self.slant_spin.valueChanged.connect(self.change_slant)
        side.addWidget(self.slant_spin)

        self.canc_guides_check = QCheckBox("Guide dello stile (5 + 5 + 5)")
        self.canc_guides_check.toggled.connect(self.toggle_cancelleresca_guides)
        side.addWidget(self.canc_guides_check)
        self.guide_info = QLabel("Corpo, ascendenti e discendenti: 5 larghezze di pennino ciascuno.")
        self.guide_info.setWordWrap(True)
        self.guide_info.setObjectName("hint")
        side.addWidget(self.guide_info)

        self.nib_cursor_check = QCheckBox("Mostra impronta del pennino sul foglio")
        self.nib_cursor_check.setChecked(True)
        self.nib_cursor_check.toggled.connect(self.toggle_nib_cursor)
        side.addWidget(self.nib_cursor_check)

        self.ghost_check = QCheckBox("Mostra lettera modello in trasparenza")
        self.ghost_check.toggled.connect(self.toggle_letter_ghost)
        side.addWidget(self.ghost_check)
        self.ghost_letter_combo = QComboBox()
        self.ghost_letter_combo.addItems(list("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"))
        self.ghost_letter_combo.setCurrentText("a")
        self.ghost_letter_combo.setToolTip("Scegli una minuscola o una maiuscola da usare come riferimento sul foglio.")
        self.ghost_letter_combo.currentTextChanged.connect(self.change_ghost_letter)
        side.addWidget(self.ghost_letter_combo)

        ductus_row = QHBoxLayout()
        self.sheet_ductus_play = QPushButton("▶  Anima sul foglio")
        self.sheet_ductus_play.clicked.connect(lambda: self.canvas.start_ductus_animation())
        self.sheet_ductus_stop = QPushButton("■  Ferma")
        self.sheet_ductus_stop.clicked.connect(lambda: self.canvas.stop_ductus_animation())
        self.sheet_ductus_restart = QPushButton("↺  Da capo")
        self.sheet_ductus_restart.clicked.connect(lambda: self.canvas.restart_ductus_animation())
        ductus_row.addWidget(self.sheet_ductus_play)
        ductus_row.addWidget(self.sheet_ductus_stop)
        ductus_row.addWidget(self.sheet_ductus_restart)
        side.addLayout(ductus_row)

        speed_label = QLabel("VELOCITÀ DEL DUCTUS · 1×")
        side.addWidget(speed_label)
        self.sheet_ductus_speed = QSlider(Qt.Orientation.Horizontal)
        self.sheet_ductus_speed.setRange(3, 30)
        self.sheet_ductus_speed.setValue(10)
        def update_ductus_speed(value):
            self.canvas.set_ductus_speed(value)
            speed_label.setText(f"VELOCITÀ DEL DUCTUS · {value / 10:.1f}×")
        self.sheet_ductus_speed.valueChanged.connect(update_ductus_speed)
        side.addWidget(self.sheet_ductus_speed)

        self.sheet_ductus_loop = QCheckBox("Ripeti continuamente")
        self.sheet_ductus_loop.toggled.connect(lambda checked: self.canvas.set_ductus_loop(checked))
        side.addWidget(self.sheet_ductus_loop)
        ductus_hint = QLabel("Anima la costruzione della lettera selezionata direttamente sul foglio. Puoi rallentare, accelerare o ripetere il gesto.")
        ductus_hint.setWordWrap(True)
        ductus_hint.setObjectName("hint")
        side.addWidget(ductus_hint)

        side.addWidget(QLabel("OPACITÀ"))

        self.opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.opacity_slider.setRange(10, 100)
        self.opacity_slider.setValue(100)
        self.opacity_slider.valueChanged.connect(self.change_opacity)
        side.addWidget(self.opacity_slider)

        self.color_button = QPushButton("Scegli inchiostro")
        self.color_button.clicked.connect(self.choose_color)
        side.addWidget(self.color_button)

        self.guides_check = QCheckBox("Mostra righe guida")
        self.guides_check.setChecked(True)
        self.guides_check.toggled.connect(self.toggle_guides)
        side.addWidget(self.guides_check)

        side.addSpacing(12)
        side.addWidget(QLabel("STRUMENTI"))

        ductus_button = QPushButton("✒  Impara a costruire le lettere")
        ductus_button.clicked.connect(self.open_ductus)
        side.addWidget(ductus_button)

        recognize_button = QPushButton("🔍  Riconosci lo stile del mio disegno")
        recognize_button.clicked.connect(self.recognize_style)
        side.addWidget(recognize_button)

        regularity_button = QPushButton("📏  Analizza la regolarità")
        regularity_button.clicked.connect(self.analyze_regularity)
        side.addWidget(regularity_button)

        undo_button = QPushButton("↶  Annulla ultimo tratto")
        undo_button.clicked.connect(self.undo)
        side.addWidget(undo_button)

        clear_button = QPushButton("Pulisci foglio")
        clear_button.clicked.connect(self.clear_canvas)
        side.addWidget(clear_button)

        side.addWidget(QLabel("TESTO SULLA PERGAMENA"))
        self.text_input = QLineEdit()
        self.text_input.setPlaceholderText("Scrivi qui la tua frase…")
        self.text_input.setClearButtonEnabled(True)
        self.text_input.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        side.addWidget(self.text_input)

        self.text_font = QFontComboBox()
        self.text_font.setCurrentFont(QFont("DejaVu Serif"))
        self.text_font.setToolTip("Scegli il carattere per il testo")
        side.addWidget(self.text_font)

        self.text_size = QSpinBox()
        self.text_size.setRange(8, 160)
        self.text_size.setValue(36)
        self.text_size.setPrefix("Dimensione: ")
        side.addWidget(self.text_size)

        text_button = QPushButton("Posiziona testo sulla pergamena")
        text_button.clicked.connect(self.add_calligraphic_text)
        side.addWidget(text_button)

        self.type_on_paper_button = QPushButton("⌨  Attiva scrittura sul foglio")
        self.type_on_paper_button.setObjectName("primaryButton")
        self.type_on_paper_button.clicked.connect(self.enable_keyboard_writing)
        side.addWidget(self.type_on_paper_button)

        keyboard_hint = QLabel("Attiva, clicca sulla pergamena e digita. Invio conferma · Esc annulla.")
        keyboard_hint.setWordWrap(True)
        keyboard_hint.setObjectName("hint")
        side.addWidget(keyboard_hint)

        png_button = QPushButton("Esporta come PNG")
        png_button.clicked.connect(self.export_png)
        side.addWidget(png_button)

        save_button = QPushButton("Salva progetto")
        save_button.clicked.connect(self.save_project)
        side.addWidget(save_button)

        open_button = QPushButton("Apri progetto")
        open_button.clicked.connect(self.open_project)
        side.addWidget(open_button)

        side.addStretch()

        note = QLabel(
            "Consiglio: prova movimenti lenti e continui. "
            "Con una tavoletta compatibile puoi usare anche la pressione."
        )
        note.setWordWrap(True)
        side.addWidget(note)

        sidebar_scroll = QScrollArea()
        sidebar_scroll.setWidgetResizable(True)
        sidebar_scroll.setFrameShape(QFrame.Shape.NoFrame)
        sidebar_scroll.setFixedWidth(292)
        sidebar_scroll.setWidget(sidebar)
        root.addWidget(sidebar_scroll)

        # Area del foglio
        workspace = QVBoxLayout()
        workspace.setSpacing(8)

        toolbar = QHBoxLayout()
        toolbar.addWidget(QLabel("FOGLIO DI PERGAMENA"))
        toolbar.addStretch()

        self.status = QLabel("Pronto: disegna o inserisci testo")
        toolbar.addWidget(self.status)
        workspace.addLayout(toolbar)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        self.canvas = CalligraphyCanvas()
        self.change_gesture_preset(GESTO_PREDEFINITO)
        scroll.setWidget(self.canvas)
        workspace.addWidget(scroll, 1)

        root.addLayout(workspace, 1)

        impostazioni = carica_impostazioni() if carica_impostazioni else {}
        tema = impostazioni.get("tema", TEMA_PREDEFINITO)
        self.apply_theme(tema if tema in TEMI else TEMA_PREDEFINITO, salva=False)
        preset = impostazioni.get("gesto")
        if preset in PRESET_GESTO:
            self.change_gesture_preset(preset)
        self._ui_pronta = True

        undo_action = QAction("Annulla", self)
        undo_action.setShortcut("Ctrl+Z")
        undo_action.triggered.connect(self.undo)
        self.addAction(undo_action)

        clear_action = QAction("Pulisci", self)
        clear_action.setShortcut("Ctrl+L")
        clear_action.triggered.connect(self.clear_canvas)
        self.addAction(clear_action)

        save_action = QAction("Salva progetto", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_project)
        self.addAction(save_action)

        open_action = QAction("Apri progetto", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_project)
        self.addAction(open_action)

        # Allinea il carattere iniziale allo stile selezionato.
        self.update_description(self.style_combo.currentText())

    def open_history_library(self):
        """Apre le schede storiche incluse nel modulo biblioteca_stili.py."""
        dialog = QDialog(self)
        dialog.setWindowTitle("Biblioteca storica della calligrafia")
        dialog.resize(900, 620)
        layout = QVBoxLayout(dialog)

        intro = QLabel(
            "Esplora le tradizioni calligrafiche. Le descrizioni sono sintesi "
            "didattiche; i font moderni suggeriti non equivalgono a ricostruzioni storiche."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Tradizione:"))
        category = QComboBox()
        category.addItem("Tutte")
        category.addItems(tradizioni_disponibili())
        filter_row.addWidget(category)
        filter_row.addWidget(QLabel("Cerca:"))
        search = QLineEdit()
        search.setPlaceholderText("Nome, periodo, area o caratteristica…")
        filter_row.addWidget(search, 1)
        filter_row.addWidget(QLabel("Livello:"))
        level = QComboBox()
        level.addItems(["Principiante", "Intermedio", "Avanzato"])
        filter_row.addWidget(level)
        layout.addLayout(filter_row)

        body = QHBoxLayout()
        entries = QListWidget()
        entries.setMinimumWidth(245)
        details = QTextBrowser()
        details.setOpenExternalLinks(True)
        body.addWidget(entries, 1)
        body.addWidget(details, 2)
        layout.addLayout(body, 1)

        close_row = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close_row.rejected.connect(dialog.reject)
        close_row.accepted.connect(dialog.accept)
        close_row.button(QDialogButtonBox.StandardButton.Close).clicked.connect(dialog.accept)
        layout.addWidget(close_row)

        def refresh_list(*_):
            entries.clear()
            tradition = category.currentText()
            if tradition == "Tutte":
                tradition = None
            for card in cerca_stili(search.text(), tradition):
                from PySide6.QtWidgets import QListWidgetItem
                item = QListWidgetItem(f"{card['nome']}  ·  {card['tradizione']}")
                item.setData(Qt.ItemDataRole.UserRole, card["id"])
                entries.addItem(item)
            if entries.count():
                entries.setCurrentRow(0)
            else:
                details.setHtml("<h3>Nessuna scheda trovata</h3><p>Prova un'altra ricerca.</p>")

        def show_card(item):
            if item is None:
                return
            card_id = item.data(Qt.ItemDataRole.UserRole)
            card = next((x for x in BIBLIOTECA_STILI if x["id"] == card_id), None)
            if not card:
                details.setHtml(
                    "<h3>Biblioteca non caricata</h3><p>Metti biblioteca_stili.py nella stessa cartella di main.py e riavvia l'app.</p>"
                )
                return
            esc = lambda value: html.escape(str(value))
            characteristics = "".join(f"<li>{esc(v)}</li>" for v in card.get("caratteristiche", []))
            fonts = ", ".join(card.get("font_digitali", [])) or "Nessun font consigliato nel catalogo: meglio consultare esempi storici."
            sources = "".join(
                f'<li><a href="{esc(source["url"])}">{esc(source["titolo"])}</a></li>'
                for source in card.get("fonti", [])
            )
            guida = guida_tecnica(card)
            tecnica_html = "<h3>Laboratorio del gesto: ductus e tecnica</h3>" + "".join(
                f"<h4>{titolo}</h4><p>{esc(testo)}</p>"
                for titolo, testo in [("Ductus e ordine dei tratti", guida["ductus"]), ("Calamo, pennino o pennello", guida["strumento"]), ("Angolo e pressione", guida["angolo_pressione"]), ("Proporzioni e griglia", guida["proporzioni"]), ("Esercizio consigliato", guida["esercizio"])]
            ) + "<p><i>Nota didattica: queste indicazioni introducono la tecnica dello stile. La sequenza esatta di ogni lettera o carattere richiede un modello specifico e verificato.</i></p>"
            passi = passi_esercizio(card)
            livello = level.currentText()
            if livello == "Principiante":
                obiettivo = "Riconoscere lo strumento, preparare le guide e controllare i tratti fondamentali senza cercare subito la velocità."
                compito = "Completa una riga di esercizi lenti; ripeti ogni forma tre volte e annota la più regolare."
                criteri = ["orientamento dello strumento", "allineamento sulla linea di base", "regolarità e controllo del gesto"]
                passi_selezionati = passi[:3]
            elif livello == "Intermedio":
                obiettivo = "Collegare i tratti in lettere e sequenze, mantenendo costanti proporzioni, ritmo e spaziatura."
                compito = "Scrivi una breve sequenza di lettere o caratteri modello; ripetila variando una sola impostazione per volta."
                criteri = ["proporzioni e inclinazione", "spazi interni e distanza tra forme", "continuità tra i tratti"]
                passi_selezionati = passi[1:]
            else:
                obiettivo = "Studiare varianti storiche, ritmo compositivo e qualità espressiva confrontando esemplari della stessa scuola."
                compito = "Realizza una breve parola o composizione, poi confrontala con una fonte storica identificata e descrivi le differenze."
                criteri = ["fedeltà al modello e alla sua variante", "ritmo, contrasto e coerenza", "qualità delle legature o delle connessioni"]
                passi_selezionati = passi
            percorso_html = (
                f"<h3>Percorso didattico · {esc(livello)}</h3>"
                f"<p><b>Obiettivo:</b> {esc(obiettivo)}</p><ol>"
                + "".join(f"<li>{esc(passo)}</li>" for passo in passi_selezionati)
                + f"</ol><p><b>Compito:</b> {esc(compito)}</p><p><b>Autovalutazione:</b> {', '.join(esc(x) for x in criteri)}.</p>"
                + "<p><i>La progressione è didattica; il ductus puntuale va verificato su un modello della specifica scuola, epoca e variante.</i></p>"
            )
            details.setHtml(f"""
                <h2>{esc(card['nome'])}</h2>
                <p><b>Tradizione:</b> {esc(card['tradizione'])}<br>
                <b>Periodo:</b> {esc(card['periodo'])}<br>
                <b>Area:</b> {esc(card['area'])}</p>
                <h3>Contesto storico</h3><p>{esc(card['descrizione'])}</p>
                <h3>Caratteristiche</h3><ul>{characteristics}</ul>
                <h3>Strumenti</h3><p>{esc(card['strumenti'])}</p>
                {tecnica_html}
                {percorso_html}
                <h3>Font digitali suggeriti</h3><p>{esc(fonts)}</p>
                <p><i>{esc(card.get('nota_font', ''))}</i></p>
                <h3>Fonti e approfondimenti</h3><ul>{sources}</ul>
            """)

        category.currentTextChanged.connect(refresh_list)
        search.textChanged.connect(refresh_list)
        entries.currentItemChanged.connect(lambda current, previous: show_card(current))
        level.currentTextChanged.connect(lambda _value: show_card(entries.currentItem()))
        refresh_list()
        dialog.exec()

    def enable_keyboard_writing(self):
        self.canvas.start_typing(
            self.text_font.currentFont().family(),
            self.text_size.value()
        )
        self.status.setText("Scrittura attiva: clicca sul foglio e digita · Invio conferma · Esc annulla")
        self.canvas.setFocus(Qt.FocusReason.OtherFocusReason)

    def add_calligraphic_text(self):
        # Il campo di testo resta visibile nella finestra principale,
        # così è chiaro dove digitare con la tastiera.
        phrase = self.text_input.text().strip()
        if not phrase:
            self.status.setText("Scrivi prima una frase nel campo Testo")
            self.text_input.setFocus(Qt.FocusReason.OtherFocusReason)
            return

        self.canvas.typing_mode = False
        self.canvas.typing_text = ""
        self.canvas.arm_text_placement(
            phrase,
            self.text_font.currentFont().family(),
            self.text_size.value(),
            self.canvas.ink
        )
        self.status.setText("Ora fai clic sulla pergamena per posizionare il testo")
        self.canvas.setFocus(Qt.FocusReason.OtherFocusReason)

    def apply_style_grades(self, style):
        """Imposta i gradi calligrafici (angolo del pennino, inclinazione, guide) secondo lo stile scelto.

        I valori vengono dall'archivio dell'utente (dati_stili/*_ductus.json) e, dove manca,
        da stime modificabili. Un parametro non applicabile a quello stile resta com'è.
        """
        if gradi_per_nome is None or self._applicando_progetto or not hasattr(self, "canvas"):
            return
        g = gradi_per_nome(style)
        if g:
            if g["angolo"] is not None:
                self.sheet_nib_angle.blockSignals(True)
                self.sheet_nib_angle.setValue(int(round(g["angolo"])))
                self.sheet_nib_angle.blockSignals(False)
                self.canvas.nib_angle_degrees = float(g["angolo"])
            if g["inclinazione"] is not None:
                self.slant_spin.blockSignals(True)
                self.slant_spin.setValue(float(g["inclinazione"]))
                self.slant_spin.blockSignals(False)
                self.canvas.slant_degrees = float(g["inclinazione"])
            if g["corpo"] is not None:
                self.canvas.guide_nibs = float(g["corpo"])
                n = f"{g['corpo']:g}"
                self.canc_guides_check.setText(f"Guide dello stile ({n} + {n} + {n})")
                self.guide_info.setText(f"Corpo, ascendenti e discendenti: {n} larghezze di pennino ciascuno. " + descrizione_gradi(g))
            else:
                self.guide_info.setText("Guide invariate. " + descrizione_gradi(g))
            self.canvas.update()
            self.status.setText(f"{style}: " + descrizione_gradi(g).split(". «stima»")[0])
        else:
            self.guide_info.setText(descrizione_gradi(None))

    def update_description(self, style):
        self.apply_style_grades(style)
        description = STYLES.get(style, "")
        # QFontDatabase contiene le famiglie realmente disponibili sul sistema.
        installed = {family.casefold(): family for family in QFontDatabase.families()}
        selected = None
        for candidate in STYLE_FONT_CANDIDATES.get(style, []):
            if candidate.casefold() in installed:
                selected = installed[candidate.casefold()]
                break

        if selected:
            self.text_font.setCurrentFont(QFont(selected))
            self.description.setText(description + "\nCarattere selezionato: " + selected)
        else:
            # DejaVu Serif è presente normalmente su Linux; l'italico è un ripiego,
            # non una simulazione perfetta della calligrafia storica.
            fallback = installed.get("dejavu serif", "DejaVu Serif")
            self.text_font.setCurrentFont(QFont(fallback))
            self.description.setText(
                description + "\nNessun font dedicato installato: uso " + fallback + " corsivo. "
                "Installa un font adatto per una resa più autentica."
            )

    def recognize_style(self):
        """Analizza i tratti disegnati sul foglio e stima lo stile calligrafico."""
        if riconosci_stile is None:
            QMessageBox.warning(self, "Riconoscimento non disponibile", "Manca il modulo riconoscimento_stile.py.")
            return
        strokes = [s["points"] for s in self.canvas.strokes if len(s.get("points", [])) > 1]
        dialog = QDialog(self)
        dialog.setWindowTitle("Riconoscimento dello stile")
        dialog.resize(640, 520)
        layout = QVBoxLayout(dialog)
        row = QHBoxLayout()
        row.addWidget(QLabel("Alfabeto del disegno:"))
        family = QComboBox()
        family.addItems(["Automatico", "Latino", "Arabo / persiano", "Asia orientale"])
        row.addWidget(family, 1)
        layout.addLayout(row)
        browser = QTextBrowser()
        layout.addWidget(browser, 1)
        apply_button = QPushButton("Imposta lo stile suggerito sul foglio")
        layout.addWidget(apply_button)
        close = QPushButton("Chiudi"); close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        state = {"key": None}

        def run(_index=None):
            forced = [None, "latino", "arabo", "cjk"][family.currentIndex()]
            result = riconosci_stile(strokes, famiglia=forced)
            browser.setHtml(formatta_risultato_html(result))
            state["key"] = None
            if result.get("ok"):
                top_id = result["stili"][0]["id"]
                for key in STYLES:
                    if id_da_nome(key) == top_id:
                        state["key"] = key; break
            apply_button.setEnabled(state["key"] is not None)

        def apply_style():
            if state["key"]:
                self.style_combo.setCurrentText(state["key"])
                dialog.accept()

        family.currentIndexChanged.connect(run)
        apply_button.clicked.connect(apply_style)
        run()
        dialog.exec()

    def open_ductus(self):
        DuctusDialog(self).exec()

    def change_nib_width(self, text):
        value = float(text.replace(" mm", "").replace(",", "."))
        self.canvas.nib_width_mm = value
        self.canvas.base_width = max(1, round(value * 3.78))
        self.width_slider.setValue(self.canvas.base_width)
        self.guide_info.setText(
            f"Pennino {value:g} mm · corpo 5× = {value*5:g} mm · "
            f"ascendente 5× = {value*5:g} mm · discendente 5× = {value*5:g} mm."
        )
        self.canvas.update()

    def apply_theme(self, name, salva=True):
        """Applica un tema all'interfaccia e al colore del foglio; la scelta viene salvata."""
        if foglio_stile is None or name not in TEMI:
            return
        self.setStyleSheet(foglio_stile(name))
        if hasattr(self, "canvas"):
            self.canvas.paper = QColor(TEMI[name]["carta"])
            self.canvas.update()
        self.tema_corrente = name
        self.theme_combo.blockSignals(True)
        self.theme_combo.setCurrentText(name)
        self.theme_combo.blockSignals(False)
        if hasattr(self, "status"):
            self.status.setText(f"Tema: {name}")
        if salva:
            self._salva_impostazioni()

    def _salva_impostazioni(self):
        if salva_impostazioni is None or not getattr(self, "_ui_pronta", False):
            return
        gesto = getattr(self.canvas, "gesto", None)
        salva_impostazioni({"tema": getattr(self, "tema_corrente", TEMA_PREDEFINITO),
                            "gesto": gesto.preset if gesto is not None else ""})

    def analyze_regularity(self):
        """Misura la regolarità di inclinazione, altezza, spaziatura e riga di base dei tratti disegnati."""
        if analizza_regolarita is None:
            QMessageBox.warning(self, "Analisi non disponibile", "Manca il modulo coerenza_scrittura.py.")
            return
        strokes = [s["points"] for s in self.canvas.strokes if len(s.get("points", [])) > 1]
        dialog = QDialog(self)
        dialog.setWindowTitle("Regolarità della scrittura")
        dialog.resize(560, 460)
        layout = QVBoxLayout(dialog)
        browser = QTextBrowser()
        browser.setHtml(formatta_regolarita_html(analizza_regolarita(strokes)))
        layout.addWidget(browser, 1)
        close = QPushButton("Chiudi"); close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        dialog.exec()

    def sync_grades_from_canvas(self):
        """Allinea i controlli dei gradi ai valori del foglio (dopo l'apertura di un progetto)."""
        for widget, valore in ((self.sheet_nib_angle, int(round(self.canvas.nib_angle_degrees))),
                               (self.slant_spin, float(self.canvas.slant_degrees))):
            widget.blockSignals(True)
            widget.setValue(valore)
            widget.blockSignals(False)
        n = f"{self.canvas.guide_nibs:g}"
        self.canc_guides_check.blockSignals(True)
        self.canc_guides_check.setChecked(bool(self.canvas.cancelleresca_guides))
        self.canc_guides_check.blockSignals(False)
        self.canc_guides_check.setText(f"Guide dello stile ({n} + {n} + {n})")
        self.guide_info.setText(f"Corpo, ascendenti e discendenti: {n} larghezze di pennino ciascuno (valori del progetto).")

    def change_gesture_preset(self, name):
        gesto = getattr(self.canvas, "gesto", None) if hasattr(self, "canvas") else None
        if gesto is None or not name:
            return
        gesto.applica_preset(name)
        self.gesture_combo.blockSignals(True)
        self.gesture_combo.setCurrentText(name)
        self.gesture_combo.blockSignals(False)
        self.gesture_slider.blockSignals(True)
        self.gesture_slider.setValue(gesto.stab)
        self.gesture_slider.blockSignals(False)
        self.gesture_slider.setEnabled(gesto.modo != "nessuno")
        self._update_gesture_label()
        if hasattr(self, "status"):
            self.status.setText(f"Gesto del mouse: {name}")
        self._salva_impostazioni()

    def change_stabilizer(self, value):
        gesto = getattr(self.canvas, "gesto", None) if hasattr(self, "canvas") else None
        if gesto is None:
            return
        gesto.configura(stab=value)
        self._update_gesture_label()

    def _update_gesture_label(self):
        gesto = self.canvas.gesto
        if gesto.modo == "nessuno":
            self.gesture_label.setText("Nessuna correzione: il tratto segue il mouse così com'è.")
        else:
            self.gesture_label.setText(f"Stabilizzatore {gesto.stab}% · modo {gesto.modo} · pressione da {gesto.pressione}")

    def change_sheet_nib_angle(self, value):
        self.canvas.nib_angle_degrees = float(value)
        self.status.setText(f"Pennino tronco sul foglio: taglio a {value}°")

    def change_sheet_pressure(self, value):
        self.canvas.nib_pressure_scale = value / 100.0
        self.sheet_pressure_label.setText(f"{value}% · pressione simulata con il mouse")
        self.status.setText("Pressione del pennino aggiornata per i nuovi tratti")

    def change_slant(self, value):
        self.canvas.slant_degrees = float(value)
        self.canvas.update()
        self.status.setText(f"Inclinazione delle aste: {value:g}° rispetto alla verticale")

    def toggle_cancelleresca_guides(self, enabled):
        self.canvas.cancelleresca_guides = enabled
        if enabled:
            n = f"{self.canvas.guide_nibs:g}"
            self.status.setText(f"Guide dello stile attive: corpo, ascendenti e discendenti di {n} larghezze di pennino")
        self.canvas.update()

    def toggle_nib_cursor(self, enabled):
        self.canvas.show_nib_cursor = bool(enabled)
        self.canvas.update()

    def toggle_letter_ghost(self, enabled):
        self.canvas.show_letter_ghost = bool(enabled)
        self.canvas.update()
        self.status.setText("Modello lettera sul foglio attivo" if enabled else "Modello lettera nascosto")

    def change_ghost_letter(self, letter):
        self.canvas.ghost_letter = letter
        self.canvas.ductus_animation_progress = 0.0
        self.canvas.stop_ductus_animation()
        self.canvas.update()

    def change_width(self, value):
        self.canvas.base_width = value

    def change_opacity(self, value):
        self.canvas.ink_opacity = value

    def toggle_guides(self, checked):
        self.canvas.show_guides = checked
        self.canvas.update()

    def choose_color(self):
        color = QColorDialog.getColor(self.canvas.ink, self, "Scegli il colore")
        if color.isValid():
            self.canvas.ink = color
            self.color_button.setStyleSheet(
                "background-color: " + color.name() + ";"
            )

    def undo(self):
        self.canvas.undo()
        self.status.setText("Ultimo tratto annullato")

    def clear_canvas(self):
        answer = QMessageBox.question(
            self,
            "Pulisci il foglio",
            "Vuoi cancellare tutti i tratti dal foglio?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.canvas.clear_canvas()
            self.status.setText("Foglio pulito")

    def export_png(self):
        filename, _ = QFileDialog.getSaveFileName(
            self, "Esporta immagine", "calligrafia.png",
            "Immagini PNG (*.png)"
        )
        if not filename:
            return
        if not filename.lower().endswith(".png"):
            filename += ".png"

        try:
            self.canvas.export_png(filename)
            self.status.setText("Immagine esportata")
        except Exception as error:
            QMessageBox.critical(self, "Errore esportazione", str(error))

    def save_project(self):
        filename, _ = QFileDialog.getSaveFileName(
            self, "Salva progetto", "progetto.cstudio",
            "Progetti Calligrafia Studio (*.cstudio)"
        )
        if not filename:
            return
        if not filename.lower().endswith(".cstudio"):
            filename += ".cstudio"

        try:
            self.canvas.save_project(
                filename, self.style_combo.currentText()
            )
            self.status.setText("Progetto salvato")
        except Exception as error:
            QMessageBox.critical(self, "Errore salvataggio", str(error))

    def open_project(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Apri progetto", "",
            "Progetti Calligrafia Studio (*.cstudio)"
        )
        if not filename:
            return

        try:
            style = self.canvas.load_project(filename)
            self._applicando_progetto = True          # i gradi salvati nel progetto non vanno sostituiti da quelli dello stile
            try:
                index = self.style_combo.findText(style)
                if index >= 0:
                    self.style_combo.setCurrentIndex(index)
            finally:
                self._applicando_progetto = False
            if self.canvas.progetto_con_gradi:
                self.sync_grades_from_canvas()
            else:
                self.apply_style_grades(self.style_combo.currentText())     # vecchio progetto: valgono i gradi dello stile

            self.width_slider.setValue(self.canvas.base_width)
            self.opacity_slider.setValue(self.canvas.ink_opacity)
            self.guides_check.setChecked(self.canvas.show_guides)
            self.color_button.setStyleSheet(
                "background-color: " + self.canvas.ink.name() + ";"
            )
            self.status.setText("Progetto aperto")
        except Exception as error:
            QMessageBox.critical(self, "Errore apertura progetto", str(error))


def main():
    app = QApplication(sys.argv)
    app.setWindowIcon(icona_applicazione())
    app.setApplicationName("Calligrafia Studio")

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
