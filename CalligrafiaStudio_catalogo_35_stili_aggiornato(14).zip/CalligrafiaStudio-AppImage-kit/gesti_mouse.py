"""Emulazione dei gesti del mouse in stile Krita, senza dipendenze da Qt.

Con un mouse la pressione non esiste e la mano trema: qui si ricostruiscono, a partire
dai soli movimenti, le tecniche che i programmi di pittura usano per dare al mouse un
tratto più naturale.

Tecniche
--------
* Stabilizzatore (tre modi, come in Krita):
    - "dinamico": il pennino è una massa trascinata dal cursore con una molla e un attrito;
      i tratti diventano fluidi e le curve si arrotondano.
    - "corda": il pennino segue il cursore solo quando questo si allontana oltre un raggio
      (come una corda): ottimo per linee pulite.
    - "peso": media pesata degli ultimi punti.
* Pressione simulata:
    - "velocita": lento = pieno, veloce = sottile (sensore «velocità» di Krita).
    - "direzione": pieno in discesa, sottile in salita (punta flessibile da corsivo).
    - "costante".
* Fade: il tratto parte leggero (fade-in) e si assottiglia alla fine (coda), come una penna
  che entra e esce dal foglio.
* Rifinitura al rilascio: un passaggio di arrotondamento che elimina gli ultimi scatti
  senza spianare gli angoli netti.
* Linea retta (Shift) e scatto di angolo (Shift+Ctrl), come in Krita.

I valori dei preset sono scelti a mano: vanno ritoccati con lo slider in base alla
risoluzione dello schermo e alla propria velocità.
"""
import math
import time

PRESET = {
    "Naturale (stile Krita)": dict(stab=35, modo="dinamico", pressione="velocita", fade_in=14, coda=26, rifinisci=True),
    "Calligrafia stabile": dict(stab=55, modo="corda", pressione="velocita", fade_in=10, coda=22, rifinisci=True),
    "Punta flessibile (corsivo)": dict(stab=30, modo="dinamico", pressione="direzione", fade_in=8, coda=30, rifinisci=True),
    "Libero (nessuna correzione)": dict(stab=0, modo="nessuno", pressione="costante", fade_in=0, coda=0, rifinisci=False),
}
PRESET_PREDEFINITO = "Naturale (stile Krita)"

PRESSIONE_MIN = 0.35
VELOCITA_RIF = 1.4          # px/ms oltre la quale il tratto è al minimo (velocità)


def _smoothstep(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


def _chaikin(punti):
    """Un passaggio di Chaikin su (x, y, p); gli angoli molto netti restano."""
    if len(punti) < 4:
        return punti
    out = [punti[0]]
    for i in range(len(punti) - 1):
        a, b = punti[i], punti[i + 1]
        if 0 < i < len(punti) - 1:
            # non arrotondare i vertici con svolta > 100°
            p0, p1, p2 = punti[i - 1], punti[i], punti[i + 1]
            v1 = (p1[0] - p0[0], p1[1] - p0[1]); v2 = (p2[0] - p1[0], p2[1] - p1[1])
            n1 = math.hypot(*v1); n2 = math.hypot(*v2)
            if n1 > 0 and n2 > 0:
                cosang = (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)
                if cosang < math.cos(math.radians(100)):
                    out.append(a); out.append(b); continue
        out.append(tuple(0.75 * a[k] + 0.25 * b[k] for k in range(3)))
        out.append(tuple(0.25 * a[k] + 0.75 * b[k] for k in range(3)))
    out.append(punti[-1])
    return out


def linea_retta(p0, p1, passo=5.0, pressione=1.0, scatto_gradi=None):
    """Punti (x, y, p) di una linea retta; con scatto_gradi l'angolo si arrotonda a quel passo."""
    (x0, y0), (x1, y1) = p0, p1
    if scatto_gradi:
        d = math.hypot(x1 - x0, y1 - y0)
        ang = round(math.degrees(math.atan2(y1 - y0, x1 - x0)) / scatto_gradi) * scatto_gradi
        x1 = x0 + d * math.cos(math.radians(ang)); y1 = y0 + d * math.sin(math.radians(ang))
    d = math.hypot(x1 - x0, y1 - y0)
    n = max(1, int(d / passo))
    return [(x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, pressione) for i in range(n + 1)]


class GestoMouse:
    def __init__(self, preset=PRESET_PREDEFINITO):
        self.preset = PRESET_PREDEFINITO
        self.stab = 0
        self.modo = "nessuno"
        self.pressione = "costante"
        self.fade_in = 0.0
        self.coda = 0.0
        self.rifinisci = False
        self.applica_preset(preset)
        self._reset()

    # ------------------------------------------------------------------ configurazione
    def applica_preset(self, nome):
        cfg = PRESET.get(nome)
        if cfg is None:
            return False
        self.preset = nome
        self.configura(**cfg)
        return True

    def configura(self, stab=None, modo=None, pressione=None, fade_in=None, coda=None, rifinisci=None):
        if stab is not None: self.stab = max(0, min(100, int(stab)))
        if modo is not None: self.modo = modo
        if pressione is not None: self.pressione = pressione
        if fade_in is not None: self.fade_in = float(fade_in)
        if coda is not None: self.coda = float(coda)
        if rifinisci is not None: self.rifinisci = bool(rifinisci)

    @property
    def attivo(self):
        return not (self.modo == "nessuno" and self.pressione == "costante" and not self.rifinisci and self.fade_in <= 0 and self.coda <= 0)

    # ------------------------------------------------------------------ stato
    def _reset(self):
        self.b = (0.0, 0.0)       # posizione del pennino
        self.c = (0.0, 0.0)       # ultima posizione del cursore
        self.v = (0.0, 0.0)       # velocità del pennino (modo dinamico)
        self.t_prec = None
        self.out = (0.0, 0.0)     # ultimo punto emesso
        self.p_filtrata = 0.6
        self.percorso = 0.0
        self.recenti = []

    @staticmethod
    def _tempo(t):
        return float(t) if t is not None else time.monotonic() * 1000.0

    # ------------------------------------------------------------------ eventi
    def inizia(self, x, y, t=None, pressione=None):
        self._reset()
        self.b = self.c = self.out = (float(x), float(y))
        self.t_prec = self._tempo(t)
        self.recenti = [(float(x), float(y))]
        if pressione is not None:
            return (float(x), float(y), float(pressione))
        p0 = PRESSIONE_MIN + (1 - PRESSIONE_MIN) * _smoothstep(0.0) if self.fade_in > 0 else 0.7
        self.p_filtrata = p0
        return (float(x), float(y), p0)

    def _muovi_pennino(self, dt_ms, n_sub):
        """Aggiorna la posizione del pennino secondo il modo scelto; restituisce i punti candidati."""
        cx, cy = self.c
        bx, by = self.b
        candidati = []
        s = self.stab / 100.0
        if self.modo == "corda":
            raggio = 2.0 + 38.0 * s
            dx, dy = bx - cx, by - cy
            d = math.hypot(dx, dy)
            if d > raggio:
                bx, by = cx + dx / d * raggio, cy + dy / d * raggio
            candidati.append((bx, by))
        elif self.modo == "dinamico":
            m = 1.0 + 5.0 * s          # massa
            k = 1.0                     # molla
            smorz = 2.0 * math.sqrt(k * m) * 0.85
            vx, vy = self.v
            h = dt_ms / n_sub / 16.0    # passo normalizzato a ~60 Hz
            for _ in range(n_sub):
                ax = (k * (cx - bx) - smorz * vx) / m
                ay = (k * (cy - by) - smorz * vy) / m
                vx += ax * h; vy += ay * h
                bx += vx * h; by += vy * h
                candidati.append((bx, by))
            self.v = (vx, vy)
        elif self.modo == "peso":
            self.recenti.append((cx, cy))
            n = 2 + int(s * 10)
            self.recenti = self.recenti[-n:]
            tot = sum(range(1, len(self.recenti) + 1))
            bx = sum(p[0] * (i + 1) for i, p in enumerate(self.recenti)) / tot
            by = sum(p[1] * (i + 1) for i, p in enumerate(self.recenti)) / tot
            candidati.append((bx, by))
        else:
            bx, by = cx, cy
            candidati.append((bx, by))
        self.b = (bx, by)
        return candidati

    def _pressione_da_moto(self, da, a, dt_ms):
        dx, dy = a[0] - da[0], a[1] - da[1]
        d = math.hypot(dx, dy)
        if d == 0:
            return self.p_filtrata
        if self.pressione == "velocita":
            v = d / max(dt_ms, 1.0)
            f = min(1.0, (v / VELOCITA_RIF) ** 0.7)
            target = 1.0 - (1.0 - PRESSIONE_MIN) * f
        elif self.pressione == "direzione":
            discesa = max(0.0, dy / d)
            target = PRESSIONE_MIN + (1.0 - PRESSIONE_MIN) * discesa ** 1.3
        else:
            target = 1.0
        self.p_filtrata += (target - self.p_filtrata) * 0.35      # filtro passa-basso
        return self.p_filtrata

    def muovi(self, x, y, t=None, pressione=None):
        """Restituisce la lista (anche vuota) dei nuovi punti (x, y, p) da aggiungere al tratto."""
        if self.t_prec is None:
            return [self.inizia(x, y, t, pressione)]
        ora = self._tempo(t)
        dt = max(4.0, min(50.0, ora - self.t_prec))
        self.t_prec = ora
        self.c = (float(x), float(y))
        n_sub = max(1, int(dt / 8.0)) if self.modo == "dinamico" else 1
        nuovi = []
        for cand in self._muovi_pennino(dt, n_sub):
            d = math.hypot(cand[0] - self.out[0], cand[1] - self.out[1])
            if d < 1.0:                      # zona morta: ignora i micro-spostamenti
                continue
            if pressione is not None:
                p = float(pressione)
            else:
                p = self._pressione_da_moto(self.out, cand, dt / n_sub)
                if self.fade_in > 0:
                    p *= PRESSIONE_MIN + (1 - PRESSIONE_MIN) * _smoothstep((self.percorso + d) / self.fade_in)
            self.percorso += d
            self.out = cand
            nuovi.append((cand[0], cand[1], max(0.1, min(1.0, p))))
        return nuovi

    def termina(self, punti):
        """Chiude il tratto: raggiunge il cursore, assottiglia la coda e rifinisce la curva."""
        punti = list(punti)
        if len(punti) < 2:
            return punti
        reale = None  # (non usato: la coda si applica anche alle pressioni reali in modo leggero)
        # 1) il pennino raggiunge il cursore (solo modo dinamico)
        if self.modo == "dinamico":
            for _ in range(60):
                cand = self._muovi_pennino(16.0, 1)[0]
                if math.hypot(cand[0] - self.c[0], cand[1] - self.c[1]) < 0.8:
                    break
                if math.hypot(cand[0] - self.out[0], cand[1] - self.out[1]) >= 1.0:
                    p = self._pressione_da_moto(self.out, cand, 16.0) if self.pressione != "costante" else punti[-1][2]
                    self.out = cand
                    punti.append((cand[0], cand[1], max(0.1, min(1.0, p))))
        # 1b) modo corda: il tratto si chiude sul cursore con piccoli passi (niente salto finale)
        elif self.modo == "corda":
            d = math.hypot(self.c[0] - self.out[0], self.c[1] - self.out[1])
            n = int(d / 4.0)
            for i in range(1, n + 1):
                f = i / (n + 1)
                punti.append((self.out[0] + (self.c[0] - self.out[0]) * f,
                              self.out[1] + (self.c[1] - self.out[1]) * f, punti[-1][2]))
            if d >= 1.0:
                punti.append((self.c[0], self.c[1], punti[-1][2]))
            self.out = self.c
        # 2) coda: gli ultimi px si assottigliano
        if self.coda > 0:
            acc = 0.0
            for i in range(len(punti) - 1, 0, -1):
                acc += math.hypot(punti[i][0] - punti[i - 1][0], punti[i][1] - punti[i - 1][1])
                if acc > self.coda:
                    break
                f = PRESSIONE_MIN + (1 - PRESSIONE_MIN) * _smoothstep(acc / self.coda)
                x, y, p = punti[i - 1]
                punti[i - 1] = (x, y, max(0.1, p * f))
            x, y, p = punti[-1]
            punti[-1] = (x, y, max(0.1, p * PRESSIONE_MIN))
        # 3) rifinitura
        if self.rifinisci and len(punti) >= 4:
            lung = sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(punti, punti[1:]))
            if lung > 16:
                punti = _chaikin(punti)
        self.t_prec = None
        return punti
