"""Analisi della regolarità della scrittura a mano libera (senza dipendenze da Qt).

Misura quanto sono costanti, lungo la riga scritta, quattro cose che i maestri di
calligrafia controllano per prime: inclinazione delle aste, altezza delle lettere,
spaziatura e riga di base. Dà un punteggio da 0 a 100 per ciascuna e un consiglio.

LIMITI: lavora solo sulla geometria dei tratti (con il mouse manca la pressione, quindi
non giudica spessori e contrasto). Servono almeno 4 lettere separate: se le lettere
sono legate in un tratto unico le misure per lettera non sono affidabili. I punteggi sono
indicativi e le soglie scelte a mano, non tarate su campioni di allievi.
"""
import math
from statistics import median, pstdev, mean

from riconoscimento_stile import _pulisci, _raggruppa, _lunghezza, _bbox, _leviga, _ricampiona


def _cv(valori):
    m = mean(valori)
    return pstdev(valori) / m if m else 0.0


def _punteggio(x, zero_a):
    """100 se x = 0; scende linearmente fino a 0 quando x = zero_a."""
    return round(max(0.0, min(100.0, 100.0 * (1.0 - x / zero_a))))


def _inclinazione_gruppo(tratti, H):
    """Inclinazione (gradi dalla verticale, + = a destra) delle aste di un gruppo; None se non misurabile."""
    voci = []
    passo = max(2.5, H * 0.08)
    for t in tratti:
        r = _ricampiona(_leviga(t), passo)
        for a, b in zip(r, r[1:]):
            dx, dy = b[0] - a[0], b[1] - a[1]
            d = math.hypot(dx, dy)
            if d < 1e-6:
                continue
            if dy > 0:
                dx, dy = -dx, -dy
            theta = math.degrees(math.atan2(dx, -dy))
            if abs(theta) <= 60 and abs(dy) > 0.5 * d:
                voci.append((theta, d))
    tot = sum(w for _, w in voci)
    if tot < 0.6 * H:
        return None
    voci.sort()
    acc = 0.0
    for th, w in voci:
        acc += w
        if acc >= tot / 2:
            return th
    return None


def analizza_regolarita(strokes):
    tratti = _pulisci(strokes)
    if not tratti:
        return {"ok": False, "messaggio": "Non ci sono tratti da analizzare."}
    grandi = [t for t in tratti if _lunghezza(t) > 8]
    gruppi = _raggruppa(grandi)
    if len(gruppi) < 4:
        return {"ok": False, "messaggio": "Servono almeno 4 lettere separate (o una parola scritta a lettere staccate) per misurare la regolarità."}

    altezze = [g["y1"] - g["y0"] for g in gruppi]
    larghezze = [g["x1"] - g["x0"] for g in gruppi]
    H = median(altezze)
    # altezza: scarto relativo dalla mediana (robusto alle aste che sporgono)
    scarti_h = [abs(a - H) / H for a in altezze]
    cv_h = median(scarti_h) * 1.4826 if len(scarti_h) > 1 else 0.0       # MAD normalizzata
    # inclinazione per lettera
    inc = []
    for g in gruppi:
        t = [grandi[i] for i in g["idx"]]
        v = _inclinazione_gruppo(t, H)
        if v is not None:
            inc.append(v)
    dev_inc = pstdev(inc) if len(inc) >= 3 else None
    inc_media = mean(inc) if inc else None
    # spaziatura: spazi tra lettere consecutive (si escludono gli spazi tra parole)
    ordinati = sorted(gruppi, key=lambda g: g["x0"])
    spazi = [ordinati[i + 1]["x0"] - ordinati[i]["x1"] for i in range(len(ordinati) - 1)]
    lim_parola = 2.2 * median(larghezze)
    spazi_l = [s for s in spazi if s < lim_parola]
    cv_s = _cv([max(s, 1.0) for s in spazi_l]) if len(spazi_l) >= 3 else None
    # riga di base: parte bassa dei gruppi
    xs = [(g["x0"] + g["x1"]) / 2 for g in ordinati]
    ys = [g["y1"] for g in ordinati]
    mx, my = mean(xs), mean(ys)
    den = sum((x - mx) ** 2 for x in xs)
    pend = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den if den > 1e-6 else 0.0
    residui = [y - (my + pend * (x - mx)) for x, y in zip(xs, ys)]
    scarto_base = pstdev(residui) / H if H else 0.0
    inclinazione_riga = math.degrees(math.atan(pend))

    punti = {"altezza": _punteggio(cv_h, 0.30), "riga": _punteggio(scarto_base, 0.25)}
    punti["inclinazione"] = _punteggio(dev_inc, 12.0) if dev_inc is not None else None
    punti["spaziatura"] = _punteggio(cv_s, 0.9) if cv_s is not None else None
    validi = [v for v in punti.values() if v is not None]
    totale = round(sum(validi) / len(validi))

    consigli = []
    if punti["inclinazione"] is not None and punti["inclinazione"] < 70:
        consigli.append(f"Inclinazione irregolare (le aste variano di ±{dev_inc:.0f}°): traccia prima delle linee guida inclinate e fai passare ogni asta lungo una di esse.")
    if punti["altezza"] < 70:
        consigli.append("Altezza delle lettere variabile: scrivi tra due linee guida (riga di base e linea della x) e controlla che tutte le lettere le tocchino.")
    if punti["spaziatura"] is not None and punti["spaziatura"] < 70:
        consigli.append("Spazi tra le lettere disuguali: lo spazio dentro una «o» è un buon metro per lo spazio tra due aste.")
    if punti["riga"] < 70 or abs(inclinazione_riga) > 3:
        consigli.append(f"La riga di base ondeggia o è inclinata ({inclinazione_riga:+.1f}°): usa le linee guida e tieni l'avambraccio parallelo alla riga.")
    if not consigli:
        consigli.append("Scrittura regolare: ora puoi lavorare sul contrasto e sul ritmo.")

    return {
        "ok": True, "totale": totale, "punti": punti, "consigli": consigli, "n_lettere": len(gruppi),
        "misure": {"dev_inclinazione": dev_inc, "inclinazione_media": inc_media, "cv_altezza": cv_h,
                   "cv_spazi": cv_s, "scarto_base": scarto_base, "inclinazione_riga": inclinazione_riga},
    }


def formatta_regolarita_html(ris):
    import html as _h
    if not ris.get("ok"):
        return f"<p>{_h.escape(ris.get('messaggio', 'Analisi non disponibile.'))}</p>"
    nomi = {"inclinazione": "Inclinazione delle aste", "altezza": "Altezza delle lettere",
            "spaziatura": "Spaziatura", "riga": "Riga di base"}

    def barra(v):
        if v is None:
            return "<i>non misurabile</i>"
        col = "#5b8a3c" if v >= 70 else ("#c98a1b" if v >= 45 else "#b3412c")
        return f"<span style='color:{col}'><b>{v}</b>/100</span>"
    h = [f"<h3 style='color:#573417'>Regolarità: {ris['totale']}/100</h3>",
         f"<p>Lettere analizzate: {ris['n_lettere']}</p><table cellpadding='3'>"]
    for k in ("inclinazione", "altezza", "spaziatura", "riga"):
        h.append(f"<tr><td>{nomi[k]}</td><td align='right'>{barra(ris['punti'][k])}</td></tr>")
    h.append("</table><p><b>Cosa migliorare:</b></p><ul>" + "".join(f"<li>{_h.escape(c)}</li>" for c in ris["consigli"]) + "</ul>")
    h.append("<p style='color:#8a5a22'>⚠ Misura solo la geometria dei tratti: con il mouse non si vedono spessori e contrasto. "
             "Soglie indicative, non tarate su scritture di allievi.</p>")
    return "".join(h)
